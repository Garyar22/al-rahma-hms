#!/usr/bin/env bash
#
# Release a new version onto the hospital server.
# Usage:  sudo -u www-data bash scripts/deploy.sh
#
# Refuses to run without a fresh database backup: a migration that goes wrong
# with no backup is the worst afternoon this project can have.

set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/hms}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/hms}"
cd "$APP_DIR"

echo "==> Backing up the database first"
mkdir -p "$BACKUP_DIR"
STAMP=$(date +%F-%H%M)
mysqldump --single-transaction --routines --triggers \
  --user="${DB_USERNAME:-root}" "${DB_DATABASE:-al_rahma_hms}" \
  | gzip > "$BACKUP_DIR/pre-deploy-$STAMP.sql.gz"

if [ ! -s "$BACKUP_DIR/pre-deploy-$STAMP.sql.gz" ]; then
  echo "!! Backup is empty. Stopping before anything is changed." >&2
  exit 1
fi
echo "    saved $BACKUP_DIR/pre-deploy-$STAMP.sql.gz"

echo "==> Maintenance mode"
php artisan down --render="errors::503" --retry=60

cleanup() { php artisan up; }
trap cleanup EXIT          # the hospital never gets left on the 503 page

echo "==> Pulling the new version"
git pull --ff-only

echo "==> Dependencies"
composer install --no-dev --optimize-autoloader --no-interaction

echo "==> Migrations"
php artisan migrate --force

echo "==> Settings and reference data (idempotent; configured values are kept)"
php artisan db:seed --class=SettingSeeder --force

echo "==> Caches"
php artisan optimize

echo "==> Restarting services"
sudo systemctl restart hms-queue
sudo systemctl reload php8.4-fpm

echo "==> Done. Check the dashboard before telling staff it is back."
