<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('lab_requests', function (Blueprint $table) {
            $table->id();
            $table->string('request_number', 30)->unique();
            $table->foreignId('visit_id')->constrained('visits')->restrictOnDelete();
            $table->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $table->foreignId('requested_by')->constrained('doctors')->restrictOnDelete();
            $table->string('priority', 10)->default('routine'); // routine|urgent
            $table->text('clinical_notes')->nullable();
            $table->string('status', 22)->default('open')->index();
            $table->timestamp('requested_at')->index();
            $table->timestamps();
            $table->index(['patient_id', 'requested_at']);
        });

        Schema::create('lab_samples', function (Blueprint $table) {
            $table->id();
            $table->string('sample_number', 30)->unique();
            $table->foreignId('lab_request_id')->constrained('lab_requests')->restrictOnDelete();
            $table->string('sample_type', 40);
            $table->foreignId('collected_by')->constrained('users')->restrictOnDelete();
            $table->timestamp('collected_at');
            // A rejected sample is a real daily event: haemolysed, clotted,
            // insufficient. It must be recorded, not silently re-collected.
            $table->string('condition', 15)->default('good');
            $table->timestamp('rejected_at')->nullable();
            $table->foreignId('rejected_by')->nullable()->constrained('users')->nullOnDelete();
            $table->string('rejection_reason')->nullable();
            $table->timestamps();
        });

        Schema::create('lab_request_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('lab_request_id')->constrained('lab_requests')->cascadeOnDelete();
            $table->foreignId('lab_test_id')->constrained('lab_tests')->restrictOnDelete();
            // requested|sample_collected|processing|completed|verified|cancelled|sample_rejected
            $table->string('status', 20)->default('requested')->index();
            $table->decimal('price', 12, 2)->default(0);
            $table->foreignId('sample_id')->nullable()->constrained('lab_samples')->nullOnDelete();
            $table->timestamp('completed_at')->nullable();
            $table->timestamp('verified_at')->nullable();
            $table->foreignId('verified_by')->nullable()->constrained('users')->nullOnDelete();
            $table->string('cancellation_reason')->nullable();
            $table->timestamps();
            $table->index(['status', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('lab_request_items');
        Schema::dropIfExists('lab_samples');
        Schema::dropIfExists('lab_requests');
    }
};
