<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Batches are GLOBAL (Blueprint D3): batch number, expiry and cost live here
 | once, while quantity lives per location in stock_balances. The same batch
 | can sit in the main store and the pharmacy without duplicating its expiry
 | date — which is what keeps the expiry report trustworthy. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('item_batches', function (Blueprint $table) {
            $table->id();
            $table->foreignId('item_id')->constrained('items')->restrictOnDelete();
            $table->string('batch_number', 60);
            $table->date('expiry_date')->nullable()->index();
            $table->decimal('cost_price', 12, 2)->default(0);
            $table->decimal('selling_price', 12, 2)->default(0);
            $table->foreignId('supplier_id')->nullable()->constrained('suppliers')->nullOnDelete();
            $table->timestamp('received_at')->nullable();
            $table->timestamps();
            $table->unique(['item_id', 'batch_number', 'expiry_date']);
        });
    }

    public function down(): void { Schema::dropIfExists('item_batches'); }
};
