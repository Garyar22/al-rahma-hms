<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Employees (FR-STF-01). There is deliberately no `nurses` table: a nurse is
 | an employee whose user holds the Nurse role. A separate table would
 | duplicate `employees` without adding one distinct attribute.
 | Only information the hospital actually needs to operate is stored (§24). */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->id();
            $table->string('employee_number', 30)->unique();
            $table->string('first_name', 60);
            $table->string('middle_name', 60)->nullable();
            $table->string('last_name', 60);
            $table->string('gender', 10);
            $table->date('date_of_birth')->nullable();
            $table->string('phone', 25)->index();
            $table->string('email')->nullable();
            $table->foreignId('department_id')->constrained('departments')->restrictOnDelete();
            $table->string('job_title', 80);
            $table->date('hire_date');
            $table->string('employment_status', 15)->default('active');
            $table->time('shift_start')->nullable();  // drives "late" in attendance (FR-STF-04)
            $table->time('shift_end')->nullable();
            $table->string('emergency_contact_name')->nullable();
            $table->string('emergency_contact_phone', 25)->nullable();
            $table->string('address')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->index(['last_name', 'first_name']);
            $table->index('employment_status');
        });

        Schema::table('departments', function (Blueprint $table) {
            $table->foreign('head_employee_id')->references('id')->on('employees')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('departments', fn (Blueprint $t) => $t->dropForeign(['head_employee_id']));
        Schema::dropIfExists('employees');
    }
};
