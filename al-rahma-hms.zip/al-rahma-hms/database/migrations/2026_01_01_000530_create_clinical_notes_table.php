<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Ward rounds, nursing notes, observations and handover. Polymorphic over
 | visit or admission so the same note machinery serves OPD and inpatient. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('clinical_notes', function (Blueprint $table) {
            $table->id();
            $table->string('notable_type');   // visit|admission (morph map)
            $table->unsignedBigInteger('notable_id');
            $table->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $table->string('note_type', 15)->default('progress'); // progress|nursing|round|handover|procedure|other
            $table->text('body');
            $table->foreignId('author_id')->constrained('users')->restrictOnDelete();
            $table->timestamp('recorded_at');
            $table->timestamps();
            $table->index(['notable_type', 'notable_id']);
            $table->index(['patient_id', 'recorded_at']);
        });
    }

    public function down(): void { Schema::dropIfExists('clinical_notes'); }
};
