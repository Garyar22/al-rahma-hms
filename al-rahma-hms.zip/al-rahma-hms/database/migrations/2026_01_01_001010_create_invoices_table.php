<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

/*
 | INVOICES. Financial records are never deleted (mandatory rule §49.6 and
 | §20 of the project instruction): the only corrections are `cancelled` and
 | `written_off`, both requiring a reason and an authorising user.
 |
 | invoice_items carries a POLYMORPHIC link to whatever clinical event
 | generated the charge, with UNIQUE (billable_type, billable_id). That single
 | constraint is what makes double-billing impossible even if a request is
 | retried or two staff click at once (Blueprint D7).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->id();
            $table->string('invoice_number', 30)->unique();
            $table->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $table->foreignId('visit_id')->nullable()->constrained('visits')->restrictOnDelete();
            $table->foreignId('admission_id')->nullable()->constrained('admissions')->restrictOnDelete();
            $table->string('status', 15)->default('draft')->index(); // draft|issued|partially_paid|paid|cancelled|written_off
            $table->decimal('subtotal', 14, 2)->default(0);
            $table->decimal('discount_amount', 14, 2)->default(0);
            $table->string('discount_reason')->nullable();
            $table->foreignId('discount_approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->decimal('total', 14, 2)->default(0);
            $table->decimal('amount_paid', 14, 2)->default(0);
            $table->decimal('balance', 14, 2)->default(0);
            $table->string('currency', 3)->default('USD');
            $table->timestamp('issued_at')->nullable()->index();
            $table->foreignId('created_by')->constrained('users')->restrictOnDelete();
            $table->foreignId('cancelled_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('cancelled_at')->nullable();
            $table->text('cancellation_reason')->nullable();
            $table->timestamps();
            $table->index(['patient_id', 'status']);
        });

        $offset = (int) config('hospital.utc_offset_hours', 3);
        $isMysql = in_array(DB::getDriverName(), ['mysql', 'mariadb'], true);

        if ($isMysql) {
            Schema::table('invoices', function (Blueprint $table) use ($offset) {
                $table->date('business_date')
                    ->storedAs("DATE(issued_at + INTERVAL {$offset} HOUR)")
                    ->after('issued_at');
                $table->index(['business_date', 'status']);
            });
        }

        Schema::create('invoice_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained('invoices')->restrictOnDelete();
            $table->foreignId('service_id')->nullable()->constrained('services')->nullOnDelete();
            $table->string('billable_type')->nullable();
            $table->unsignedBigInteger('billable_id')->nullable();
            $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
            $table->string('description');
            $table->decimal('quantity', 12, 2)->default(1);
            $table->decimal('unit_price', 12, 2);
            $table->decimal('discount_amount', 12, 2)->default(0);
            $table->decimal('line_total', 14, 2);
            $table->foreignId('created_by')->constrained('users')->restrictOnDelete();
            $table->timestamps();

            // One charge per clinical order, guaranteed (Blueprint D7).
            $table->unique(['billable_type', 'billable_id'], 'invoice_items_billable_unique');
            $table->index('invoice_id');
        });

        Schema::table('dispenses', function (Blueprint $table) {
            $table->foreign('invoice_id')->references('id')->on('invoices')->nullOnDelete();
        });

        if ($isMysql) {
            DB::statement('ALTER TABLE invoices ADD CONSTRAINT chk_invoice_paid_not_negative CHECK (amount_paid >= 0)');
        }
    }

    public function down(): void
    {
        Schema::table('dispenses', fn (Blueprint $t) => $t->dropForeign(['invoice_id']));
        Schema::dropIfExists('invoice_items');
        Schema::dropIfExists('invoices');
    }
};
