<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* NEVER updated and never deleted (FR-VIT-03, mandatory rule §49.1).
 | A correction inserts a NEW row pointing at the one it replaces, so the
 | original reading and the correction are both visible with their timestamps.
 | There is intentionally no updated_at: these rows do not change. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('vital_signs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $table->foreignId('visit_id')->nullable()->constrained('visits')->nullOnDelete();
            $table->unsignedBigInteger('admission_id')->nullable(); // FK added after admissions
            $table->decimal('temperature_c', 4, 1)->nullable();
            $table->unsignedSmallInteger('systolic')->nullable();
            $table->unsignedSmallInteger('diastolic')->nullable();
            $table->unsignedSmallInteger('pulse')->nullable();
            $table->unsignedSmallInteger('respiratory_rate')->nullable();
            $table->unsignedTinyInteger('spo2')->nullable();
            $table->decimal('weight_kg', 5, 2)->nullable();
            $table->decimal('height_cm', 5, 1)->nullable();
            $table->decimal('bmi', 5, 2)->nullable();
            $table->unsignedTinyInteger('pain_score')->nullable();
            $table->text('notes')->nullable();
            $table->foreignId('recorded_by')->constrained('users')->restrictOnDelete();
            $table->timestamp('recorded_at')->index();
            $table->foreignId('is_correction_of_id')->nullable()->constrained('vital_signs')->nullOnDelete();
            $table->timestamp('created_at');
            $table->index(['patient_id', 'recorded_at']);
        });
    }

    public function down(): void { Schema::dropIfExists('vital_signs'); }
};
