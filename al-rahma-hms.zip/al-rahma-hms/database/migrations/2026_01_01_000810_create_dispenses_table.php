<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* A reversal creates a NEW dispense row linked to the original rather than
 | editing it, so the pharmacy register always reads as what actually
 | happened, in order. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('dispenses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('prescription_id')->nullable()->constrained('prescriptions')->restrictOnDelete();
            $table->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $table->foreignId('location_id')->constrained('stock_locations')->restrictOnDelete();
            $table->unsignedBigInteger('invoice_id')->nullable(); // FK added after invoices
            $table->foreignId('dispensed_by')->constrained('users')->restrictOnDelete();
            $table->timestamp('dispensed_at')->index();
            $table->string('status', 10)->default('completed'); // completed|reversed
            $table->foreignId('reversal_of_id')->nullable()->constrained('dispenses')->nullOnDelete();
            $table->text('reason')->nullable();
            $table->timestamps();
        });

        Schema::create('dispense_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('dispense_id')->constrained('dispenses')->cascadeOnDelete();
            $table->foreignId('prescription_item_id')->nullable()->constrained('prescription_items')->nullOnDelete();
            $table->foreignId('item_id')->constrained('items')->restrictOnDelete();
            $table->foreignId('batch_id')->constrained('item_batches')->restrictOnDelete();
            $table->decimal('quantity', 12, 2);
            $table->decimal('unit_price', 12, 2);
            $table->decimal('line_total', 14, 2);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('dispense_items');
        Schema::dropIfExists('dispenses');
    }
};
