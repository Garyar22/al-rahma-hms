<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* The daily queue (FR-VIS-02/03). Numbers restart each day per department and
 | the unique index guarantees no two patients are handed the same number —
 | the fastest way to lose the waiting room's trust on day one. priority 1 is
 | most urgent; emergency cases enter ahead of routine OPD by priority rather
 | than by number (FR-EMG-03). */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('queue_entries', function (Blueprint $table) {
            $table->id();
            $table->foreignId('visit_id')->unique()->constrained('visits')->cascadeOnDelete();
            $table->foreignId('department_id')->constrained('departments')->restrictOnDelete();
            $table->date('queue_date');
            $table->unsignedInteger('queue_number');
            $table->unsignedTinyInteger('priority')->default(3);
            $table->string('status', 16)->default('waiting')->index();
            $table->timestamp('called_at')->nullable();
            $table->foreignId('called_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('served_at')->nullable();
            $table->timestamps();
            $table->unique(['department_id', 'queue_date', 'queue_number']);
            $table->index(['queue_date', 'status', 'priority']);
        });
    }

    public function down(): void { Schema::dropIfExists('queue_entries'); }
};
