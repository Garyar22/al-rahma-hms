<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Every report generation is recorded (FR-REP-10). reference_no is printed in
 | the footer so any printed page traces back to who ran it and with which
 | filters. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('report_runs', function (Blueprint $table) {
            $table->id();
            $table->string('reference_no', 30)->unique();
            $table->string('report_key', 60)->index();
            $table->json('parameters');
            $table->string('format', 10)->default('html');
            $table->unsignedInteger('row_count')->nullable();
            $table->unsignedInteger('duration_ms')->nullable();
            $table->foreignId('generated_by')->constrained('users')->restrictOnDelete();
            $table->timestamp('generated_at')->index();
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('report_runs'); }
};
