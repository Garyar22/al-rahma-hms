<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Discharge is a STATE of the admission, not a separate table: a 1:1
 | `discharges` table would add a join and an integrity risk for no gain.
 | last_bed_charge_date lets the nightly job accrue one bed charge per day
 | idempotently, so a re-run never double-bills the patient. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('admissions', function (Blueprint $table) {
            $table->id();
            $table->string('admission_number', 30)->unique();
            $table->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $table->foreignId('visit_id')->unique()->constrained('visits')->restrictOnDelete();
            $table->foreignId('attending_doctor_id')->constrained('doctors')->restrictOnDelete();
            $table->foreignId('ward_id')->constrained('wards')->restrictOnDelete();
            $table->timestamp('admitted_at')->index();
            $table->text('admission_reason');
            $table->string('provisional_diagnosis')->nullable();
            $table->string('status', 15)->default('admitted')->index(); // admitted|discharged|transferred_out|absconded|deceased
            $table->timestamp('discharged_at')->nullable();
            $table->string('discharge_type', 20)->nullable(); // home|referred|transferred|absconded|deceased|against_advice
            $table->text('discharge_summary')->nullable();
            $table->foreignId('discharged_by')->nullable()->constrained('users')->nullOnDelete();
            $table->date('last_bed_charge_date')->nullable();
            $table->foreignId('created_by')->constrained('users')->restrictOnDelete();
            $table->timestamps();
        });

        Schema::table('vital_signs', function (Blueprint $table) {
            $table->foreign('admission_id')->references('id')->on('admissions')->nullOnDelete();
            $table->index(['admission_id', 'recorded_at']);
        });
    }

    public function down(): void
    {
        Schema::table('vital_signs', fn (Blueprint $t) => $t->dropForeign(['admission_id']));
        Schema::dropIfExists('admissions');
    }
};
