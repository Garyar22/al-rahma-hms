<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | Results are released to the doctor only after verification (FR-LAB-06), and
 | are immutable once verified (FR-LAB-09): an amendment inserts a new row
 | pointing at the one it supersedes, and both remain visible with their
 | timestamps.
 |
 | ref_range_snapshot stores the range that applied AT THE TIME. Reference
 | ranges get corrected; a report reprinted two years later must show the
 | range the clinician actually read, not today's.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('lab_results', function (Blueprint $table) {
            $table->id();
            $table->foreignId('lab_request_item_id')->constrained('lab_request_items')->cascadeOnDelete();
            $table->foreignId('parameter_id')->nullable()->constrained('lab_test_parameters')->nullOnDelete();
            $table->decimal('value_numeric', 14, 3)->nullable();
            $table->text('value_text')->nullable();
            $table->string('flag', 15)->nullable(); // low|normal|high|critical_low|critical_high|abnormal
            $table->string('ref_range_snapshot', 80)->nullable();
            $table->foreignId('entered_by')->constrained('users')->restrictOnDelete();
            $table->timestamp('entered_at');
            $table->foreignId('supersedes_id')->nullable()->constrained('lab_results')->nullOnDelete();
            $table->boolean('is_amended')->default(false);
            $table->string('amendment_reason')->nullable();
            $table->text('comments')->nullable();
            $table->timestamps();
            $table->index(['lab_request_item_id', 'entered_at']);
        });
    }

    public function down(): void { Schema::dropIfExists('lab_results'); }
};
