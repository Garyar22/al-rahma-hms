<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Emergency extends a visit of type `emergency`. Billing never gates
 | emergency care: charges accumulate and are settled afterwards regardless of
 | the pay-before-service setting (FR-EMG-05). */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('emergency_cases', function (Blueprint $table) {
            $table->id();
            $table->foreignId('visit_id')->unique()->constrained('visits')->cascadeOnDelete();
            $table->timestamp('arrival_at');
            $table->string('arrival_mode', 15)->default('walk_in');
            $table->unsignedTinyInteger('triage_priority')->default(3);
            $table->foreignId('triage_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('triage_at')->nullable();
            $table->text('presenting_complaint');
            $table->string('disposition', 12)->default('pending')->index();
            $table->timestamp('disposition_at')->nullable();
            $table->foreignId('disposition_by')->nullable()->constrained('users')->nullOnDelete();
            $table->string('referred_to')->nullable();
            $table->text('disposition_notes')->nullable();
            $table->timestamps();
            $table->index(['arrival_at', 'triage_priority']);
        });
    }

    public function down(): void { Schema::dropIfExists('emergency_cases'); }
};
