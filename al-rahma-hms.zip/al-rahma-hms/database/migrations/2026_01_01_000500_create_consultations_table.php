<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* A finalised consultation is never edited (Blueprint D11, mandatory rule
 | §49.2). Corrections become timestamped, attributed addenda. Draft is the
 | only editable state, and only by its author within the grace window. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('consultations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('visit_id')->unique()->constrained('visits')->restrictOnDelete();
            $table->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $table->foreignId('doctor_id')->constrained('doctors')->restrictOnDelete();
            $table->text('chief_complaint');
            $table->text('history_present_illness')->nullable();
            $table->text('past_medical_history')->nullable();
            $table->text('current_medication')->nullable();
            $table->text('examination')->nullable();
            $table->text('assessment')->nullable();
            $table->text('plan')->nullable();
            $table->date('follow_up_date')->nullable();
            $table->text('follow_up_notes')->nullable();
            $table->string('status', 10)->default('draft'); // draft|finalised
            $table->timestamp('finalised_at')->nullable()->index();
            $table->timestamps();
            $table->index(['doctor_id', 'finalised_at']);
            $table->index('patient_id');
        });
    }

    public function down(): void { Schema::dropIfExists('consultations'); }
};
