<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | STOCK MOVEMENTS — append-only ledger, the single source of truth for every
 | quantity change (Blueprint D4, mandatory rule §49.3).
 |
 | Nothing in the application edits a quantity directly. Every receipt, issue,
 | transfer, dispense, return, adjustment and disposal appends a row with who
 | did it, when, why and against which document. balance_after is recorded at
 | write time so "why is this item wrong?" is answerable by reading down the
 | ledger instead of recomputing history.
 |
 | There is no updated_at: these rows never change.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('stock_movements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('item_id')->constrained('items')->restrictOnDelete();
            $table->foreignId('batch_id')->nullable()->constrained('item_batches')->restrictOnDelete();
            $table->foreignId('location_id')->constrained('stock_locations')->restrictOnDelete();
            $table->foreignId('counterparty_location_id')->nullable()->constrained('stock_locations')->nullOnDelete();
            // receipt|issue|transfer_in|transfer_out|dispense|return|adjustment|
            // disposal_expired|disposal_damaged|count_correction
            $table->string('type', 20)->index();
            $table->decimal('quantity_change', 14, 2); // signed
            $table->decimal('balance_after', 14, 2);
            $table->decimal('unit_cost', 12, 2)->nullable();
            $table->string('reference_type')->nullable();
            $table->unsignedBigInteger('reference_id')->nullable();
            $table->string('reason')->nullable();
            $table->foreignId('performed_by')->constrained('users')->restrictOnDelete();
            $table->timestamp('occurred_at')->index();
            $table->timestamp('created_at');
            $table->index(['item_id', 'occurred_at']);
            $table->index(['location_id', 'occurred_at']);
            $table->index(['reference_type', 'reference_id']);
        });

        $offset = (int) config('hospital.utc_offset_hours', 3);
        if (in_array(Schema::getConnection()->getDriverName(), ['mysql', 'mariadb'], true)) {
            Schema::table('stock_movements', function (Blueprint $table) use ($offset) {
                $table->date('business_date')
                    ->storedAs("DATE(occurred_at + INTERVAL {$offset} HOUR)")
                    ->after('occurred_at');
                $table->index(['business_date', 'type']);
            });
        }
    }

    public function down(): void { Schema::dropIfExists('stock_movements'); }
};
