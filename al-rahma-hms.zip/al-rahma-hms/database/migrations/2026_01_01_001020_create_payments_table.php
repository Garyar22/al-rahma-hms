<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | PAYMENTS AND RECEIPTS.
 |
 | A receipt is immutable (FR-PAY-05). A reversal or refund is a NEW row with
 | a negative amount linked to the original; the original keeps its receipt
 | number and remains retrievable and reprintable, marked REVERSED.
 |
 | This is also why `amount` is signed rather than having a separate reversal
 | table: "sum the payments in this period" then gives the correct net figure
 | in one query, and the metric dictionary's rule — a reversal counts on the
 | date it was made — falls out naturally.
 |
 | print_count backs FR-PAY-04: every reprint is counted and audited, because
 | an uncontrolled reprint is how a cash receipt gets used twice.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->string('receipt_number', 30)->unique();
            $table->foreignId('invoice_id')->nullable()->constrained('invoices')->restrictOnDelete();
            $table->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $table->string('type', 10)->default('payment'); // payment|reversal|refund
            $table->decimal('amount', 14, 2); // signed: reversals negative
            $table->foreignId('payment_method_id')->constrained('payment_methods')->restrictOnDelete();
            $table->string('reference_no', 60)->nullable();
            $table->string('status', 10)->default('completed')->index(); // completed|reversed
            $table->foreignId('reverses_payment_id')->nullable()->constrained('payments')->nullOnDelete();
            $table->foreignId('shift_id')->nullable()->constrained('cashier_shifts')->nullOnDelete();
            $table->foreignId('received_by')->constrained('users')->restrictOnDelete();
            $table->timestamp('paid_at')->index();
            $table->text('reason')->nullable();
            $table->text('notes')->nullable();
            $table->unsignedSmallInteger('print_count')->default(0);
            $table->timestamps();
            $table->index('patient_id');
            $table->index(['received_by', 'paid_at']);
        });

        $offset = (int) config('hospital.utc_offset_hours', 3);
        if (in_array(Schema::getConnection()->getDriverName(), ['mysql', 'mariadb'], true)) {
            Schema::table('payments', function (Blueprint $table) use ($offset) {
                $table->date('business_date')
                    ->storedAs("DATE(paid_at + INTERVAL {$offset} HOUR)")
                    ->after('paid_at');
                $table->index(['business_date', 'payment_method_id']);
            });
        }
    }

    public function down(): void { Schema::dropIfExists('payments'); }
};
