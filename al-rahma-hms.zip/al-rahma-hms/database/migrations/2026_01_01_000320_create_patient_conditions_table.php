<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Persistent problem list (diabetes, hypertension, epilepsy). Distinct from
 | `diagnoses`, which record what was found at one consultation. A doctor must
 | see chronic conditions immediately without reading five years of notes. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('patient_conditions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained('patients')->cascadeOnDelete();
            $table->string('condition');
            $table->date('onset_date')->nullable();
            $table->string('status', 10)->default('active');
            $table->text('notes')->nullable();
            $table->foreignId('recorded_by')->constrained('users')->restrictOnDelete();
            $table->timestamps();
            $table->index(['patient_id', 'status']);
        });
    }

    public function down(): void { Schema::dropIfExists('patient_conditions'); }
};
