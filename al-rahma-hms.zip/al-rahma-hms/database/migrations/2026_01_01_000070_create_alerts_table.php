<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Materialised operational alerts, refreshed by the scheduler rather than
 | recomputed on every dashboard load (NFR-01). Deliberately few types: §28
 | warns against notification noise, which staff learn to ignore. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('alerts', function (Blueprint $table) {
            $table->id();
            $table->string('type', 40)->index();
            $table->string('severity', 10)->default('warning');
            $table->string('subject_type')->nullable();
            $table->unsignedBigInteger('subject_id')->nullable();
            $table->string('message');
            $table->json('data')->nullable();
            $table->boolean('is_resolved')->default(false)->index();
            $table->timestamp('resolved_at')->nullable();
            $table->timestamps();
            $table->index(['subject_type', 'subject_id']);
        });
    }

    public function down(): void { Schema::dropIfExists('alerts'); }
};
