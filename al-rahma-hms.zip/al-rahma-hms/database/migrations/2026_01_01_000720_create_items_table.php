<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | ITEMS — one master for medicines AND general supplies (Blueprint D2).
 |
 | The project context lists both `medicines` and `inventory_items`. Building
 | both means two stock engines, two expiry reports and guaranteed divergence
 | between them. Medicine-specific columns are simply nullable here, and
 | `item_type` discriminates. The pharmacy is a stock LOCATION, not a second
 | inventory system.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('items', function (Blueprint $table) {
            $table->id();
            $table->string('item_code', 30)->unique();
            $table->string('name')->index();
            $table->string('generic_name')->nullable()->index();
            $table->string('brand_name')->nullable();
            $table->string('item_type', 15)->default('medicine')->index(); // medicine|supply|consumable|equipment|other
            $table->foreignId('category_id')->constrained('item_categories')->restrictOnDelete();
            $table->foreignId('unit_id')->constrained('units')->restrictOnDelete();
            $table->string('strength', 50)->nullable();     // medicine only
            $table->string('dosage_form', 40)->nullable();
            $table->string('route', 30)->nullable();
            $table->boolean('is_batch_tracked')->default(true);
            $table->boolean('is_expiry_tracked')->default(true);
            $table->boolean('is_billable')->default(true);
            $table->boolean('requires_prescription')->default(true);
            $table->decimal('reorder_level', 12, 2)->default(0);
            $table->decimal('default_selling_price', 12, 2)->default(0);
            $table->foreignId('service_id')->nullable()->constrained('services')->nullOnDelete();
            $table->text('notes')->nullable();
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::table('patient_allergies', function (Blueprint $table) {
            $table->foreign('item_id')->references('id')->on('items')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('patient_allergies', fn (Blueprint $t) => $t->dropForeign(['item_id']));
        Schema::dropIfExists('items');
    }
};
