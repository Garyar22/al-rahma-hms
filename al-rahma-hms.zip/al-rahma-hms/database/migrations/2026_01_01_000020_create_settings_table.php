<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Hospital settings (FR-SEC-06, Rule 11): everything an administrator may
 | change without a developer. Security-affecting keys are flagged so the UI
 | can keep them Owner-only even where Management edits branding. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('group', 50)->index();
            $table->string('key', 100)->unique();
            $table->text('value')->nullable();
            $table->string('type', 20)->default('string'); // string|int|bool|json|decimal
            $table->string('label')->nullable();
            $table->text('description')->nullable();
            $table->boolean('is_security_sensitive')->default(false);
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('settings'); }
};
