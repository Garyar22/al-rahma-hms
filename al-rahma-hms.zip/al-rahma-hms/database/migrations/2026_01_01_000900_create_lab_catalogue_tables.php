<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Configurable test catalogue (FR-LAB-01/02). Reference ranges are per
 | parameter and may vary by sex and age — a haemoglobin range that ignores
 | this flags healthy women and children as abnormal every single day. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('lab_test_categories', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->unsignedSmallInteger('display_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('lab_tests', function (Blueprint $table) {
            $table->id();
            $table->string('code', 30)->unique();
            $table->string('name');
            $table->foreignId('category_id')->constrained('lab_test_categories')->restrictOnDelete();
            $table->foreignId('service_id')->nullable()->constrained('services')->nullOnDelete();
            $table->string('sample_type', 40);
            $table->string('container', 40)->nullable();
            $table->unsignedSmallInteger('turnaround_hours')->nullable();
            $table->decimal('price', 12, 2)->default(0);
            $table->boolean('has_parameters')->default(true);
            $table->text('preparation_notes')->nullable();
            $table->boolean('is_active')->default(true)->index();
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('lab_test_parameters', function (Blueprint $table) {
            $table->id();
            $table->foreignId('lab_test_id')->constrained('lab_tests')->cascadeOnDelete();
            $table->string('name');
            $table->string('unit', 20)->nullable();
            $table->string('result_type', 10)->default('numeric'); // numeric|text|option
            $table->json('options')->nullable();
            $table->decimal('ref_low', 12, 3)->nullable();
            $table->decimal('ref_high', 12, 3)->nullable();
            $table->string('ref_text')->nullable();
            $table->decimal('critical_low', 12, 3)->nullable();
            $table->decimal('critical_high', 12, 3)->nullable();
            $table->string('sex_applicability', 10)->default('any');
            $table->unsignedTinyInteger('age_min_years')->nullable();
            $table->unsignedTinyInteger('age_max_years')->nullable();
            $table->unsignedSmallInteger('display_order')->default(0);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('lab_test_parameters');
        Schema::dropIfExists('lab_tests');
        Schema::dropIfExists('lab_test_categories');
    }
};
