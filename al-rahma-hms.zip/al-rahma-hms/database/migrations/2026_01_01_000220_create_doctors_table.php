<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* A doctor EXTENDS an employee (1:1) rather than duplicating name, phone and
 | department. Doctor-specific attributes only. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('doctors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->unique()->constrained('employees')->restrictOnDelete();
            $table->string('specialty', 80)->nullable();
            $table->string('license_number', 50)->nullable();
            $table->string('qualification', 120)->nullable();
            $table->decimal('consultation_fee', 12, 2)->default(0);
            $table->foreignId('consultation_service_id')->nullable()->constrained('services')->nullOnDelete();
            $table->unsignedSmallInteger('default_slot_minutes')->default(20);
            $table->string('signature_path')->nullable();
            $table->boolean('is_accepting_appointments')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('doctors'); }
};
