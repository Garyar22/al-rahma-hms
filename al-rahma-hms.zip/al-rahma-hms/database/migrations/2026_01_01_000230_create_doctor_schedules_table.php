<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Published working hours. Appointments may only be booked into a slot
 | generated from an active schedule (FR-APT-01), which is what gives the
 | slot_lock unique index on appointments its meaning. effective_from/to let a
 | schedule change without invalidating why an old booking was legal. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('doctor_schedules', function (Blueprint $table) {
            $table->id();
            $table->foreignId('doctor_id')->constrained('doctors')->cascadeOnDelete();
            $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
            $table->unsignedTinyInteger('day_of_week'); // 0 = Sunday
            $table->time('start_time');
            $table->time('end_time');
            $table->unsignedSmallInteger('slot_minutes')->default(20);
            $table->date('effective_from');
            $table->date('effective_to')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->index(['doctor_id', 'day_of_week', 'is_active']);
        });
    }

    public function down(): void { Schema::dropIfExists('doctor_schedules'); }
};
