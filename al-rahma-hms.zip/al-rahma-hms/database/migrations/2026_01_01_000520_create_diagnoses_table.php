<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* code_system/code are reserved so ICD-10 or ICD-11 can be adopted later
 | without a schema change (§12 of the project instruction). v1 records the
 | description plus a seeded shortlist of locally common conditions for
 | autocomplete, which is what makes "common diagnoses" reportable at all. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('diagnoses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('consultation_id')->constrained('consultations')->cascadeOnDelete();
            $table->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $table->string('type', 15)->default('primary'); // primary|secondary|provisional|differential
            $table->string('code_system', 10)->nullable();
            $table->string('code', 20)->nullable();
            $table->string('description')->index();
            $table->text('notes')->nullable();
            $table->foreignId('created_by')->constrained('users')->restrictOnDelete();
            $table->timestamps();
            $table->index(['patient_id', 'type']);
        });
    }

    public function down(): void { Schema::dropIfExists('diagnoses'); }
};
