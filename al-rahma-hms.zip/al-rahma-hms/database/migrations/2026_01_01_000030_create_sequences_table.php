<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Human-readable document numbers (Blueprint D6). Allocation is always
 | SELECT ... FOR UPDATE -> format -> increment inside the caller's transaction.
 | MAX(id)+1 duplicates under concurrency; auto-increment leaves gaps that a
 | hospital owner will question on an invoice series. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sequences', function (Blueprint $table) {
            $table->id();
            $table->string('key', 50)->unique();
            $table->string('prefix', 20);
            $table->unsignedBigInteger('next_number')->default(1);
            $table->unsignedTinyInteger('padding')->default(6);
            $table->string('reset_period', 10)->default('none'); // none|yearly|monthly
            $table->string('current_period', 7)->nullable();
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('sequences'); }
};
