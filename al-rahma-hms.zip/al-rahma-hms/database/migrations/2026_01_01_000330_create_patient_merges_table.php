<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Audit of duplicate-patient merges (FR-PAT-08). merged_patient_number is
 | copied as a string so the old number stays searchable forever: a patient
 | returning with an old card must still be found. moved_counts records how
 | many visits/invoices/results were reassigned so a merge can be checked
 | afterwards without guesswork. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('patient_merges', function (Blueprint $table) {
            $table->id();
            $table->foreignId('surviving_patient_id')->constrained('patients')->restrictOnDelete();
            $table->foreignId('merged_patient_id')->constrained('patients')->restrictOnDelete();
            $table->string('merged_patient_number', 30)->index();
            $table->text('reason');
            $table->json('moved_counts')->nullable();
            $table->foreignId('performed_by')->constrained('users')->restrictOnDelete();
            $table->timestamp('performed_at');
            $table->timestamps();
        });
    }

    public function down(): void { Schema::dropIfExists('patient_merges'); }
};
