<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | BED OCCUPANCY — guaranteed by the database, same technique as appointments.
 |
 | active_flag is 1 while the patient occupies the bed and NULL once released.
 | UNIQUE (bed_id, active_flag)       -> one occupant per bed, ever.
 | UNIQUE (admission_id, active_flag) -> one bed per patient at a time.
 |
 | Released rows keep active_flag NULL, so the full movement history of every
 | transfer is retained without weakening the constraint (FR-IPD-02/04,
 | mandatory rule §49.x).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('bed_assignments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('admission_id')->constrained('admissions')->restrictOnDelete();
            $table->foreignId('bed_id')->constrained('beds')->restrictOnDelete();
            $table->timestamp('assigned_at');
            $table->timestamp('released_at')->nullable();
            $table->unsignedTinyInteger('active_flag')->nullable();
            $table->foreignId('assigned_by')->constrained('users')->restrictOnDelete();
            $table->string('release_reason', 60)->nullable();
            $table->timestamps();

            $table->unique(['bed_id', 'active_flag'], 'bed_assignments_bed_active_unique');
            $table->unique(['admission_id', 'active_flag'], 'bed_assignments_admission_active_unique');
            $table->index(['admission_id', 'assigned_at']);
        });
    }

    public function down(): void { Schema::dropIfExists('bed_assignments'); }
};
