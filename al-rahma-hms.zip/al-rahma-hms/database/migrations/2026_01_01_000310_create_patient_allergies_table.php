<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Shown on every clinical screen and checked when prescribing (FR-PRX-03).
 | item_id links the allergy to a catalogue medicine where the allergen is a
 | stocked drug, which makes the prescribing check reliable rather than a
 | string comparison. Allergies are deactivated, never deleted: "recorded then
 | disputed" is clinically different from "never recorded". */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('patient_allergies', function (Blueprint $table) {
            $table->id();
            $table->foreignId('patient_id')->constrained('patients')->cascadeOnDelete();
            $table->string('allergen');
            $table->string('allergy_type', 20)->default('drug');
            $table->unsignedBigInteger('item_id')->nullable(); // FK added after items
            $table->string('reaction')->nullable();
            $table->string('severity', 10)->default('moderate');
            $table->string('status', 10)->default('active');
            $table->foreignId('recorded_by')->constrained('users')->restrictOnDelete();
            $table->timestamp('recorded_at');
            $table->timestamps();
            $table->index(['patient_id', 'status']);
        });
    }

    public function down(): void { Schema::dropIfExists('patient_allergies'); }
};
