<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | VISITS — one table for every encounter type (Blueprint D1).
 |
 | Outpatient, emergency, inpatient and follow-up all live here with a `type`
 | discriminator; emergency_cases and admissions EXTEND a visit rather than
 | duplicating the encounter. Every charge, order, note and result needs
 | exactly one encounter to hang on. Three encounter tables would force every
 | downstream module to handle three polymorphic parents, and "all visits this
 | month" — the most requested figure in the hospital — would become a UNION.
 |
 | business_date is a STORED GENERATED column so daily/monthly grouping uses
 | hospital-local days (UTC+3) and stays indexable (Blueprint D9). Without it
 | every transaction between 00:00 and 03:00 EAT lands on the previous day's
 | report.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('visits', function (Blueprint $table) {
            $table->id();
            $table->string('visit_number', 30)->unique();
            $table->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $table->string('type', 12)->default('outpatient')->index();
            $table->foreignId('department_id')->constrained('departments')->restrictOnDelete();
            $table->foreignId('doctor_id')->nullable()->constrained('doctors')->nullOnDelete();
            $table->foreignId('parent_visit_id')->nullable()->constrained('visits')->nullOnDelete();
            $table->string('status', 20)->default('registered')->index();
            $table->string('chief_complaint_short')->nullable();
            $table->timestamp('arrived_at');
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->foreignId('created_by')->constrained('users')->restrictOnDelete();
            $table->foreignId('closed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->text('cancellation_reason')->nullable();
            $table->timestamps();
            $table->index(['patient_id', 'arrived_at']);
            $table->index(['department_id', 'arrived_at']);
        });

        $offset = (int) config('hospital.utc_offset_hours', 3);
        if (in_array(Schema::getConnection()->getDriverName(), ['mysql', 'mariadb'], true)) {
            Schema::table('visits', function (Blueprint $table) use ($offset) {
                $table->date('business_date')
                    ->storedAs("DATE(arrived_at + INTERVAL {$offset} HOUR)")
                    ->after('arrived_at');
                $table->index(['business_date', 'type']);
                $table->index(['business_date', 'department_id']);
            });
        }
    }

    public function down(): void { Schema::dropIfExists('visits'); }
};
