<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | Extends Laravel's default users table. There is no public registration
 | route: accounts are created by an administrator and must change their
 | password on first login (FR-SEC-08). Users are deactivated, never deleted
 | (FR-SEC-09), so their history stays attributed.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('username', 60)->unique()->after('name');
            $table->boolean('is_active')->default(true)->after('password');
            $table->boolean('is_protected')->default(false)->after('is_active');
            $table->boolean('must_change_password')->default(true)->after('is_protected');
            $table->timestamp('password_changed_at')->nullable();
            $table->timestamp('last_login_at')->nullable();
            $table->string('last_login_ip', 45)->nullable();
            $table->unsignedSmallInteger('failed_login_count')->default(0);
            $table->timestamp('locked_until')->nullable();
            $table->string('two_factor_secret')->nullable();
            $table->softDeletes();
            $table->index('is_active');
        });

        // Email is optional here: many hospital staff have no email address.
        Schema::table('users', function (Blueprint $table) {
            $table->string('email')->nullable()->change();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropIndex(['is_active']);
            $table->dropSoftDeletes();
            $table->dropColumn([
                'username', 'is_active', 'is_protected', 'must_change_password',
                'password_changed_at', 'last_login_at', 'last_login_ip',
                'failed_login_count', 'locked_until', 'two_factor_secret',
            ]);
        });
    }
};
