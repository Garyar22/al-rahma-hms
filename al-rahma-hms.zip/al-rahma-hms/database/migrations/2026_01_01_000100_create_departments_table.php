<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | SECTORS / DEPARTMENTS — the hospital's own organisational structure.
 |
 | The administration can create, rename, restructure, deactivate and delete
 | any sector without a developer (§10 of the project instruction). To make
 | that genuinely flexible rather than a fixed list with an edit button:
 |
 |  - `parent_id` gives unlimited nesting: Sector -> Department -> Unit.
 |    "Clinical Services > Outpatient > Paediatrics" is created entirely
 |    through the UI.
 |  - `kind` labels the level (sector|department|unit) for display and
 |    reporting grouping, without constraining the tree.
 |  - `modules` is a JSON list of system modules this sector uses, chosen from
 |    config('hospital.modules'). Turning Maternity or Radiology on for a new
 |    sector is a checkbox, not a migration.
 |  - `is_system` protects the handful of sectors the software itself depends
 |    on (e.g. the one that receives walk-in OPD visits). They can be RENAMED
 |    and reconfigured, but not deleted, so the system cannot be bricked by a
 |    well-meant tidy-up.
 |  - Soft deletes, because a deleted sector still appears in three years of
 |    historical visits, invoices and reports. Hard-deleting it would orphan
 |    them; FKs restrict on delete for the same reason.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('departments', function (Blueprint $table) {
            $table->id();
            $table->string('code', 30)->unique();
            $table->string('name');
            $table->foreignId('parent_id')->nullable()
                ->constrained('departments')->restrictOnDelete();
            $table->string('kind', 15)->default('department'); // sector|department|unit
            $table->string('type', 20)->default('clinical');   // clinical|support|administrative
            $table->json('modules')->nullable();
            $table->text('description')->nullable();
            $table->string('location_note', 120)->nullable();  // "Block B, ground floor"
            $table->string('phone_extension', 20)->nullable();
            $table->foreignId('head_employee_id')->nullable(); // FK added after employees
            $table->boolean('accepts_appointments')->default(true);
            $table->boolean('accepts_walkins')->default(true);
            $table->boolean('is_system')->default(false);
            $table->boolean('is_active')->default(true)->index();
            $table->unsignedSmallInteger('display_order')->default(0);
            $table->timestamps();
            $table->softDeletes();

            $table->index(['parent_id', 'display_order']);
            $table->index('kind');
        });
    }

    public function down(): void { Schema::dropIfExists('departments'); }
};
