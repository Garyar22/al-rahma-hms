<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* The billing catalogue (FR-BIL-01). Every chargeable thing resolves to a
 | service, so "revenue by service" and "revenue by department" are answerable
 | without special-casing each module. requires_prepayment supports the
 | pay-before-service mode per category. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('services', function (Blueprint $table) {
            $table->id();
            $table->string('code', 30)->unique();
            $table->string('name');
            $table->string('category', 20)->index(); // consultation|laboratory|pharmacy|procedure|bed|other
            $table->foreignId('department_id')->nullable()->constrained('departments')->nullOnDelete();
            $table->decimal('price', 12, 2)->default(0);
            $table->string('currency', 3)->default('USD');
            $table->boolean('requires_prepayment')->nullable(); // null = follow hospital default
            $table->boolean('is_active')->default(true)->index();
            $table->text('description')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void { Schema::dropIfExists('services'); }
};
