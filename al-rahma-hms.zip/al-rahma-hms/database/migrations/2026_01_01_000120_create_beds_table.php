<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('beds', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ward_id')->constrained('wards')->restrictOnDelete();
            $table->string('bed_number', 20);
            $table->string('status', 15)->default('available')->index(); // available|occupied|reserved|cleaning|maintenance
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->unique(['ward_id', 'bed_number']);
        });
    }

    public function down(): void { Schema::dropIfExists('beds'); }
};
