<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

/* Cached quantity per batch per location (Blueprint D4). The ledger is the
 | truth; this is the fast lookup, written ONLY by StockLedger inside a locked
 | transaction. The CHECK constraint is the last line of defence behind the
 | service-level check: stock can never go negative (mandatory rule §49.3). */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('stock_balances', function (Blueprint $table) {
            $table->id();
            $table->foreignId('item_id')->constrained('items')->restrictOnDelete();
            $table->foreignId('batch_id')->nullable()->constrained('item_batches')->restrictOnDelete();
            $table->foreignId('location_id')->constrained('stock_locations')->restrictOnDelete();
            $table->decimal('quantity', 14, 2)->default(0);
            $table->timestamp('updated_at')->nullable();
            $table->unique(['item_id', 'batch_id', 'location_id']);
            $table->index(['location_id', 'item_id']);
        });

        if (in_array(DB::getDriverName(), ['mysql', 'mariadb'], true)) {
            DB::statement('ALTER TABLE stock_balances ADD CONSTRAINT chk_stock_non_negative CHECK (quantity >= 0)');
        }
    }

    public function down(): void { Schema::dropIfExists('stock_balances'); }
};
