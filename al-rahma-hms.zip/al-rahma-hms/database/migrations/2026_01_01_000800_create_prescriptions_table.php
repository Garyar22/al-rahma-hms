<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* status 'external' on an item means the patient buys it outside: no stock
 | movement and no charge, but the prescription record stays complete — which
 | is the difference between an accurate medication history and a misleading
 | one. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('prescriptions', function (Blueprint $table) {
            $table->id();
            $table->string('prescription_number', 30)->unique();
            $table->foreignId('visit_id')->constrained('visits')->restrictOnDelete();
            $table->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $table->foreignId('doctor_id')->constrained('doctors')->restrictOnDelete();
            $table->string('status', 22)->default('pending')->index(); // pending|partially_dispensed|dispensed|cancelled
            $table->text('notes')->nullable();
            $table->foreignId('cancelled_by')->nullable()->constrained('users')->nullOnDelete();
            $table->text('cancellation_reason')->nullable();
            $table->timestamps();
            $table->index(['patient_id', 'created_at']);
        });

        Schema::create('prescription_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('prescription_id')->constrained('prescriptions')->cascadeOnDelete();
            $table->foreignId('item_id')->constrained('items')->restrictOnDelete();
            $table->string('dose', 60);
            $table->string('frequency', 60);
            $table->string('route', 30)->nullable();
            $table->unsignedSmallInteger('duration_days')->nullable();
            $table->decimal('quantity_prescribed', 12, 2);
            $table->decimal('quantity_dispensed', 12, 2)->default(0);
            $table->string('instructions')->nullable();
            $table->string('status', 12)->default('pending'); // pending|partial|dispensed|cancelled|external
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('prescription_items');
        Schema::dropIfExists('prescriptions');
    }
};
