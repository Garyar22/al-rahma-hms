<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | APPOINTMENTS — and the mechanism that makes double booking IMPOSSIBLE.
 |
 | slot_lock holds the scheduled start while the appointment is active and
 | NULL once it is cancelled or marked no-show. A UNIQUE index on
 | (doctor_id, slot_lock) therefore permits exactly one ACTIVE appointment per
 | doctor per slot while allowing any number of cancelled ones, because MySQL
 | and MariaDB treat NULLs as distinct in a unique index.
 |
 | This matters because an application-level "is the slot free?" check loses
 | races: two receptionists clicking Save in the same second both see a free
 | slot and both writes succeed. Mandatory rule §49.4 says double booking must
 | never happen, and only the database can actually promise that. The app
 | still pre-checks so the user gets a clear message instead of a constraint
 | violation — but the constraint is the guarantee, not the check.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('appointments', function (Blueprint $table) {
            $table->id();
            $table->string('appointment_number', 30)->unique();
            $table->foreignId('patient_id')->constrained('patients')->restrictOnDelete();
            $table->foreignId('doctor_id')->constrained('doctors')->restrictOnDelete();
            $table->foreignId('department_id')->constrained('departments')->restrictOnDelete();
            $table->dateTime('scheduled_start');
            $table->dateTime('scheduled_end');
            $table->dateTime('slot_lock')->nullable();
            $table->string('status', 12)->default('scheduled')->index();
            $table->string('reason')->nullable();
            $table->text('notes')->nullable();
            $table->timestamp('checked_in_at')->nullable();
            $table->foreignId('visit_id')->nullable()->constrained('visits')->nullOnDelete();
            $table->foreignId('cancelled_by')->nullable()->constrained('users')->nullOnDelete();
            $table->text('cancellation_reason')->nullable();
            $table->foreignId('created_by')->constrained('users')->restrictOnDelete();
            $table->timestamps();

            // THE guarantee (FR-APT-02, mandatory rule §49.4)
            $table->unique(['doctor_id', 'slot_lock'], 'appointments_doctor_slot_unique');

            $table->index(['doctor_id', 'scheduled_start']);
            $table->index(['department_id', 'scheduled_start']);
            $table->index(['patient_id', 'scheduled_start']);
        });
    }

    public function down(): void { Schema::dropIfExists('appointments'); }
};
