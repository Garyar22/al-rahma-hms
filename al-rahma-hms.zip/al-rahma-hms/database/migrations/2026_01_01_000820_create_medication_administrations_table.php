<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Medication administration record for inpatients (FR-NUR-02). "Held",
 | "refused" and "missed" are recorded explicitly, because a blank is
 | ambiguous and a blank in a drug chart is a safety problem. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('medication_administrations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('admission_id')->constrained('admissions')->restrictOnDelete();
            $table->foreignId('prescription_item_id')->nullable()->constrained('prescription_items')->nullOnDelete();
            $table->foreignId('item_id')->constrained('items')->restrictOnDelete();
            $table->string('dose', 60);
            $table->string('route', 30)->nullable();
            $table->timestamp('scheduled_at')->index();
            $table->timestamp('administered_at')->nullable();
            $table->string('status', 12)->default('scheduled'); // scheduled|given|held|refused|missed
            $table->foreignId('administered_by')->nullable()->constrained('users')->nullOnDelete();
            $table->string('reason')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->index(['admission_id', 'scheduled_at']);
        });
    }

    public function down(): void { Schema::dropIfExists('medication_administrations'); }
};
