<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/*
 | PATIENTS — the identity backbone of the whole system.
 |
 | Decisions specific to this hospital (Blueprint A4/A5):
 |
 | 1. Three name parts, because Somali names are given + father + grandfather.
 |    One "full name" string makes searching by father's name — the normal way
 |    staff disambiguate two patients — impossible.
 | 2. name_normalized is a transliteration-folded key so Maxamed / Mohamed /
 |    Mohammed / Muhammad match one another. Written by NameNormalizer,
 |    indexed, never displayed.
 | 3. date_of_birth is NULLABLE with dob_accuracy. Many patients do not know
 |    their birth date; storing a guessed 1 January silently corrupts every
 |    age-based report and paediatric reference range. An estimated age is an
 |    honest value, a fake exact date is not.
 | 4. phone is indexed but NOT unique: families share one phone.
 | 5. is_unidentified supports "Unknown male ~40" in Emergency (FR-EMG-01),
 |    completed later without creating a second record.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('patients', function (Blueprint $table) {
            $table->id();
            $table->string('patient_number', 30)->unique();

            $table->string('first_name', 60);
            $table->string('middle_name', 60)->nullable();
            $table->string('last_name', 60)->nullable();
            $table->string('name_normalized', 190);
            $table->string('name_soundex', 60)->nullable();

            $table->string('gender', 10);

            $table->date('date_of_birth')->nullable();
            $table->string('dob_accuracy', 10)->default('estimated'); // exact|year|estimated
            $table->unsignedSmallInteger('birth_year')->nullable();
            $table->unsignedSmallInteger('age_at_registration')->nullable();

            $table->string('phone', 25)->nullable();
            $table->string('phone_alt', 25)->nullable();
            $table->string('address_line')->nullable();
            $table->string('district', 80)->nullable();
            $table->string('city', 80)->default('Qardho');

            $table->string('blood_group', 5)->nullable();
            $table->string('marital_status', 15)->nullable();
            $table->string('occupation', 80)->nullable();

            $table->string('next_of_kin_name')->nullable();
            $table->string('next_of_kin_phone', 25)->nullable();
            $table->string('next_of_kin_relation', 40)->nullable();

            $table->string('status', 10)->default('active')->index(); // active|inactive|deceased|merged
            $table->foreignId('merged_into_patient_id')->nullable()->constrained('patients')->nullOnDelete();
            $table->boolean('is_unidentified')->default(false);

            $table->timestamp('registered_at');
            $table->foreignId('registered_by')->constrained('users')->restrictOnDelete();
            $table->text('notes')->nullable();

            $table->timestamps();
            $table->softDeletes();

            $table->index('name_normalized');
            $table->index(['last_name', 'first_name']);
            $table->index('phone');
            $table->index('registered_at');
        });

        $offset = (int) config('hospital.utc_offset_hours', 3);
        if (in_array(Schema::getConnection()->getDriverName(), ['mysql', 'mariadb'], true)) {
            Schema::table('patients', function (Blueprint $table) use ($offset) {
                $table->date('business_date')
                    ->storedAs("DATE(registered_at + INTERVAL {$offset} HOUR)")
                    ->after('registered_at');
                $table->index('business_date');
            });
        }
    }

    public function down(): void { Schema::dropIfExists('patients'); }
};
