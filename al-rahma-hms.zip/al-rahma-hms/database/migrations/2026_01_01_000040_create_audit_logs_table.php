<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Audit trail (FR-SEC-04/05, Blueprint D12). INSERT ONLY — there is no update
 | or delete path in the application and the production DB user holds only
 | INSERT, SELECT here. Clinical free text is never diffed into old/new values,
 | only the NAMES of changed fields, so this table never becomes a second,
 | less-protected copy of the medical record.
 |
 | user_name_snapshot/role_snapshot are stored because users get renamed,
 | deactivated and re-roled; the audit must still read correctly years later. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('audit_logs', function (Blueprint $table) {
            $table->id();
            $table->timestamp('occurred_at')->index();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('user_name_snapshot')->nullable();
            $table->string('role_snapshot')->nullable();
            $table->string('action', 60);
            $table->string('module', 40);
            $table->string('auditable_type')->nullable();
            $table->unsignedBigInteger('auditable_id')->nullable();
            $table->json('changed_fields')->nullable();
            $table->json('old_values')->nullable();
            $table->json('new_values')->nullable();
            $table->json('context')->nullable();
            $table->text('reason')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->string('user_agent', 255)->nullable();
            $table->index(['auditable_type', 'auditable_id']);
            $table->index(['user_id', 'occurred_at']);
            $table->index(['module', 'action', 'occurred_at']);
        });
    }

    public function down(): void { Schema::dropIfExists('audit_logs'); }
};
