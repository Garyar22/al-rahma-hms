<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/* Added after appointments exists: an appointment produces a visit at
 | check-in, and a visit records which appointment it came from. */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('visits', function (Blueprint $table) {
            $table->foreignId('appointment_id')->nullable()->after('doctor_id')
                ->constrained('appointments')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('visits', fn (Blueprint $t) => $t->dropConstrainedForeignId('appointment_id'));
    }
};
