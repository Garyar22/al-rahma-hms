<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Seeder;

/**
 * Order matters, and each step depends on the one before it:
 *
 *  1. Settings      — everything else reads hospital identity and prefixes from here.
 *  2. Branding      — installs the hospital logo against the branding.* settings keys.
 *  3. Sequences     — document-number counters, built from the numbering.* prefixes.
 *  4. Roles         — permissions must exist before any user can be given a role.
 *  5. Sectors       — departments, wards, beds and stock locations.
 *  6. Catalogue     — units, categories, payment methods and services (needs departments).
 *  7. Lab catalogue — tests, parameters and reference ranges.
 *  8. System Owner  — the hospital's own account; needs the system-owner role to exist.
 *
 * Every seeder is idempotent, so running this again after adding new reference
 * data inserts only what is missing and never resets configured values.
 */
class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            SettingSeeder::class,
            BrandingSeeder::class,
            SequenceSeeder::class,
            RolePermissionSeeder::class,
            SectorSeeder::class,
            CatalogueSeeder::class,
            LabCatalogueSeeder::class,
            SystemOwnerSeeder::class,
        ]);

        // Demo data never touches production (project instruction §41:
        // clearly fake data only, and never real patient information).
        if (! app()->environment('production')) {
            // DemoStaffSeeder::class, DemoPatientSeeder::class, DemoStockSeeder::class
        }
    }
}
