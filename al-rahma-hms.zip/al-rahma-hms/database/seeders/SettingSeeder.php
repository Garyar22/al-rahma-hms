<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

/**
 * Seeds every value an administrator may change without a developer (Rule 11).
 *
 * updateOrCreate on `key` keeps this idempotent: re-running after a new setting
 * is added inserts only the new row and never resets what the hospital has
 * already configured.
 *
 * Brand colours are recorded here, not only in CSS, because printed documents
 * are rendered server-side and need the same values.
 */
class SettingSeeder extends Seeder
{
    public function run(): void
    {
        foreach ($this->settings() as $row) {
            $setting = Setting::query()->firstOrNew(['key' => $row['key']]);

            // Metadata is always refreshed so new labels and descriptions appear.
            $setting->group                 = $row['group'];
            $setting->type                  = $row['type'] ?? 'string';
            $setting->label                 = $row['label'];
            $setting->description           = $row['description'] ?? null;
            $setting->is_security_sensitive = $row['secure'] ?? false;

            // The VALUE is only written on first install: re-seeding must never
            // reset what the hospital has configured.
            if (! $setting->exists) {
                $setting->value = $row['value'];
            }

            $setting->save();
        }

        $this->command?->info('Hospital settings seeded.');
    }

    /** @return array<int,array<string,mixed>> */
    private function settings(): array
    {
        return [
            // ---- Hospital identity -------------------------------------------------
            ['group' => 'hospital', 'key' => 'hospital.name', 'value' => 'Al Rahma Hospital', 'label' => 'Hospital name'],
            ['group' => 'hospital', 'key' => 'hospital.legal_name', 'value' => 'Al Rahma Hospital', 'label' => 'Registered name'],
            ['group' => 'hospital', 'key' => 'hospital.address', 'value' => 'Qardho Main Road', 'label' => 'Street address'],
            ['group' => 'hospital', 'key' => 'hospital.city', 'value' => 'Qardho', 'label' => 'City'],
            ['group' => 'hospital', 'key' => 'hospital.region', 'value' => 'Bari, Puntland', 'label' => 'Region'],
            ['group' => 'hospital', 'key' => 'hospital.country', 'value' => 'Somalia', 'label' => 'Country'],
            ['group' => 'hospital', 'key' => 'hospital.phone', 'value' => '', 'label' => 'Telephone', 'description' => 'Printed on every receipt and report. Set this before go-live.'],
            ['group' => 'hospital', 'key' => 'hospital.phone_alt', 'value' => '', 'label' => 'Alternative telephone'],
            ['group' => 'hospital', 'key' => 'hospital.email', 'value' => '', 'label' => 'Email address'],
            ['group' => 'hospital', 'key' => 'hospital.website', 'value' => '', 'label' => 'Website'],

            // ---- Locale and money --------------------------------------------------
            ['group' => 'locale', 'key' => 'hospital.currency', 'value' => 'USD', 'label' => 'Currency code'],
            ['group' => 'locale', 'key' => 'hospital.currency_symbol', 'value' => '$', 'label' => 'Currency symbol'],
            ['group' => 'locale', 'key' => 'hospital.timezone', 'value' => 'Africa/Mogadishu', 'label' => 'Timezone', 'secure' => true,
             'description' => 'Report day boundaries depend on this. Changing it requires a migration that rebuilds generated business_date columns.'],
            ['group' => 'locale', 'key' => 'hospital.date_format', 'value' => 'd/m/Y', 'label' => 'Date format'],
            ['group' => 'locale', 'key' => 'hospital.datetime_format', 'value' => 'd/m/Y H:i', 'label' => 'Date and time format'],
            ['group' => 'locale', 'key' => 'hospital.locale', 'value' => 'en', 'label' => 'Interface language', 'description' => 'English at launch; so and ar can be added without code changes.'],

            // ---- Branding ----------------------------------------------------------
            ['group' => 'branding', 'key' => 'branding.logo_path', 'value' => 'branding/logo.png', 'label' => 'Hospital logo', 'description' => 'Colour logo on a transparent background. Used on screen and on printed letterhead.'],
            ['group' => 'branding', 'key' => 'branding.logo_white_path', 'value' => 'branding/logo-white.png', 'label' => 'Logo (knock-out)', 'description' => 'White version for dark headers and sidebars.'],
            ['group' => 'branding', 'key' => 'branding.mark_path', 'value' => 'branding/mark.png', 'label' => 'Logo mark', 'description' => 'Emblem without the wordmark, for the collapsed sidebar and small spaces.'],
            ['group' => 'branding', 'key' => 'branding.receipt_logo_path', 'value' => 'branding/logo-receipt.png', 'label' => 'Receipt logo (thermal)', 'description' => '1-bit silhouette for 80mm thermal printers.'],
            ['group' => 'branding', 'key' => 'branding.receipt_logo_narrow_path', 'value' => 'branding/logo-receipt-narrow.png', 'label' => 'Receipt logo (58mm)'],

            // Taken from the hospital's own logo artwork.
            ['group' => 'branding', 'key' => 'branding.color_primary', 'value' => '#01AFEE', 'label' => 'Primary colour', 'description' => 'Brand blue, sampled from the logo. Decorative fills and headers only; it fails contrast rules for small text.'],
            ['group' => 'branding', 'key' => 'branding.color_secondary', 'value' => '#6DBC45', 'label' => 'Secondary colour', 'description' => 'Brand green, sampled from the logo.'],
            ['group' => 'branding', 'key' => 'branding.color_primary_text', 'value' => '#0B6E96', 'label' => 'Primary colour (text-safe)', 'description' => 'Darkened brand blue that passes WCAG AA against white for body text and buttons.'],
            ['group' => 'branding', 'key' => 'branding.color_secondary_text', 'value' => '#3D7A24', 'label' => 'Secondary colour (text-safe)'],
            ['group' => 'branding', 'key' => 'branding.color_ink', 'value' => '#10212B', 'label' => 'Text colour'],

            // ---- Reports and documents ---------------------------------------------
            ['group' => 'reports', 'key' => 'report.header_line1', 'value' => 'AL RAHMA HOSPITAL', 'label' => 'Report header line 1'],
            ['group' => 'reports', 'key' => 'report.header_line2', 'value' => 'Qardho Main Road, Qardho, Somalia', 'label' => 'Report header line 2'],
            ['group' => 'reports', 'key' => 'report.footer_note', 'value' => 'This report was generated from hospital records.', 'label' => 'Report footer note'],
            ['group' => 'reports', 'key' => 'report.show_logo', 'value' => '1', 'type' => 'bool', 'label' => 'Show logo on reports'],

            ['group' => 'receipts', 'key' => 'receipt.paper', 'value' => 'a4', 'label' => 'Receipt paper', 'description' => 'a4 | thermal80 | thermal58. Determines which logo variant and layout is used.'],
            ['group' => 'receipts', 'key' => 'receipt.thank_you_message', 'value' => 'Thank you for choosing Al Rahma Hospital', 'label' => 'Receipt thank-you message'],
            ['group' => 'receipts', 'key' => 'receipt.show_logo', 'value' => '1', 'type' => 'bool', 'label' => 'Show logo on receipts'],

            // ---- Document numbering -------------------------------------------------
            ['group' => 'numbering', 'key' => 'numbering.patient_prefix', 'value' => 'ARH-P-', 'label' => 'Patient number prefix'],
            ['group' => 'numbering', 'key' => 'numbering.visit_prefix', 'value' => 'ARH-VST-', 'label' => 'Visit number prefix'],
            ['group' => 'numbering', 'key' => 'numbering.appointment_prefix', 'value' => 'ARH-APT-', 'label' => 'Appointment number prefix'],
            ['group' => 'numbering', 'key' => 'numbering.admission_prefix', 'value' => 'ARH-ADM-', 'label' => 'Admission number prefix'],
            ['group' => 'numbering', 'key' => 'numbering.prescription_prefix', 'value' => 'ARH-RX-', 'label' => 'Prescription number prefix'],
            ['group' => 'numbering', 'key' => 'numbering.lab_request_prefix', 'value' => 'ARH-LAB-', 'label' => 'Laboratory request prefix'],
            ['group' => 'numbering', 'key' => 'numbering.invoice_prefix', 'value' => 'ARH-INV-', 'label' => 'Invoice number prefix'],
            ['group' => 'numbering', 'key' => 'numbering.receipt_prefix', 'value' => 'ARH-REC-', 'label' => 'Receipt number prefix'],
            ['group' => 'numbering', 'key' => 'numbering.goods_receipt_prefix', 'value' => 'ARH-GRN-', 'label' => 'Goods receipt prefix'],
            ['group' => 'numbering', 'key' => 'numbering.padding', 'value' => '6', 'type' => 'int', 'label' => 'Number padding'],

            // ---- Billing -------------------------------------------------------------
            ['group' => 'billing', 'key' => 'billing.mode', 'value' => 'pay_before_service', 'label' => 'Billing mode',
             'description' => 'pay_before_service | pay_after_service. Emergency care is never blocked by payment, whatever this is set to.'],
            ['group' => 'billing', 'key' => 'billing.allow_advance_payments', 'value' => '0', 'type' => 'bool', 'label' => 'Allow payments above the outstanding balance'],
            ['group' => 'billing', 'key' => 'billing.discount_approval_percent', 'value' => '10', 'type' => 'int', 'label' => 'Discount approval threshold (%)',
             'description' => 'Discounts above this percentage require approval by someone other than the person applying them.'],

            // ---- Clinical and inventory ----------------------------------------------
            ['group' => 'clinical', 'key' => 'clinical.consultation_edit_grace_minutes', 'value' => '1440', 'type' => 'int', 'label' => 'Consultation edit window (minutes)',
             'description' => 'After this, a finalised consultation can only receive an addendum.'],
            ['group' => 'clinical', 'key' => 'clinical.breakglass_window_minutes', 'value' => '720', 'type' => 'int', 'label' => 'Break-glass access window (minutes)'],
            ['group' => 'clinical', 'key' => 'clinical.allow_self_verification_in_lab', 'value' => '0', 'type' => 'bool', 'label' => 'Allow a technician to verify their own result',
             'description' => 'Open question Q11. Enable only if the hospital runs a single laboratory technician; every such result is flagged.'],
            ['group' => 'inventory', 'key' => 'inventory.expiry_warning_days', 'value' => '90', 'type' => 'int', 'label' => 'Expiry warning window (days)'],
            ['group' => 'inventory', 'key' => 'inventory.block_expired_dispensing', 'value' => '1', 'type' => 'bool', 'label' => 'Block dispensing from expired batches'],

            // ---- Security --------------------------------------------------------------
            ['group' => 'security', 'key' => 'security.session_timeout_minutes', 'value' => '30', 'type' => 'int', 'label' => 'Idle session timeout (minutes)', 'secure' => true],
            ['group' => 'security', 'key' => 'security.max_failed_logins', 'value' => '5', 'type' => 'int', 'label' => 'Failed logins before lockout', 'secure' => true],
            ['group' => 'security', 'key' => 'security.lockout_minutes', 'value' => '15', 'type' => 'int', 'label' => 'Lockout duration (minutes)', 'secure' => true],
        ];
    }
}
