<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

/**
 * Creates the hospital's System Owner account.
 *
 * This is the account that belongs to the hospital itself — the proprietor or
 * their nominated administrator. It holds every permission, including the
 * ability to create and remove all other users, manage sectors, and change
 * settings.
 *
 * Security rules applied here, deliberately:
 *
 *  1. NO fixed default password exists anywhere in this repository. A strong
 *     random password is generated and printed to the console ONCE. If it is
 *     lost, the owner resets it with `php artisan hms:reset-owner-password` —
 *     there is no "admin/admin123" waiting in the source code for anyone who
 *     clones it.
 *  2. must_change_password is set, so the real password is chosen by the
 *     human on first login and never known to the installer.
 *  3. is_protected prevents this account from being deleted, deactivated or
 *     stripped of its role through the UI, so the hospital cannot lock itself
 *     out of its own system.
 */
class SystemOwnerSeeder extends Seeder
{
    public function run(): void
    {
        $username = (string) env('HOSPITAL_OWNER_USERNAME', 'owner');

        if (User::query()->where('username', $username)->exists()) {
            $this->command?->warn("System Owner '{$username}' already exists — left untouched.");

            return;
        }

        $password = Str::password(16, symbols: false);

        $owner = User::query()->create([
            'name'                 => (string) env('HOSPITAL_OWNER_NAME', 'Hospital Owner'),
            'username'             => $username,
            'email'                => env('HOSPITAL_OWNER_EMAIL'),
            'password'             => $password,
            'is_active'            => true,
            'is_protected'         => true,
            'must_change_password' => true,
        ]);

        $owner->assignRole('system-owner');

        $this->command?->newLine();
        $this->command?->warn('=========================================================');
        $this->command?->warn('  AL RAHMA HOSPITAL — SYSTEM OWNER ACCOUNT CREATED');
        $this->command?->warn('=========================================================');
        $this->command?->line("  Username : {$username}");
        $this->command?->line("  Password : {$password}");
        $this->command?->newLine();
        $this->command?->warn('  Write this down now. It is shown once and is not stored');
        $this->command?->warn('  anywhere in readable form. You must change it at first login.');
        $this->command?->warn('=========================================================');
        $this->command?->newLine();
    }
}
