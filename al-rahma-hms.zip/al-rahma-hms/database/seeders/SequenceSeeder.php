<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Sequence;
use App\Services\Shared\SettingsRepository;
use Illuminate\Database\Seeder;

/**
 * Creates the document-number counters (Blueprint D6).
 *
 * Prefixes are read from settings so that an administrator who changes
 * "ARH-INV-" in Hospital Settings changes it in exactly one place.
 *
 * Patient, visit and admission numbers never reset: a patient number is a
 * permanent identifier printed on a card the patient keeps for years.
 * Invoices and receipts reset yearly, which is the convention finance staff
 * expect when filing paper copies.
 */
class SequenceSeeder extends Seeder
{
    public function run(): void
    {
        $settings = app(SettingsRepository::class);
        $padding  = (int) $settings->get('numbering.padding', 6);

        $sequences = [
            ['key' => 'patient',       'setting' => 'numbering.patient_prefix',       'reset' => 'none'],
            ['key' => 'visit',         'setting' => 'numbering.visit_prefix',         'reset' => 'none'],
            ['key' => 'appointment',   'setting' => 'numbering.appointment_prefix',   'reset' => 'yearly'],
            ['key' => 'admission',     'setting' => 'numbering.admission_prefix',     'reset' => 'none'],
            ['key' => 'prescription',  'setting' => 'numbering.prescription_prefix',  'reset' => 'yearly'],
            ['key' => 'lab_request',   'setting' => 'numbering.lab_request_prefix',   'reset' => 'yearly'],
            ['key' => 'invoice',       'setting' => 'numbering.invoice_prefix',       'reset' => 'yearly'],
            ['key' => 'receipt',       'setting' => 'numbering.receipt_prefix',       'reset' => 'yearly'],
            ['key' => 'goods_receipt', 'setting' => 'numbering.goods_receipt_prefix', 'reset' => 'yearly'],
        ];

        foreach ($sequences as $sequence) {
            Sequence::query()->firstOrCreate(
                ['key' => $sequence['key']],
                [
                    'prefix'       => (string) $settings->get($sequence['setting'], 'ARH-'),
                    'next_number'  => 1,
                    'padding'      => $padding,
                    'reset_period' => $sequence['reset'],
                ]
            );
        }

        $this->command?->info('Document number sequences seeded.');
    }
}
