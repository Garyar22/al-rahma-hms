<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

/**
 * Installs Al Rahma Hospital's official logo as the system's initial branding.
 *
 * This is NOT the "temporary hard-coded logo" that the requirements forbid.
 * The file is the hospital's real logo, supplied by the hospital, and it is
 * installed THROUGH the same settings mechanism an administrator uses in
 * Administration -> Hospital Settings -> Hospital Branding. Replacing it later
 * is an upload, not a code change, and nothing in the application references
 * these paths directly: every view reads branding.* from SettingsRepository.
 *
 * Re-running the seeder never overwrites a logo an administrator has uploaded.
 * If branding.logo_path already points at a file that exists, the seeder stops.
 * Losing the hospital's current branding because someone re-ran db:seed would
 * be a real and avoidable annoyance.
 */
class BrandingSeeder extends Seeder
{
    /**
     * Source asset => destination filename under storage/app/public/branding.
     *
     * Variants exist because one PNG cannot serve every surface:
     *  - logo.png                 colour, transparent background: letterhead, light UI
     *  - logo-white.png           knock-out: dark sidebar and header
     *  - mark.png                 emblem only: collapsed sidebar, favicon source
     *  - logo-receipt.png         1-bit silhouette, 384px: 80mm thermal printers
     *  - logo-receipt-narrow.png  1-bit silhouette, 240px: 58mm paper rolls
     *
     * Thermal variants are hard-thresholded, never dithered: a halftone logo
     * prints as a grey smear on receipt paper, a silhouette prints cleanly.
     */
    private const VARIANTS = [
        'al-rahma-logo.png'    => 'logo.png',
        'logo-512.png'         => 'logo-512.png',
        'logo-256.png'         => 'logo-256.png',
        'logo-128.png'         => 'logo-128.png',
        'logo-96.png'          => 'logo-96.png',
        'logo-white-512.png'   => 'logo-white.png',
        'logo-mark.png'        => 'mark.png',
        'mark-512.png'         => 'mark-512.png',
        'mark-192.png'         => 'mark-192.png',
        'mark-64.png'          => 'mark-64.png',
        'logo-receipt-384.png' => 'logo-receipt.png',
        'logo-receipt-240.png' => 'logo-receipt-narrow.png',
    ];

    public function run(): void
    {
        $existing = Setting::query()->where('key', 'branding.logo_path')->value('value');

        if ($existing && Storage::disk('public')->exists($existing)) {
            $this->command?->warn('Branding already installed; leaving the current logo untouched.');

            return;
        }

        $source = database_path('seeders/assets/branding');

        if (! File::isDirectory($source)) {
            $this->command?->error("Branding assets missing at {$source}.");

            return;
        }

        Storage::disk('public')->makeDirectory('branding');

        $installed = 0;

        foreach (self::VARIANTS as $file => $target) {
            $path = $source.DIRECTORY_SEPARATOR.$file;

            if (! File::exists($path)) {
                $this->command?->warn("Skipping missing branding asset: {$file}");

                continue;
            }

            Storage::disk('public')->put('branding/'.$target, File::get($path));
            $installed++;
        }

        // The favicon and touch icon live in the document root, not on the
        // storage disk, because browsers request them before any Laravel route.
        foreach (['favicon.ico', 'apple-touch-icon.png'] as $icon) {
            if (File::exists($source.DIRECTORY_SEPARATOR.$icon)) {
                File::copy($source.DIRECTORY_SEPARATOR.$icon, public_path($icon), true);
            }
        }

        $this->command?->info("Al Rahma Hospital branding installed ({$installed} variants).");
    }
}
