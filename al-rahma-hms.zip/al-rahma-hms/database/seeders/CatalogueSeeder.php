<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Department;
use App\Models\ExpenseCategory;
use App\Models\ItemCategory;
use App\Models\PaymentMethod;
use App\Models\Service;
use App\Models\Unit;
use Illuminate\Database\Seeder;

/** Reference data the hospital edits freely from Administration. */
class CatalogueSeeder extends Seeder
{
    public function run(): void
    {
        foreach ([
            ['tab', 'Tablet'], ['cap', 'Capsule'], ['btl', 'Bottle'], ['vial', 'Vial'],
            ['amp', 'Ampoule'], ['sach', 'Sachet'], ['tube', 'Tube'], ['box', 'Box'],
            ['pc', 'Piece'], ['pkt', 'Packet'], ['ml', 'Millilitre'], ['bag', 'Bag'],
        ] as [$code, $name]) {
            Unit::query()->firstOrCreate(['code' => $code], ['name' => $name]);
        }

        foreach ([
            ['Antibiotics', 'medicine'], ['Analgesics', 'medicine'], ['Antimalarials', 'medicine'],
            ['Antihypertensives', 'medicine'], ['Antidiabetics', 'medicine'], ['Antacids', 'medicine'],
            ['IV Fluids', 'medicine'], ['Vitamins & Supplements', 'medicine'],
            ['Injections', 'medicine'], ['Dressings & Consumables', 'supply'],
            ['Laboratory Reagents', 'supply'], ['Medical Equipment', 'supply'],
            ['Office Supplies', 'supply'], ['Cleaning Supplies', 'supply'],
        ] as [$name, $applies]) {
            ItemCategory::query()->firstOrCreate(['name' => $name], ['applies_to' => $applies]);
        }

        // Mobile money is how most patients in Qardho actually pay.
        foreach ([
            ['cash', 'Cash', false, true, 1],
            ['evc', 'EVC Plus', true, false, 2],
            ['edahab', 'eDahab', true, false, 3],
            ['bank', 'Bank Transfer', true, false, 4],
            ['waiver', 'Waiver / Charity', true, false, 5],
        ] as [$code, $name, $reference, $isCash, $order]) {
            PaymentMethod::query()->firstOrCreate(
                ['code' => $code],
                ['name' => $name, 'requires_reference' => $reference, 'is_cash' => $isCash, 'display_order' => $order]
            );
        }

        foreach ([
            'Salaries & Wages', 'Rent', 'Electricity & Generator Fuel', 'Water',
            'Medical Supplies Purchase', 'Equipment & Maintenance', 'Transport',
            'Communication & Internet', 'Cleaning & Sanitation', 'Government Fees',
            'Other Expenses',
        ] as $name) {
            ExpenseCategory::query()->firstOrCreate(['name' => $name]);
        }

        $opd = Department::query()->where('code', 'OPD')->value('id');
        $emg = Department::query()->where('code', 'EMG')->value('id');
        $ipd = Department::query()->where('code', 'IPD')->value('id');

        foreach ([
            ['CONS-GEN',  'General Consultation',    'consultation', $opd, 5.00],
            ['CONS-SPEC', 'Specialist Consultation', 'consultation', $opd, 10.00],
            ['CONS-FUP',  'Follow-up Consultation',  'consultation', $opd, 2.00],
            ['CONS-EMG',  'Emergency Consultation',  'consultation', $emg, 10.00],
            ['PROC-INJ',  'Injection',               'procedure',    $opd, 2.00],
            ['PROC-DRES', 'Wound Dressing',          'procedure',    $opd, 3.00],
            ['PROC-SUT',  'Suturing',                'procedure',    $emg, 15.00],
            ['PROC-NEB',  'Nebulisation',            'procedure',    $opd, 5.00],
            ['BED-GEN',   'General Ward Bed (per day)', 'bed',       $ipd, 15.00],
            ['BED-MAT',   'Maternity Bed (per day)',   'bed',        $ipd, 20.00],
        ] as [$code, $name, $category, $departmentId, $price]) {
            Service::query()->firstOrCreate(
                ['code' => $code],
                ['name' => $name, 'category' => $category, 'department_id' => $departmentId, 'price' => $price]
            );
        }
    }
}
