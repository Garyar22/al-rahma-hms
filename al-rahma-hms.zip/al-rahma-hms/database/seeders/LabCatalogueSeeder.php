<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\LabTest;
use App\Models\LabTestCategory;
use App\Models\LabTestParameter;
use Illuminate\Database\Seeder;

/**
 * A realistic starting catalogue for a small hospital in Puntland — malaria,
 * typhoid, urinalysis, CBC, basic chemistry and screening — rather than a
 * reference-lab menu the hospital cannot run.
 *
 * Reference ranges are seeded with sex and age applicability where it matters
 * clinically (haemoglobin, haematocrit), because a single adult-male range
 * flags healthy women and children as abnormal every single day, and staff
 * quickly learn to ignore the flag altogether.
 */
class LabCatalogueSeeder extends Seeder
{
    public function run(): void
    {
        $haematology = LabTestCategory::query()->firstOrCreate(['name' => 'Haematology'], ['display_order' => 1]);
        $chemistry   = LabTestCategory::query()->firstOrCreate(['name' => 'Clinical Chemistry'], ['display_order' => 2]);
        $micro       = LabTestCategory::query()->firstOrCreate(['name' => 'Microbiology & Parasitology'], ['display_order' => 3]);
        $serology    = LabTestCategory::query()->firstOrCreate(['name' => 'Serology & Rapid Tests'], ['display_order' => 4]);

        $cbc = $this->test('CBC', 'Complete Blood Count', $haematology, 'Whole blood (EDTA)', 6.00, 2);
        $this->parameters($cbc, [
            ['WBC', '10^9/L', 4.0, 11.0, 'any', null, null, 1.5, 30.0],
            ['RBC', '10^12/L', 4.2, 5.9, 'any', null, null, null, null],
            ['Haemoglobin', 'g/dL', 13.0, 17.0, 'male', 15, null, 7.0, null],
            ['Haemoglobin', 'g/dL', 12.0, 15.0, 'female', 15, null, 7.0, null],
            ['Haemoglobin', 'g/dL', 11.0, 14.0, 'any', 0, 14, 7.0, null],
            ['Haematocrit', '%', 40.0, 52.0, 'male', 15, null, null, null],
            ['Haematocrit', '%', 36.0, 46.0, 'female', 15, null, null, null],
            ['Platelets', '10^9/L', 150.0, 450.0, 'any', null, null, 50.0, null],
        ]);

        $this->simple('MPS', 'Malaria Parasite Smear', $micro, 'Whole blood', 3.00, 1, 'Result', ['Negative', 'P. falciparum', 'P. vivax', 'P. malariae', 'Mixed']);
        $this->simple('MRDT', 'Malaria Rapid Test', $micro, 'Whole blood', 2.00, 1, 'Result', ['Negative', 'Positive']);
        $this->simple('WIDAL', 'Widal Test (Typhoid)', $serology, 'Serum', 4.00, 3, 'Result', ['Negative', 'Reactive 1:80', 'Reactive 1:160', 'Reactive 1:320']);
        $this->simple('PREG', 'Pregnancy Test (hCG)', $serology, 'Urine', 2.00, 1, 'Result', ['Negative', 'Positive']);
        $this->simple('HIV', 'HIV Screening', $serology, 'Serum', 3.00, 2, 'Result', ['Non-reactive', 'Reactive']);
        $this->simple('HBSAG', 'Hepatitis B Surface Antigen', $serology, 'Serum', 4.00, 2, 'Result', ['Negative', 'Positive']);
        $this->simple('BG', 'Blood Group & Rh', $haematology, 'Whole blood (EDTA)', 3.00, 1, 'Group', ['O+', 'O-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-']);

        $urine = $this->test('URIN', 'Urinalysis', $micro, 'Urine', 3.00, 1);
        $this->parameters($urine, [
            ['Protein', null, null, null, 'any', null, null, null, null, 'Negative'],
            ['Glucose', null, null, null, 'any', null, null, null, null, 'Negative'],
            ['Pus cells', '/HPF', 0.0, 5.0, 'any', null, null, null, null],
            ['RBC', '/HPF', 0.0, 2.0, 'any', null, null, null, null],
        ]);

        $rbs = $this->test('RBS', 'Random Blood Sugar', $chemistry, 'Serum/Plasma', 2.00, 1);
        $this->parameters($rbs, [
            ['Glucose', 'mmol/L', 3.9, 7.8, 'any', null, null, 2.5, 25.0],
        ]);

        $rft = $this->test('RFT', 'Renal Function Test', $chemistry, 'Serum', 10.00, 6);
        $this->parameters($rft, [
            ['Urea', 'mmol/L', 2.5, 7.1, 'any', null, null, null, 30.0],
            ['Creatinine', 'umol/L', 62.0, 106.0, 'male', 15, null, null, 500.0],
            ['Creatinine', 'umol/L', 44.0, 80.0, 'female', 15, null, null, 500.0],
        ]);

        $lft = $this->test('LFT', 'Liver Function Test', $chemistry, 'Serum', 12.00, 6);
        $this->parameters($lft, [
            ['ALT', 'U/L', 7.0, 56.0, 'any', null, null, null, null],
            ['AST', 'U/L', 10.0, 40.0, 'any', null, null, null, null],
            ['Total Bilirubin', 'umol/L', 3.0, 20.0, 'any', null, null, null, null],
        ]);

        $this->simple('STOOL', 'Stool Analysis', $micro, 'Stool', 3.00, 2, 'Findings', ['No ova or parasites seen', 'Entamoeba histolytica', 'Giardia lamblia', 'Ascaris lumbricoides', 'Hookworm', 'Other']);
        $this->simple('ESR', 'Erythrocyte Sedimentation Rate', $haematology, 'Whole blood (citrate)', 2.00, 2, 'ESR (mm/hr)', null);
    }

    private function test(string $code, string $name, LabTestCategory $category, string $sample, float $price, int $hours): LabTest
    {
        return LabTest::query()->firstOrCreate(
            ['code' => $code],
            [
                'name'             => $name,
                'category_id'      => $category->id,
                'sample_type'      => $sample,
                'turnaround_hours' => $hours,
                'price'            => $price,
                'has_parameters'   => true,
            ]
        );
    }

    private function simple(string $code, string $name, LabTestCategory $category, string $sample, float $price, int $hours, string $parameter, ?array $options): void
    {
        $test = $this->test($code, $name, $category, $sample, $price, $hours);

        LabTestParameter::query()->firstOrCreate(
            ['lab_test_id' => $test->id, 'name' => $parameter],
            [
                'result_type' => $options ? 'option' : 'numeric',
                'options'     => $options,
                'ref_text'    => $options ? ($options[0] ?? null) : null,
            ]
        );
    }

    private function parameters(LabTest $test, array $rows): void
    {
        foreach ($rows as $order => $row) {
            [$name, $unit, $low, $high, $sex, $ageMin, $ageMax, $critLow, $critHigh] = array_pad($row, 9, null);
            $refText = $row[9] ?? null;

            LabTestParameter::query()->firstOrCreate(
                ['lab_test_id' => $test->id, 'name' => $name, 'sex_applicability' => $sex, 'age_min_years' => $ageMin],
                [
                    'unit'          => $unit,
                    'result_type'   => $refText ? 'text' : 'numeric',
                    'ref_low'       => $low,
                    'ref_high'      => $high,
                    'ref_text'      => $refText,
                    'critical_low'  => $critLow,
                    'critical_high' => $critHigh,
                    'age_max_years' => $ageMax,
                    'display_order' => $order,
                ]
            );
        }
    }
}
