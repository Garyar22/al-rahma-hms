<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\App;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

/**
 * The authorisation contract for the whole system (Blueprint Part 3).
 *
 * This seeder is IDEMPOTENT: it can be re-run after adding a permission
 * without disturbing the roles a hospital has customised. Permissions are
 * created here and nowhere else — a permission invented inside a controller
 * is invisible to the role screen and therefore ungovernable.
 *
 * No role name is ever hard-coded in a condition anywhere in the codebase.
 * Code asks can('patients.record.create'), never hasRole('receptionist').
 * Roles change over a hospital's life; permissions are the stable contract.
 */
class RolePermissionSeeder extends Seeder
{
    /** @var array<string, array<int,string>> */
    public const PERMISSIONS = [
        'patients' => [
            'patients.record.view', 'patients.record.create', 'patients.record.edit',
            'patients.record.merge', 'patients.record.deactivate', 'patients.clinical.view',
            'patients.allergy.manage', 'patients.record.export', 'patients.record.print',
        ],
        'appointments' => [
            'appointments.booking.view', 'appointments.booking.create', 'appointments.booking.edit',
            'appointments.booking.cancel', 'appointments.booking.checkin', 'appointments.schedule.manage',
        ],
        'visits' => [
            'visits.visit.view', 'visits.visit.create', 'visits.visit.cancel',
            'visits.queue.view', 'visits.queue.manage',
        ],
        'clinical' => [
            'clinical.consultation.view', 'clinical.consultation.create', 'clinical.consultation.edit',
            'clinical.consultation.addendum', 'clinical.diagnosis.manage', 'clinical.note.create',
            'clinical.record.breakglass', 'clinical.document.print',
            'vitals.record.view', 'vitals.record.create', 'nursing.mar.administer',
        ],
        'inpatient' => [
            'ipd.admission.view', 'ipd.admission.create', 'ipd.bed.assign', 'ipd.bed.manage',
            'ipd.admission.transfer', 'ipd.discharge.process', 'ipd.discharge.override_balance',
        ],
        'emergency' => [
            'emergency.case.view', 'emergency.case.create', 'emergency.case.triage',
            'emergency.case.disposition',
        ],
        'pharmacy' => [
            'prescriptions.prescription.view', 'prescriptions.prescription.create',
            'prescriptions.prescription.cancel', 'prescriptions.prescription.print',
            'pharmacy.dispense.process', 'pharmacy.dispense.reverse', 'pharmacy.stock.view',
            'pharmacy.stock.receive', 'pharmacy.stock.adjust', 'pharmacy.stock.dispose',
        ],
        'laboratory' => [
            'lab.request.view', 'lab.request.create', 'lab.request.cancel', 'lab.sample.collect',
            'lab.sample.reject', 'lab.result.enter', 'lab.result.verify', 'lab.result.view',
            'lab.result.amend', 'lab.catalogue.manage', 'lab.report.print',
        ],
        'billing' => [
            'billing.invoice.view', 'billing.invoice.create', 'billing.invoice.edit',
            'billing.invoice.cancel', 'billing.invoice.writeoff', 'billing.discount.apply',
            'billing.discount.approve', 'billing.service.manage',
            'payments.payment.record', 'payments.payment.reverse', 'payments.receipt.print',
            'payments.receipt.reprint', 'payments.shift.manage', 'payments.shift.review',
            'expenses.expense.record', 'expenses.expense.approve',
        ],
        'inventory' => [
            'inventory.item.view', 'inventory.item.manage', 'inventory.stock.receive',
            'inventory.stock.issue', 'inventory.stock.transfer', 'inventory.stock.adjust',
            'inventory.stock.count', 'suppliers.supplier.view', 'suppliers.supplier.manage',
            'suppliers.purchase.record',
        ],
        'staff' => [
            'staff.employee.view', 'staff.employee.manage', 'staff.doctor.manage',
            'attendance.record.view', 'attendance.record.create',
            'attendance.leave.request', 'attendance.leave.approve',
        ],
        'administration' => [
            'org.sector.view', 'org.sector.create', 'org.sector.edit', 'org.sector.delete',
            'org.ward.manage', 'settings.hospital.manage', 'settings.branding.manage',
            'settings.security.manage', 'users.account.view', 'users.account.manage',
            'users.role.manage', 'backups.backup.manage',
        ],
        'reporting' => [
            'reports.operational.view', 'reports.clinical.view', 'reports.financial.view',
            'reports.pharmacy.view', 'reports.laboratory.view', 'reports.inventory.view',
            'reports.staff.view', 'reports.report.export', 'reports.report.print',
            'dashboard.management.view', 'audit.log.view', 'audit.breakglass.review',
        ],
    ];

    /**
     * Roles and what they may do.
     *
     * 'system-owner' and 'super-admin' receive EVERY permission, including any
     * added in future releases, so the hospital can never be locked out of a
     * new module by an out-of-date seed.
     */
    public const ROLES = [
        'system-owner' => ['label' => 'System Owner', 'all' => true],
        'super-admin'  => ['label' => 'Super Administrator', 'all' => true],

        'management' => ['label' => 'Hospital Management', 'permissions' => [
            'patients.record.view', 'patients.record.edit', 'patients.record.merge',
            'patients.record.deactivate', 'patients.record.export', 'patients.record.print',
            'appointments.booking.view', 'appointments.booking.cancel', 'appointments.schedule.manage',
            'visits.visit.view', 'visits.visit.cancel', 'visits.queue.view',
            'ipd.admission.view', 'ipd.bed.manage', 'ipd.discharge.override_balance',
            'emergency.case.view',
            'prescriptions.prescription.view', 'pharmacy.dispense.reverse',
            'pharmacy.stock.view', 'pharmacy.stock.adjust', 'pharmacy.stock.dispose',
            'lab.request.view', 'lab.result.view', 'lab.catalogue.manage',
            'billing.invoice.view', 'billing.invoice.cancel', 'billing.invoice.writeoff',
            'billing.discount.apply', 'billing.discount.approve', 'billing.service.manage',
            'payments.payment.reverse', 'payments.receipt.reprint',
            'payments.shift.manage', 'payments.shift.review',
            'expenses.expense.record', 'expenses.expense.approve',
            'inventory.item.view', 'inventory.item.manage', 'inventory.stock.adjust',
            'inventory.stock.count', 'suppliers.supplier.view', 'suppliers.supplier.manage',
            'suppliers.purchase.record',
            'staff.employee.view', 'staff.employee.manage', 'staff.doctor.manage',
            'attendance.record.view', 'attendance.record.create',
            'attendance.leave.request', 'attendance.leave.approve',
            'org.sector.view', 'org.sector.create', 'org.sector.edit', 'org.sector.delete',
            'org.ward.manage', 'settings.hospital.manage', 'settings.branding.manage',
            'users.account.view',
            'reports.operational.view', 'reports.clinical.view', 'reports.financial.view',
            'reports.pharmacy.view', 'reports.laboratory.view', 'reports.inventory.view',
            'reports.staff.view', 'reports.report.export', 'reports.report.print',
            'dashboard.management.view', 'audit.log.view', 'audit.breakglass.review',
        ]],

        'receptionist' => ['label' => 'Receptionist', 'permissions' => [
            'patients.record.view', 'patients.record.create', 'patients.record.edit',
            'patients.record.print',
            'appointments.booking.view', 'appointments.booking.create', 'appointments.booking.edit',
            'appointments.booking.cancel', 'appointments.booking.checkin', 'appointments.schedule.manage',
            'visits.visit.view', 'visits.visit.create', 'visits.visit.cancel',
            'visits.queue.view', 'visits.queue.manage',
            'ipd.admission.view', 'ipd.bed.assign',
            'emergency.case.view', 'emergency.case.create',
            'billing.invoice.view', 'billing.invoice.create',
            'payments.payment.record', 'payments.receipt.print',
            'attendance.leave.request',
            'reports.operational.view', 'reports.report.print',
        ]],

        'doctor' => ['label' => 'Doctor', 'permissions' => [
            'patients.record.view', 'patients.record.create', 'patients.record.edit',
            'patients.clinical.view', 'patients.allergy.manage', 'patients.record.print',
            'appointments.booking.view', 'appointments.booking.create', 'appointments.booking.edit',
            'appointments.booking.cancel', 'appointments.schedule.manage',
            'visits.visit.view', 'visits.visit.create', 'visits.queue.view', 'visits.queue.manage',
            'clinical.consultation.view', 'clinical.consultation.create', 'clinical.consultation.edit',
            'clinical.consultation.addendum', 'clinical.diagnosis.manage', 'clinical.note.create',
            'clinical.record.breakglass', 'clinical.document.print',
            'vitals.record.view', 'vitals.record.create',
            'ipd.admission.view', 'ipd.admission.create', 'ipd.bed.assign',
            'ipd.admission.transfer', 'ipd.discharge.process',
            'emergency.case.view', 'emergency.case.create', 'emergency.case.triage',
            'emergency.case.disposition',
            'prescriptions.prescription.view', 'prescriptions.prescription.create',
            'prescriptions.prescription.cancel', 'prescriptions.prescription.print',
            'pharmacy.stock.view',
            'lab.request.view', 'lab.request.create', 'lab.request.cancel',
            'lab.result.view', 'lab.result.verify', 'lab.report.print',
            'attendance.leave.request',
            'reports.operational.view', 'reports.clinical.view', 'reports.laboratory.view',
            'reports.report.export', 'reports.report.print',
        ]],

        'nurse' => ['label' => 'Nurse', 'permissions' => [
            'patients.record.view', 'patients.record.create', 'patients.clinical.view',
            'patients.allergy.manage', 'patients.record.print',
            'appointments.booking.view', 'appointments.booking.checkin',
            'visits.visit.view', 'visits.visit.create', 'visits.queue.view', 'visits.queue.manage',
            'clinical.consultation.view', 'clinical.note.create', 'clinical.document.print',
            'clinical.record.breakglass',
            'vitals.record.view', 'vitals.record.create', 'nursing.mar.administer',
            'ipd.admission.view', 'ipd.admission.create', 'ipd.bed.assign',
            'ipd.bed.manage', 'ipd.admission.transfer',
            'emergency.case.view', 'emergency.case.create', 'emergency.case.triage',
            'prescriptions.prescription.view', 'prescriptions.prescription.print',
            'lab.request.view', 'lab.request.create', 'lab.sample.collect',
            'lab.result.view', 'lab.report.print',
            'inventory.item.view',
            'attendance.leave.request',
            'reports.operational.view', 'reports.clinical.view', 'reports.report.print',
        ]],

        'pharmacist' => ['label' => 'Pharmacist', 'permissions' => [
            'patients.record.view', 'patients.clinical.view', 'patients.allergy.manage',
            'visits.visit.view',
            'prescriptions.prescription.view', 'prescriptions.prescription.cancel',
            'prescriptions.prescription.print',
            'pharmacy.dispense.process', 'pharmacy.dispense.reverse', 'pharmacy.stock.view',
            'pharmacy.stock.receive', 'pharmacy.stock.adjust', 'pharmacy.stock.dispose',
            'inventory.item.view', 'inventory.item.manage', 'inventory.stock.receive',
            'inventory.stock.issue', 'inventory.stock.transfer', 'inventory.stock.adjust',
            'inventory.stock.count', 'suppliers.supplier.view',
            'billing.invoice.view', 'payments.payment.record', 'payments.receipt.print',
            'attendance.leave.request',
            'reports.operational.view', 'reports.pharmacy.view', 'reports.inventory.view',
            'reports.report.export', 'reports.report.print',
        ]],

        'laboratory' => ['label' => 'Laboratory Staff', 'permissions' => [
            'patients.record.view', 'patients.clinical.view',
            'visits.visit.view',
            'lab.request.view', 'lab.request.cancel', 'lab.sample.collect', 'lab.sample.reject',
            'lab.result.enter', 'lab.result.verify', 'lab.result.view', 'lab.result.amend',
            'lab.catalogue.manage', 'lab.report.print',
            'billing.invoice.view', 'inventory.item.view',
            'attendance.leave.request',
            'reports.operational.view', 'reports.laboratory.view',
            'reports.report.export', 'reports.report.print',
        ]],

        'cashier' => ['label' => 'Cashier', 'permissions' => [
            'patients.record.view',
            'visits.visit.view', 'ipd.admission.view',
            'prescriptions.prescription.view',
            'lab.request.view',
            'billing.invoice.view', 'billing.invoice.create', 'billing.invoice.edit',
            'billing.invoice.cancel', 'billing.discount.apply',
            'payments.payment.record', 'payments.payment.reverse',
            'payments.receipt.print', 'payments.receipt.reprint', 'payments.shift.manage',
            'expenses.expense.record',
            'reports.operational.view', 'reports.financial.view',
            'reports.report.export', 'reports.report.print',
        ]],

        'store-officer' => ['label' => 'Store / Inventory Officer', 'permissions' => [
            'pharmacy.stock.view', 'pharmacy.stock.receive', 'pharmacy.stock.dispose',
            'inventory.item.view', 'inventory.item.manage', 'inventory.stock.receive',
            'inventory.stock.issue', 'inventory.stock.transfer', 'inventory.stock.adjust',
            'inventory.stock.count', 'suppliers.supplier.view', 'suppliers.supplier.manage',
            'suppliers.purchase.record',
            'attendance.leave.request',
            'reports.operational.view', 'reports.inventory.view', 'reports.pharmacy.view',
            'reports.report.export', 'reports.report.print',
        ]],

        'hr-officer' => ['label' => 'HR / Staff Officer', 'permissions' => [
            'staff.employee.view', 'staff.employee.manage', 'staff.doctor.manage',
            'attendance.record.view', 'attendance.record.create',
            'attendance.leave.request', 'attendance.leave.approve',
            'reports.operational.view', 'reports.staff.view',
            'reports.report.export', 'reports.report.print',
        ]],
    ];

    public function run(): void
    {
        app(PermissionRegistrar::class)->forgetCachedPermissions();

        $all = [];

        foreach (self::PERMISSIONS as $group => $permissions) {
            foreach ($permissions as $name) {
                Permission::findOrCreate($name, 'web');
                $all[] = $name;
            }
        }

        foreach (self::ROLES as $name => $definition) {
            $role = Role::findOrCreate($name, 'web');

            $grants = ($definition['all'] ?? false) ? $all : $definition['permissions'];

            // syncPermissions would wipe any extra permission the hospital has
            // granted a role itself. givePermissionTo only adds, so local
            // customisation survives an upgrade.
            $role->givePermissionTo(array_diff($grants, $role->permissions->pluck('name')->all()));
        }

        app(PermissionRegistrar::class)->forgetCachedPermissions();

        if (App::runningInConsole()) {
            $this->command?->info('Seeded '.count($all).' permissions across '.count(self::ROLES).' roles.');
        }
    }
}
