<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Bed;
use App\Models\Department;
use App\Models\StockLocation;
use App\Models\Ward;
use Illuminate\Database\Seeder;

/**
 * Al Rahma Hospital's STARTING structure — a starting point, not a fixed list.
 *
 * Everything seeded here can be renamed, moved, nested, deactivated or (where
 * not marked is_system) deleted by the administration through
 * Administration → Sectors, with no developer involved.
 *
 * is_system is set only on the nodes the software itself depends on:
 * Outpatient receives walk-in registrations, Emergency drives the triage
 * workflow, Pharmacy and Laboratory own their dispensing and testing queues.
 * Those four remain renameable and reconfigurable — only deletion is refused,
 * so a tidy-up on a quiet afternoon cannot break registration on Monday.
 */
class SectorSeeder extends Seeder
{
    public function run(): void
    {
        $clinical = $this->sector('CLIN', 'Clinical Services', 'clinical', 1);
        $support  = $this->sector('SUPP', 'Diagnostic & Support Services', 'support', 2);
        $admin    = $this->sector('ADMIN', 'Administration', 'administrative', 3);

        $departments = [
            // code, name, parent, type, modules, system?, appointments?, walkins?
            ['OPD',   'Outpatient (OPD)',  $clinical, 'clinical',       ['opd', 'billing', 'reporting'], true,  true,  true],
            ['EMG',   'Emergency',         $clinical, 'clinical',       ['emergency', 'billing', 'reporting'], true, false, true],
            ['IPD',   'Inpatient Ward',    $clinical, 'clinical',       ['inpatient', 'billing', 'reporting'], false, false, false],
            ['MAT',   'Maternity',         $clinical, 'clinical',       ['maternity', 'inpatient', 'billing'], false, true, true],
            ['LAB',   'Laboratory',        $support,  'support',        ['laboratory', 'billing', 'reporting'], true, false, true],
            ['PHARM', 'Pharmacy',          $support,  'support',        ['pharmacy', 'inventory', 'billing'], true, false, true],
            ['STORE', 'Main Store',        $support,  'support',        ['inventory'], false, false, false],
            ['FIN',   'Finance & Cashier', $admin,    'administrative', ['billing', 'reporting'], false, false, false],
            ['HR',    'Human Resources',   $admin,    'administrative', ['hr', 'reporting'], false, false, false],
            ['MGMT',  'Management',        $admin,    'administrative', ['reporting'], false, false, false],
        ];

        foreach ($departments as $i => [$code, $name, $parent, $type, $modules, $system, $appointments, $walkins]) {
            Department::query()->firstOrCreate(
                ['code' => $code],
                [
                    'name'                 => $name,
                    'parent_id'            => $parent->id,
                    'kind'                 => 'department',
                    'type'                 => $type,
                    'modules'              => $modules,
                    'accepts_appointments' => $appointments,
                    'accepts_walkins'      => $walkins,
                    'is_system'            => $system,
                    'is_active'            => true,
                    'display_order'        => $i + 1,
                ]
            );
        }

        $this->seedWardsAndBeds();
        $this->seedStockLocations();
    }

    private function sector(string $code, string $name, string $type, int $order): Department
    {
        return Department::query()->firstOrCreate(
            ['code' => $code],
            [
                'name'                 => $name,
                'kind'                 => 'sector',
                'type'                 => $type,
                'modules'              => [],
                'accepts_appointments' => false,
                'accepts_walkins'      => false,
                'is_system'            => true,
                'display_order'        => $order,
            ]
        );
    }

    private function seedWardsAndBeds(): void
    {
        $ipd      = Department::query()->where('code', 'IPD')->firstOrFail();
        $maternity = Department::query()->where('code', 'MAT')->firstOrFail();

        $wards = [
            ['General Ward (Male)',   $ipd,       'male',   15.00, 8],
            ['General Ward (Female)', $ipd,       'female', 15.00, 8],
            ['Maternity Ward',        $maternity, 'female', 20.00, 6],
        ];

        foreach ($wards as [$name, $department, $gender, $rate, $bedCount]) {
            $ward = Ward::query()->firstOrCreate(
                ['name' => $name],
                [
                    'department_id'      => $department->id,
                    'gender_restriction' => $gender,
                    'daily_bed_rate'     => $rate,
                    'is_active'          => true,
                ]
            );

            for ($n = 1; $n <= $bedCount; $n++) {
                Bed::query()->firstOrCreate(
                    ['ward_id' => $ward->id, 'bed_number' => str_pad((string) $n, 2, '0', STR_PAD_LEFT)],
                    ['status' => 'available']
                );
            }
        }
    }

    private function seedStockLocations(): void
    {
        $locations = [
            ['MAIN',  'Main Store',         'store',    'STORE', false],
            ['PHARM', 'Pharmacy',           'pharmacy', 'PHARM', true],
            ['LAB',   'Laboratory Store',   'lab',      'LAB',   false],
            ['WARD',  'Ward Stock',         'ward',     'IPD',   true],
        ];

        foreach ($locations as [$code, $name, $type, $departmentCode, $dispensing]) {
            StockLocation::query()->firstOrCreate(
                ['code' => $code],
                [
                    'name'                => $name,
                    'type'                => $type,
                    'department_id'       => Department::query()->where('code', $departmentCode)->value('id'),
                    'is_dispensing_point' => $dispensing,
                    'is_active'           => true,
                ]
            );
        }
    }
}
