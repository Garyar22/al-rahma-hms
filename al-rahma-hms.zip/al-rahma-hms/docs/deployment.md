# Deployment — putting the HMS into the hospital

There are three different things people mean by "publishing" this system, and
they are not the same job. Do them in this order.

| | What it is | Ready now? |
|---|---|---|
| 1 | **Publish the code** to a private Git repository | Yes |
| 2 | **Stand up a demonstration server** so staff and management can see it | Yes |
| 3 | **Go live** on real patients, money and stock | No — Phases 5–8 first |

---

## 1. Publish the code to Git

Do this before anything else; everything below assumes the code has a home.

```bash
cd al-rahma-hms
git init
git add .
git commit -m "Al Rahma HMS — database, auth, RBAC, sectors, system owner"
git branch -M main
git remote add origin git@github.com:<account>/al-rahma-hms.git
git push -u origin main
```

**Make the repository private.** It is a hospital's operational system: the
schema, permission model and workflow are not things to hand to anyone who
searches for them.

Confirm `.gitignore` contains at least `.env`, `/vendor`, `/node_modules`,
`/storage/*.key`, `/public/storage`, `/public/build`. If `.env` has ever been
committed, the database password and `APP_KEY` in it must be treated as leaked
and rotated — removing the file in a later commit does not remove it from
history.

---

## 2. Demonstration server

The point is to let the hospital use the screens and tell you what is wrong
while it is still cheap to change. Put it on a laptop or a spare PC on the
hospital network, **with a separate database**, clearly labelled as a
demonstration, and never with real patient data in it.

```bash
php artisan migrate:fresh --seed
php artisan serve --host=0.0.0.0 --port=8000
```

Staff reach it at `http://<the-laptop-ip>:8000`. That is enough for a review
session and nothing more — `artisan serve` is a development server and must
never run the real thing.

---

## 3. Production: the on-premise server

### Why on-premise

The blueprint's A1 assumption decides this: the hospital's internet is
unreliable, its local network is not. A cloud-hosted HMS stops working for
registration, dispensing and billing the moment the link drops — which here is
a normal event, not an emergency. The server sits in the hospital, on the
local network, and the internet is used only for off-site backup and updates.

```
Reception · Doctors · Nurses · Pharmacy · Laboratory · Cashier · Management
                         │  HTTPS over the hospital LAN
                  ┌──────┴──────────────────────┐
                  │  HMS SERVER (in the office) │
                  │  Ubuntu Server 24.04 LTS    │
                  │  Nginx + PHP-FPM 8.4        │
                  │  MariaDB 11.4 (InnoDB)      │
                  │  cron → scheduler           │
                  │  systemd → queue worker     │
                  │  on a UPS                   │
                  └──────┬──────────────────────┘
                         │  nightly, when internet allows
                  Off-site encrypted backup + weekly USB rotation
```

**Minimum machine:** 4 cores, 8 GB RAM, 256 GB SSD, and a UPS with at least 20
minutes of runtime. The UPS is not optional — an unclean shutdown mid-write is
the single most likely cause of data damage here, and it is the cheapest risk
to remove.

### Server build

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y nginx mariadb-server php8.4-fpm php8.4-mysql php8.4-mbstring \
     php8.4-xml php8.4-curl php8.4-zip php8.4-gd php8.4-bcmath php8.4-intl \
     git unzip ufw

sudo mysql_secure_installation
```

Create the database and a least-privilege application user:

```sql
CREATE DATABASE al_rahma_hms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'hms_app'@'localhost' IDENTIFIED BY '<a long random password>';

GRANT SELECT, INSERT, UPDATE, DELETE ON al_rahma_hms.* TO 'hms_app'@'localhost';

-- The audit trail is append-only by design, so make it append-only in the
-- database as well. Even a defect in the application cannot rewrite history.
REVOKE UPDATE, DELETE ON al_rahma_hms.audit_logs FROM 'hms_app'@'localhost';

FLUSH PRIVILEGES;
```

Migrations need DDL rights, which the application user must not have. Run them
as a separate deploy user, or grant `ALTER, CREATE, DROP, INDEX, REFERENCES`
temporarily during a release and revoke afterwards.

### Deploy the application

```bash
sudo mkdir -p /var/www/hms && sudo chown $USER:www-data /var/www/hms
cd /var/www/hms
git clone git@github.com:<account>/al-rahma-hms.git .

composer install --no-dev --optimize-autoloader
cp .env.example .env && php artisan key:generate
# edit .env: APP_ENV=production, APP_DEBUG=false, APP_URL=https://hms.alrahma.local,
#            SESSION_SECURE_COOKIE=true, DB credentials

php artisan migrate --force
php artisan db:seed --force          # settings, branding, roles, sectors, owner
php artisan storage:link
php artisan optimize                 # config, route and view caches

sudo chown -R www-data:www-data storage bootstrap/cache
sudo chmod -R 775 storage bootstrap/cache
```

Build assets on your own machine (`npm run build`) and commit or copy
`public/build` — the server needs no Node.js.

**`APP_DEBUG=false` is not a preference.** With it on, a database error shows a
receptionist a stack trace containing the connection details.

### Nginx

```nginx
server {
    listen 443 ssl http2;
    server_name hms.alrahma.local;
    root /var/www/hms/public;

    ssl_certificate     /etc/ssl/hms/hms.crt;
    ssl_certificate_key /etc/ssl/hms/hms.key;

    index index.php;
    charset utf-8;
    client_max_body_size 12M;          # logo and attachment uploads

    location / { try_files $uri $uri/ /index.php?$query_string; }

    location ~ \.php$ {
        fastcgi_pass unix:/run/php/php8.4-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* { deny all; }
}

server {
    listen 80;
    server_name hms.alrahma.local;
    return 301 https://$host$request_uri;
}
```

### HTTPS on a local network

There is no public domain, so a public certificate authority cannot issue one.
Use an internal certificate: generate a small CA once, install its root
certificate on every workstation, and issue the server a certificate for
`hms.alrahma.local`. Point that name at the server's fixed IP in the router's
DNS or in each machine's hosts file.

Plain HTTP on the hospital wifi would put every password and every patient
record in the clear for anyone with a laptop in the waiting room.

### Scheduler and queue

```bash
sudo crontab -u www-data -e
# * * * * * cd /var/www/hms && php artisan schedule:run >> /dev/null 2>&1
```

```ini
# /etc/systemd/system/hms-queue.service
[Unit]
Description=Al Rahma HMS queue worker
After=network.target mariadb.service

[Service]
User=www-data
Restart=always
RestartSec=5
ExecStart=/usr/bin/php /var/www/hms/artisan queue:work --sleep=3 --tries=3 --max-time=3600

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now hms-queue
```

### Firewall

```bash
sudo ufw allow from 192.168.1.0/24 to any port 443   # the hospital LAN only
sudo ufw allow from 192.168.1.0/24 to any port 22
sudo ufw enable
```

**Do not port-forward this system to the internet.** If the owner needs access
from outside the building, use a VPN — WireGuard or Tailscale — so the HMS
stays on a private network and only authenticated devices reach it. An HMS
exposed on a public IP is scanned within hours.

### Updating later

```bash
cd /var/www/hms
php artisan down --render="errors::503"
git pull
composer install --no-dev --optimize-autoloader
php artisan migrate --force
php artisan optimize
sudo systemctl restart hms-queue php8.4-fpm
php artisan up
```

`scripts/deploy.sh` does this in one command. **Take a database backup before
every release that includes a migration**, and confirm it exists before
running `migrate`.

---

## Go-live checklist

Nothing here is optional, and several items are the difference between a
system the hospital trusts and one it abandons.

**Before the first patient is registered**

- [ ] Phases 5–8 built and tested: patients, appointments, clinical, pharmacy, laboratory, billing, reporting
- [ ] `php artisan test` passes on the production stack
- [ ] The eleven open decisions in the blueprint are answered — the four schema-affecting ones especially
- [ ] `APP_DEBUG=false`, `APP_ENV=production`, HTTPS working, demo seeders confirmed blocked
- [ ] Hospital settings complete: phone, email, prefixes, billing mode, receipt paper
- [ ] Real sectors, services and prices entered — not the seeded examples
- [ ] Every member of staff has their own account; **no shared logins**
- [ ] The System Owner password is held by the hospital, not only by the developer
- [ ] A backup has been taken **and restored into a scratch database to prove it works**
- [ ] Someone on staff is named as responsible for backups, with a second person trained
- [ ] UPS tested by pulling the mains plug and watching the server stay up
- [ ] Staff trained per role, with the one-page guides printed

**Rollout order** — do not switch the whole hospital over on one morning:

```
Weeks 1–2   Reception + Cashier only. Paper register continues in parallel;
            compare counts every evening.
Weeks 3–4   Add Pharmacy and Laboratory.
Weeks 5–6   Add Doctors. Only proceed when registration is demonstrably reliable.
Week 7+     Add Inpatient, Emergency, Attendance, Reports.
Stop paper  After one full month with no material discrepancy.
```

If registration data is wrong, every later module inherits the error — and
reception is where adoption succeeds or fails. If it is slow, staff will route
around the system and no amount of reporting will save the project.
