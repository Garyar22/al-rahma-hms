# Backup and restore

A backup that has never been restored is a hypothesis. The restore drill below
is the part that matters; the backup command is the easy half.

## What is backed up

The database, the uploaded logo and any attachments. Nothing else on the
server is irreplaceable — the code is in Git and the operating system can be
rebuilt.

## Schedule

`spatie/laravel-backup` runs from the scheduler:

| | When | Kept |
|---|---|---|
| Database dump | Nightly, 01:00 | 30 daily · 12 weekly · 12 monthly |
| Files | Nightly with the database | same |
| Binary logs | Hourly copy | 7 days |

Binary logging turns the worst case from "a day of work lost" into "an hour".
Enable it in `/etc/mysql/mariadb.conf.d/50-server.cnf`:

```ini
log_bin         = /var/log/mysql/mysql-bin.log
expire_logs_days = 7
```

## Three destinations

One copy on the same disk as the database is not a backup — the disk is the
thing that fails.

1. Local disk, for fast restore of a mistake.
2. **External USB drive, rotated weekly and kept off the premises.** This is
   the copy that survives fire, flood and theft.
3. Encrypted copy off-site when the internet allows.

Archives are encrypted. The passphrase is held by hospital management **off the
system** — not in the repository, not in `.env` on the same machine.

## Manual backup

```bash
cd /var/www/hms
php artisan backup:run
```

Before any release containing a migration:

```bash
mysqldump --single-transaction --routines --triggers \
  -u root -p al_rahma_hms | gzip > ~/pre-release-$(date +%F-%H%M).sql.gz
```

`--single-transaction` gives a consistent dump without locking the tables,
which matters because InnoDB is in use and the hospital may still be working.

## Restore

```bash
php artisan down
mysql -u root -p -e "CREATE DATABASE al_rahma_restore CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
gunzip < backup.sql.gz | mysql -u root -p al_rahma_restore
# check it, then point .env at it or rename the databases
php artisan up
```

Restore into a **new** database first and look at it. Restoring straight over
a live database converts a recoverable problem into an unrecoverable one.

## The monthly drill

Once a month, on a fixed day, by the named person:

1. Take the newest backup from the USB drive — not the local copy.
2. Restore it into `al_rahma_restore`.
3. Check three numbers against the live system: patient count, the most recent
   receipt number, and yesterday's total payments.
4. Record the date, the backup used, and whether the numbers matched, on a
   one-page log kept with the UPS.
5. Drop the scratch database.

Twenty minutes a month. The alternative is discovering that the backups have
been writing zero-byte files since March, on the day the disk fails.
