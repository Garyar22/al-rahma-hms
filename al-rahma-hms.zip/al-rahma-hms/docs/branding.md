# Hospital branding

## The logo

Al Rahma Hospital's official logo is installed by `BrandingSeeder` on first
`db:seed`. The source artwork lives in `database/seeders/assets/branding/`;
the running system reads it from `storage/app/public/branding/` through the
`branding.*` settings keys.

Nothing in the application references a logo file path directly. Every view,
report and receipt asks `SettingsRepository` for `branding.logo_path`, which is
what makes replacing the logo an upload rather than a code change.

## Why there are several files

One PNG cannot serve every surface.

| Variant | File | Where it is used |
|---|---|---|
| Colour, transparent | `logo.png` (+ 512/256/128/96) | Login page, letterhead, invoices, reports, light UI |
| Knock-out white | `logo-white.png` | Dark sidebar and dark page headers |
| Emblem only | `mark.png` (+ 512/192/64) | Collapsed sidebar, favicon source, small spaces |
| Thermal 80mm | `logo-receipt.png` (384px, 1-bit) | 80mm receipt printers |
| Thermal 58mm | `logo-receipt-narrow.png` (240px, 1-bit) | 58mm paper rolls |
| Browser icons | `favicon.ico`, `apple-touch-icon.png` | Copied into the document root |

The thermal variants are **hard-thresholded silhouettes, never dithered**. A
halftone logo prints as a grey smear on receipt paper; a silhouette prints
cleanly. `receipt.paper` (`a4` | `thermal80` | `thermal58`) selects which
variant and layout the receipt uses.

## Brand colours

Sampled from the artwork:

| Token | Hex | Contrast on white |
|---|---|---|
| Brand blue | `#01AFEE` | 2.51:1 |
| Brand green | `#6DBC45` | 2.35:1 |
| Blue, text-safe | `#0B6E96` | 5.70:1 |
| Green, text-safe | `#3D7A24` | 5.24:1 |

The two brand colours **fail WCAG AA** for body text (4.5:1) and for white text
on a coloured button (3:1). They are decorative tokens only: logo areas, large
headings, chart fills, accent bars. Anything a user has to read uses the
text-safe shades. Staff read this system all day on inexpensive monitors in a
bright room, so this is a usability requirement (NFR-09), not a style opinion.

Clinical status colours are deliberately *not* brand colours: green must mean
"result within range", never "Al Rahma".

## Replacing the logo

Administration → Hospital Settings → Hospital Branding.

The upload is validated by extension, MIME type, real image content
(`getimagesize`) and file size; the file is stored under a generated name,
never the uploaded one; and the previous file is deleted only after the new one
is verified (FR-SEC-07). Only users with `settings.branding.manage` may do it.

Re-running `db:seed` will **not** overwrite a logo uploaded through that screen.

## Regenerating the variants

If the hospital supplies new artwork, regenerate the variants rather than
uploading one large PNG everywhere — the thermal and knock-out versions cannot
be produced by resizing alone. `docs/regenerate-branding.md` records the exact
steps used to derive the current set from the original 960×960 artwork.
