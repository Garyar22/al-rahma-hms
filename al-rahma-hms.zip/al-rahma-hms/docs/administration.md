# Administration

## Sectors — the hospital's own structure

**Administration → Sectors.**

The hospital builds and rebuilds its own structure. Sectors hold departments,
departments hold units, to any depth. Adding Radiology, splitting Maternity out
of Inpatient, or renaming a ward after a refurbishment is a few clicks, not a
migration.

Each node chooses which parts of the system it uses. Switching Maternity's
modules on adds those screens to that branch only.

### What the administration can do

| Action | Permission | Notes |
|---|---|---|
| View the structure | `org.sector.view` | |
| Add a sector, department or unit | `org.sector.create` | A code is generated if none is given |
| Rename, move, re-configure | `org.sector.edit` | Including which modules it uses |
| Close / reopen | `org.sector.edit` | Everything inside closes with it |
| Delete | `org.sector.delete` | Only when nothing depends on it |

### Three rules the system enforces for you

1. **A sector can never end up inside itself.** Moving a parent into its own
   child is refused with an explanation, because a cycle would make the
   sidebar recurse forever.
2. **Closing a sector closes everything inside it.** A department cannot be
   open inside a closed sector; staff would still see it in a picker and
   register patients against it.
3. **Deletion is refused once history points at the node** — visits, staff,
   wards or services. The screen then offers *Close* instead, which keeps every
   past record readable. Deleted sectors are soft-deleted, so even a permitted
   deletion is recoverable and stays in the audit trail.

Four nodes are marked **Core** — Outpatient, Emergency, Pharmacy and
Laboratory. The software's own workflows depend on them. They stay fully
renameable and reconfigurable; only deletion is refused, so a tidy-up on a
quiet afternoon cannot break patient registration on Monday morning.

## Users and the System Owner

**Administration → Users.**

One login per person. Shared accounts are forbidden: the audit trail is the
hospital's main accountability control, and a shared login destroys it.

### Creating an account

An administrator enters the person's name, username and role. A strong
temporary password is generated and shown **once**, on screen, ready to print.
It is never emailed and never stored in readable form. The person chooses their
own password at first sign-in, so no administrator ever knows a colleague's
working password.

### The System Owner

The System Owner account belongs to the hospital itself — the proprietor or
their nominated administrator. It holds every permission, including permissions
added in future releases, so the hospital can never be locked out of a new
module by an out-of-date seed.

Four protections apply to it, each because of a real way hospitals lose access:

- It cannot be deleted or deactivated by anyone, including itself.
- Its role cannot be changed through the interface.
- Only a System Owner may edit another System Owner, so an administrator
  cannot quietly take over the proprietor's account.
- The `system-owner` role is never offered in the role dropdown; it is granted
  at installation only.

Nobody can deactivate or delete their own account either — the common
accidental version of the same mistake.

**If the owner password is lost:**

```
php artisan hms:reset-owner-password
```

This requires shell access to the server, which in practice means physical
access to the machine in the office. That is the intended level of difficulty:
hard enough not to be a remote attack path, easy enough that a lost password is
not a disaster.

## Security applied at this layer

| Control | Where |
|---|---|
| Username sign-in, vague failures, precise audit | `LoginController` |
| Account lockout after repeated failures | `User::registerFailedLogin()` |
| Rate limiting per username and IP | login route + controller |
| Forced first-login password change | `EnsurePasswordChanged` middleware |
| Idle session timeout on shared workstations | `EnforceIdleTimeout` middleware |
| CSP, frame, sniff and referrer headers; no-store for signed-in pages | `SecurityHeaders` middleware |
| Permission middleware **and** per-record policy on every admin route | routes + controllers |
| Every account and role change written to the audit trail | `UserService`, `SectorService` |
