<x-layouts.guest :title="__('Sign in')">
    <div class="panel">
        <div class="panel__body">
            <h1 style="font-size:var(--t-lg);margin:0 0 var(--sp-4)">{{ __('Sign in') }}</h1>

            <form method="post" action="{{ route('login') }}">
                @csrf

                <x-field name="username" :label="__('Username')" required>
                    <input id="username" name="username" type="text" autocomplete="username"
                           value="{{ old('username') }}" autofocus required
                           class="@error('username') is-invalid @enderror">
                </x-field>

                <x-field name="password" :label="__('Password')" required>
                    <input id="password" name="password" type="password" autocomplete="current-password" required
                           class="@error('password') is-invalid @enderror">
                </x-field>

                <div class="check">
                    <input id="remember" name="remember" type="checkbox" value="1">
                    <label for="remember">{{ __('Keep me signed in on this computer') }}</label>
                </div>

                <button class="btn btn--primary" type="submit" style="width:100%;margin-top:var(--sp-3)">
                    {{ __('Sign in') }}
                </button>
            </form>

            <p style="margin:var(--sp-4) 0 0;font-size:var(--t-xs);color:var(--arh-muted)">
                {{ __('Forgotten your password? Ask an administrator to issue a new one. Do not use a colleague’s account.') }}
            </p>
        </div>
    </div>
</x-layouts.guest>
