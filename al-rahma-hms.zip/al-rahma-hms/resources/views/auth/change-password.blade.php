<x-layouts.guest :title="__('Choose a password')">
    <div class="panel">
        <div class="panel__body">
            <h1 style="font-size:var(--t-lg);margin:0 0 6px">{{ __('Choose your password') }}</h1>
            <p style="margin:0 0 var(--sp-4);color:var(--arh-muted);font-size:var(--t-sm)">
                @if ($forced)
                    {{ __('This is your first sign-in. Pick a password only you know — your name is attached to everything you record in this system.') }}
                @else
                    {{ __('Your new password replaces the current one immediately.') }}
                @endif
            </p>

            <form method="post" action="{{ route('password.update') }}">
                @csrf
                @method('put')

                <x-field name="current_password" :label="__('Current password')" required>
                    <input id="current_password" name="current_password" type="password" autocomplete="current-password" required
                           class="@error('current_password') is-invalid @enderror">
                </x-field>

                <x-field name="password" :label="__('New password')" required
                         :hint="__('At least :n characters, with letters and numbers.', ['n' => config('hospital.security.password_min_length', 12)])">
                    <input id="password" name="password" type="password" autocomplete="new-password" required
                           class="@error('password') is-invalid @enderror">
                </x-field>

                <x-field name="password_confirmation" :label="__('New password again')" required>
                    <input id="password_confirmation" name="password_confirmation" type="password" autocomplete="new-password" required>
                </x-field>

                <button class="btn btn--primary" type="submit" style="width:100%">{{ __('Save password') }}</button>
            </form>
        </div>
    </div>
</x-layouts.guest>
