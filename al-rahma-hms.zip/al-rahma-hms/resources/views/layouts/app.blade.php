<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ?? __('Dashboard') }} · {{ $branding->hospitalName() }}</title>
    <link rel="icon" href="{{ asset('favicon.ico') }}">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body>
<div class="app" x-data="{ nav: false }">

    <aside class="sidebar" :class="{ 'is-open': nav }" aria-label="{{ __('Main navigation') }}">
        <div class="sidebar__brand">
            @if ($mark = $branding->logo('mark'))
                <img src="{{ $mark }}" alt="">
            @endif
            <span>
                <b>{{ $branding->hospitalName() }}</b>
                <span>{{ __('Hospital management') }}</span>
            </span>
        </div>

        <nav>
            <x-nav-link route="dashboard" icon="dashboard">{{ __('Dashboard') }}</x-nav-link>

            <p class="sidebar__group">{{ __('Patient care') }}</p>
            <x-nav-link route="patients.index" icon="patients" permission="patients.record.view">{{ __('Patients') }}</x-nav-link>
            <x-nav-link route="appointments.index" icon="calendar" permission="appointments.booking.view">{{ __('Appointments') }}</x-nav-link>
            <x-nav-link route="queue.index" icon="queue" permission="visits.queue.view">{{ __('Queue') }}</x-nav-link>
            <x-nav-link route="consultations.index" icon="stethoscope" permission="clinical.consultation.view">{{ __('Consultations') }}</x-nav-link>
            <x-nav-link route="admissions.index" icon="bed" permission="ipd.admission.view">{{ __('Inpatients') }}</x-nav-link>

            <p class="sidebar__group">{{ __('Services') }}</p>
            <x-nav-link route="pharmacy.index" icon="pill" permission="pharmacy.stock.view">{{ __('Pharmacy') }}</x-nav-link>
            <x-nav-link route="laboratory.index" icon="flask" permission="lab.request.view">{{ __('Laboratory') }}</x-nav-link>
            <x-nav-link route="billing.index" icon="receipt" permission="billing.invoice.view">{{ __('Billing') }}</x-nav-link>
            <x-nav-link route="inventory.index" icon="box" permission="inventory.item.view">{{ __('Inventory') }}</x-nav-link>

            <p class="sidebar__group">{{ __('Administration') }}</p>
            <x-nav-link route="admin.sectors.index" icon="sectors" permission="org.sector.view">{{ __('Sectors') }}</x-nav-link>
            <x-nav-link route="admin.users.index" icon="users" permission="users.account.view">{{ __('Users') }}</x-nav-link>
            <x-nav-link route="reports.index" icon="chart" permission="reports.operational.view">{{ __('Reports') }}</x-nav-link>
            <x-nav-link route="admin.settings.edit" icon="settings" permission="settings.hospital.manage">{{ __('Settings') }}</x-nav-link>
            <x-nav-link route="admin.audit.index" icon="shield" permission="audit.log.view">{{ __('Audit trail') }}</x-nav-link>
        </nav>
    </aside>

    <div>
        <header class="topbar">
            <button type="button" class="btn btn--ghost" style="display:none" @click="nav = !nav"
                    x-init="$el.style.display = window.innerWidth < 920 ? 'inline-flex' : 'none'"
                    aria-label="{{ __('Show navigation') }}">
                <x-icon name="queue" />
            </button>

            <form class="topbar__search" action="{{ route('patients.index') }}" method="get" role="search">
                <x-icon name="search" size="16" />
                <label class="sr-only" for="global-search">{{ __('Find a patient') }}</label>
                <input id="global-search" type="search" name="q"
                       placeholder="{{ __('Find a patient by name, number or phone') }}">
            </form>

            <div style="margin-left:auto;display:flex;align-items:center;gap:var(--sp-3)">
                <span style="font-size:var(--t-sm);text-align:right;line-height:1.3">
                    <strong style="display:block">{{ auth()->user()->name }}</strong>
                    <span style="color:var(--arh-muted)">{{ auth()->user()->getRoleNames()->first() }}</span>
                </span>
                <form method="post" action="{{ route('logout') }}">
                    @csrf
                    <button class="btn btn--secondary btn--sm" type="submit">
                        <x-icon name="power" size="15" />{{ __('Sign out') }}
                    </button>
                </form>
            </div>
        </header>

        <main class="content">
            <x-flash />
            {{ $slot }}
        </main>
    </div>
</div>
</body>
</html>
