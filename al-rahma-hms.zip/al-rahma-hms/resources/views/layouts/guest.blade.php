<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title ?? __('Sign in') }} · {{ $branding->hospitalName() }}</title>
    <link rel="icon" href="{{ asset('favicon.ico') }}">
    @vite(['resources/css/app.css'])
</head>
<body>
    <main class="signin">
        <div class="signin__card">
            @if ($logo = $branding->logo('screen'))
                <img class="signin__logo" src="{{ $logo }}" alt="{{ $branding->hospitalName() }}">
            @else
                <h1 style="text-align:center">{{ $branding->hospitalName() }}</h1>
            @endif

            <x-flash />
            {{ $slot }}

            <p style="text-align:center;margin-top:var(--sp-5);font-size:var(--t-xs);color:var(--arh-muted)">
                {{ $branding->addressLine() }}
            </p>
        </div>
    </main>
</body>
</html>
