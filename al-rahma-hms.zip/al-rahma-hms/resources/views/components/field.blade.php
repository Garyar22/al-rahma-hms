@props(['name', 'label', 'required' => false, 'hint' => null])
<div class="field">
    <label for="{{ $name }}">
        {{ $label }}@if($required)<span class="req" aria-hidden="true"> *</span><span class="sr-only"> ({{ __('required') }})</span>@endif
    </label>
    {{ $slot }}
    @if ($hint)
        <p class="hint" id="{{ $name }}-hint">{{ $hint }}</p>
    @endif
    @error($name)
        <p class="error" id="{{ $name }}-error">{{ $message }}</p>
    @enderror
</div>
