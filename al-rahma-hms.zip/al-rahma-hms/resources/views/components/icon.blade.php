@props(['name', 'size' => 18])
{{--
  A small authored icon set: one stroke weight (1.5), one grid (24), one join.
  Emoji and unicode glyphs are not icons — they change shape per platform and
  break the moment the system is read on a different machine.
--}}
@php
$paths = [
    'dashboard' => '<path d="M4 13h7V4H4v9Zm0 7h7v-5H4v5Zm9 0h7v-9h-7v9Zm0-16v5h7V4h-7Z"/>',
    'patients'  => '<path d="M16 19v-1.5a3.5 3.5 0 0 0-3.5-3.5h-5A3.5 3.5 0 0 0 4 17.5V19"/><circle cx="10" cy="8" r="3.2"/><path d="M17 11.5a3 3 0 1 0-2-5.3M20 19v-1.3a3.2 3.2 0 0 0-2.2-3"/>',
    'calendar'  => '<rect x="3.5" y="5" width="17" height="15" rx="2"/><path d="M3.5 9.5h17M8 3.5v3M16 3.5v3"/>',
    'queue'     => '<path d="M4 7h16M4 12h11M4 17h7"/>',
    'stethoscope' => '<path d="M6 4v5a4 4 0 0 0 8 0V4M6 4H4.5M14 4h1.5"/><path d="M10 17v-4"/><circle cx="18" cy="15" r="2.5"/><path d="M18 12.5V11a4 4 0 0 0-4-4"/>',
    'bed'       => '<path d="M3 18V8M3 12h18v6M3 18h18M7.5 12V9.5h4a2 2 0 0 1 2 2V12"/>',
    'pill'      => '<rect x="3" y="9" width="18" height="6.5" rx="3.25" transform="rotate(-40 12 12)"/><path d="M9 9l6 6"/>',
    'flask'     => '<path d="M10 3.5v6L4.8 18a2 2 0 0 0 1.7 3h11a2 2 0 0 0 1.7-3L14 9.5v-6"/><path d="M8.5 3.5h7M7.6 14.5h8.8"/>',
    'receipt'   => '<path d="M6 3.5h12v17l-2-1.4-2 1.4-2-1.4-2 1.4-2-1.4-2 1.4v-17Z"/><path d="M9.5 8.5h5M9.5 12.5h5"/>',
    'box'       => '<path d="M3.5 7.5 12 3.5l8.5 4v9L12 20.5l-8.5-4v-9Z"/><path d="M3.5 7.5 12 11.5l8.5-4M12 11.5v9"/>',
    'users'     => '<circle cx="9" cy="8" r="3.2"/><path d="M3.5 19v-1.2A3.8 3.8 0 0 1 7.3 14h3.4a3.8 3.8 0 0 1 3.8 3.8V19"/><path d="M17 11a3 3 0 1 0-1.8-5.4M20.5 19v-1.4a3.4 3.4 0 0 0-2.4-3.2"/>',
    'chart'     => '<path d="M4 20V4"/><path d="M4 20h16"/><path d="M8 20v-6M12.5 20V9M17 20v-9"/>',
    'sectors'   => '<rect x="9" y="3.5" width="6" height="5" rx="1.2"/><rect x="3" y="15.5" width="6" height="5" rx="1.2"/><rect x="15" y="15.5" width="6" height="5" rx="1.2"/><path d="M12 8.5v4M6 15.5v-3h12v3"/>',
    'settings'  => '<circle cx="12" cy="12" r="3"/><path d="M19.4 14a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 0 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1v.2a2 2 0 1 1-4 0v-.1A1.6 1.6 0 0 0 7.1 18l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0-1.1-2.7H3a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 4.3 6l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V2a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 2.7 1.1l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H22a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1Z"/>',
    'shield'    => '<path d="M12 3.2 5 6v5.5c0 4.3 2.9 7.6 7 9.3 4.1-1.7 7-5 7-9.3V6l-7-2.8Z"/><path d="m9.2 12.2 2 2 3.6-3.9"/>',
    'search'    => '<circle cx="11" cy="11" r="6.2"/><path d="m16 16 4 4"/>',
    'plus'      => '<path d="M12 5v14M5 12h14"/>',
    'edit'      => '<path d="M4 20h4L19 9a2.1 2.1 0 0 0-3-3L5 17v3Z"/><path d="m15 6 3 3"/>',
    'trash'     => '<path d="M4.5 6.5h15M9.5 6.5V4.8c0-.7.6-1.3 1.3-1.3h2.4c.7 0 1.3.6 1.3 1.3v1.7"/><path d="M6.5 6.5 7.4 19a1.6 1.6 0 0 0 1.6 1.5h6a1.6 1.6 0 0 0 1.6-1.5l.9-12.5"/>',
    'eye'       => '<path d="M2.5 12S6 5.8 12 5.8 21.5 12 21.5 12 18 18.2 12 18.2 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="2.8"/>',
    'power'     => '<path d="M12 3.5v8"/><path d="M7.5 6.4a7.5 7.5 0 1 0 9 0"/>',
    'key'       => '<circle cx="8" cy="12" r="4"/><path d="M12 12h9M18 12v3M15.5 12v2.2"/>',
    'back'      => '<path d="M19 12H5M11 6l-6 6 6 6"/>',
    'lock'      => '<rect x="4.5" y="10.5" width="15" height="10" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
    'alert'     => '<path d="M12 4.5 2.8 20h18.4L12 4.5Z"/><path d="M12 10v4.2M12 17.2v.1"/>',
];
@endphp
<svg xmlns="http://www.w3.org/2000/svg" width="{{ $size }}" height="{{ $size }}" viewBox="0 0 24 24"
     fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"
     aria-hidden="true" focusable="false" {{ $attributes }}>
    {!! $paths[$name] ?? $paths['alert'] !!}
</svg>
