{{-- Flash messages name what happened and, on failure, what to do next. --}}
@if (session('success'))
    <div class="flash flash--success" role="status">
        <x-icon name="shield" />
        <div>{{ session('success') }}</div>
    </div>
@endif

@if (session('error'))
    <div class="flash flash--error" role="alert">
        <x-icon name="alert" />
        <div>{{ session('error') }}</div>
    </div>
@endif

@if (session('status'))
    <div class="flash flash--info" role="status">
        <x-icon name="lock" />
        <div>{{ session('status') }}</div>
    </div>
@endif

@if (session('temporary_password'))
    @php($slip = session('temporary_password'))
    <div class="credential">
        <strong>{{ __('Temporary sign-in details') }}</strong>
        <p style="margin:4px 0 0;font-size:var(--t-sm);color:var(--arh-muted)">
            {{ __('Write these down or print this page now. They are shown once, and the person must choose a new password when they first sign in.') }}
        </p>
        <dl>
            <dt>{{ __('Username') }}</dt><dd>{{ $slip['username'] }}</dd>
            <dt>{{ __('Password') }}</dt><dd>{{ $slip['password'] }}</dd>
        </dl>
    </div>
@endif
