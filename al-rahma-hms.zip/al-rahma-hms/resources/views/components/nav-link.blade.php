@props(['route', 'icon', 'permission' => null])
{{--
  A nav item appears only if the person can actually use it. Showing a link
  that returns 403 teaches staff to distrust the menu.
  Routes not yet built are skipped silently so the shell stays valid while the
  remaining modules are implemented.
--}}
@if ((! $permission || auth()->user()?->can($permission)) && \Illuminate\Support\Facades\Route::has($route))
    <a href="{{ route($route) }}" class="sidebar__link"
       @if (request()->routeIs(\Illuminate\Support\Str::beforeLast($route, '.') . '.*')) aria-current="page" @endif>
        <x-icon :name="$icon" />
        <span>{{ $slot }}</span>
    </a>
@endif
