<x-layouts.app :title="__('Dashboard')">
    <div class="page-head">
        <div>
            <h1>{{ __('Good :part, :name', ['part' => $greeting, 'name' => \Illuminate\Support\Str::before(auth()->user()->name, ' ')]) }}</h1>
            <p>{{ $today }}</p>
        </div>
    </div>

    <div class="panel">
        <div class="panel__body">
            <div class="empty">
                <h3>{{ __('The clinical modules are still being built') }}</h3>
                <p>{{ __('Sign-in, roles, the hospital structure and user accounts are working. Patients, appointments and the clinical workflow follow in the next phase.') }}</p>
                @can('org.sector.view')
                    <a class="btn btn--primary" href="{{ route('admin.sectors.index') }}">{{ __('Set up the hospital structure') }}</a>
                @endcan
            </div>
        </div>
    </div>
</x-layouts.app>
