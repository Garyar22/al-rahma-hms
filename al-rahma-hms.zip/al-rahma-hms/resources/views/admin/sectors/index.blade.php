<x-layouts.app :title="__('Sectors')">
    <div class="page-head">
        <div>
            <h1>{{ __('Hospital structure') }}</h1>
            <p>{{ __('Sectors, departments and units — the hospital’s own shape. Add, rename, move or close any of them here; nothing requires a developer.') }}</p>
        </div>
        @can('create', \App\Models\Department::class)
            <a class="btn btn--primary" href="{{ route('admin.sectors.create') }}">
                <x-icon name="plus" size="16" />{{ __('Add sector') }}
            </a>
        @endcan
    </div>

    <div class="panel">
        <div class="panel__head">
            <form method="get" class="topbar__search" style="max-width:340px">
                <x-icon name="search" size="16" />
                <label class="sr-only" for="q">{{ __('Search sectors') }}</label>
                <input id="q" type="search" name="q" value="{{ $search }}" placeholder="{{ __('Search by name or code') }}">
            </form>
            @if ($search)
                <a class="btn btn--ghost btn--sm" href="{{ route('admin.sectors.index') }}">{{ __('Show the whole structure') }}</a>
            @endif
        </div>

        @if ($matches !== null)
            @forelse ($matches as $sector)
                <div class="tree__row {{ $sector->is_active ? '' : 'tree__row--inactive' }}">
                    <x-icon name="sectors" size="16" />
                    <div>
                        <div class="tree__name"><a href="{{ route('admin.sectors.show', $sector) }}">{{ $sector->name }}</a></div>
                        <div class="tree__meta">{{ $sector->pathLabel() }}</div>
                    </div>
                </div>
            @empty
                <div class="empty">
                    <h3>{{ __('Nothing matches “:q”', ['q' => $search]) }}</h3>
                    <p>{{ __('Try part of the name, or the short code such as OPD.') }}</p>
                </div>
            @endforelse
        @elseif ($tree->isEmpty())
            <div class="empty">
                <h3>{{ __('The structure is empty') }}</h3>
                <p>{{ __('Start with a broad sector such as Clinical Services, then add the departments that sit inside it.') }}</p>
                @can('create', \App\Models\Department::class)
                    <a class="btn btn--primary" href="{{ route('admin.sectors.create') }}">{{ __('Add the first sector') }}</a>
                @endcan
            </div>
        @else
            <ul class="tree">
                @foreach ($tree as $node)
                    @include('admin.sectors._node', ['node' => $node, 'moduleMap' => $moduleMap])
                @endforeach
            </ul>
        @endif
    </div>
</x-layouts.app>
