<x-layouts.app :title="$sector->name">
    <div class="page-head">
        <div>
            <h1>{{ $sector->name }}</h1>
            <p>{{ $sector->pathLabel() }}</p>
        </div>
        <div style="display:flex;gap:var(--sp-3)">
            @can('update', $sector)
                <a class="btn btn--primary" href="{{ route('admin.sectors.edit', $sector) }}">
                    <x-icon name="edit" size="16" />{{ __('Edit') }}
                </a>
            @endcan
            <a class="btn btn--secondary" href="{{ route('admin.sectors.index') }}">{{ __('Back to structure') }}</a>
        </div>
    </div>

    <div style="display:grid;grid-template-columns:minmax(0,1.6fr) minmax(0,1fr);gap:var(--sp-5);align-items:start">
        <div class="panel">
            <div class="panel__head">
                <h2>{{ __('Details') }}</h2>
                <div style="display:flex;gap:6px">
                    <span class="badge {{ $sector->is_active ? 'badge--open' : 'badge--closed' }}">
                        {{ $sector->is_active ? __('Open') : __('Closed') }}
                    </span>
                    @if ($sector->is_system)
                        <span class="badge badge--system">{{ __('Core') }}</span>
                    @endif
                </div>
            </div>
            <div class="panel__body">
                <table class="data">
                    <tbody>
                    <tr><th style="width:38%">{{ __('Short code') }}</th><td>{{ $sector->code }}</td></tr>
                    <tr><th>{{ __('Level') }}</th><td>{{ ucfirst($sector->kind?->value ?? '') }}</td></tr>
                    <tr><th>{{ __('Kind of work') }}</th><td>{{ ucfirst($sector->type) }}</td></tr>
                    <tr><th>{{ __('Where it is') }}</th><td>{{ $sector->location_note ?: '—' }}</td></tr>
                    <tr><th>{{ __('Extension') }}</th><td>{{ $sector->phone_extension ?: '—' }}</td></tr>
                    <tr><th>{{ __('Head of sector') }}</th>
                        <td>{{ $sector->head ? $sector->head->first_name.' '.$sector->head->last_name : __('Not assigned') }}</td></tr>
                    <tr><th>{{ __('Booked appointments') }}</th><td>{{ $sector->accepts_appointments ? __('Yes') : __('No') }}</td></tr>
                    <tr><th>{{ __('Walk-in patients') }}</th><td>{{ $sector->accepts_walkins ? __('Yes') : __('No') }}</td></tr>
                    <tr><th>{{ __('Uses') }}</th>
                        <td>
                            @if ($sector->modules)
                                <div class="chips">
                                    @foreach ($sector->modules as $module)
                                        <span class="chip">{{ $moduleMap[$module] ?? $module }}</span>
                                    @endforeach
                                </div>
                            @else — @endif
                        </td></tr>
                    @if ($sector->description)
                        <tr><th>{{ __('Notes') }}</th><td>{{ $sector->description }}</td></tr>
                    @endif
                    </tbody>
                </table>
            </div>
        </div>

        <div style="display:grid;gap:var(--sp-5)">
            <div class="panel">
                <div class="panel__head"><h2>{{ __('What points at it') }}</h2></div>
                <div class="panel__body">
                    <table class="data">
                        <tbody>
                        @foreach ($usage as $label => $count)
                            <tr><th>{{ $label }}</th><td class="num">{{ number_format($count) }}</td></tr>
                        @endforeach
                        </tbody>
                    </table>

                    @php($check = $sector->deletionCheck())
                    <p style="margin:var(--sp-4) 0 0;font-size:var(--t-sm);color:var(--arh-muted)">
                        {{ $check['allowed']
                            ? __('Nothing depends on this sector yet, so it can still be deleted.')
                            : $check['reason'] }}
                    </p>
                </div>
            </div>

            @if ($sector->children->isNotEmpty())
                <div class="panel">
                    <div class="panel__head"><h2>{{ __('Inside it') }}</h2></div>
                    <ul class="tree">
                        @foreach ($sector->children as $child)
                            <li><div class="tree__row">
                                <x-icon name="sectors" size="16" />
                                <div class="tree__name"><a href="{{ route('admin.sectors.show', $child) }}">{{ $child->name }}</a></div>
                            </div></li>
                        @endforeach
                    </ul>
                </div>
            @endif
        </div>
    </div>
</x-layouts.app>
