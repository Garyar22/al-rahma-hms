<li>
    <div class="tree__row {{ $node->is_active ? '' : 'tree__row--inactive' }}">
        <x-icon name="sectors" size="16" />

        <div style="min-width:0">
            <div class="tree__name">
                <a href="{{ route('admin.sectors.show', $node) }}">{{ $node->name }}</a>
                @unless ($node->is_active)
                    <span class="badge badge--closed">{{ __('Closed') }}</span>
                @endunless
                @if ($node->is_system)
                    <span class="badge badge--system" title="{{ __('The system depends on this sector. It can be renamed, but not deleted.') }}">{{ __('Core') }}</span>
                @endif
            </div>
            <div class="tree__meta">
                {{ $node->code }}
                @if ($node->modules)
                    · {{ collect($node->modules)->map(fn ($m) => $moduleMap[$m] ?? $m)->implode(', ') }}
                @endif
            </div>
        </div>

        <div class="tree__actions">
            @can('create', \App\Models\Department::class)
                <a class="btn btn--ghost btn--sm" href="{{ route('admin.sectors.create', ['parent' => $node->id]) }}"
                   title="{{ __('Add a sector inside :name', ['name' => $node->name]) }}">
                    <x-icon name="plus" size="15" /><span class="sr-only">{{ __('Add inside') }}</span>
                </a>
            @endcan
            @can('update', $node)
                <a class="btn btn--ghost btn--sm" href="{{ route('admin.sectors.edit', $node) }}">
                    <x-icon name="edit" size="15" /><span class="sr-only">{{ __('Edit') }}</span>
                </a>
            @endcan
            @can('deactivate', $node)
                <form method="post" action="{{ route('admin.sectors.deactivate', $node) }}"
                      onsubmit="return confirm(@js($node->is_active
                        ? __('Close :name? Staff will no longer be able to register patients against it. Its history stays intact.', ['name' => $node->name])
                        : __('Reopen :name?', ['name' => $node->name])))">
                    @csrf
                    <button class="btn btn--ghost btn--sm" type="submit">
                        <x-icon name="power" size="15" />
                        <span class="sr-only">{{ $node->is_active ? __('Close') : __('Reopen') }}</span>
                    </button>
                </form>
            @endcan
            @can('delete', $node)
                <form method="post" action="{{ route('admin.sectors.destroy', $node) }}"
                      onsubmit="return confirm(@js(__('Delete :name permanently? Use Close instead if it has any history.', ['name' => $node->name])))">
                    @csrf
                    @method('delete')
                    <button class="btn btn--ghost btn--sm" type="submit" style="color:#B42318">
                        <x-icon name="trash" size="15" /><span class="sr-only">{{ __('Delete') }}</span>
                    </button>
                </form>
            @endcan
        </div>
    </div>

    @if ($node->children->isNotEmpty())
        <ul>
            @foreach ($node->children as $child)
                @include('admin.sectors._node', ['node' => $child, 'moduleMap' => $moduleMap])
            @endforeach
        </ul>
    @endif
</li>
