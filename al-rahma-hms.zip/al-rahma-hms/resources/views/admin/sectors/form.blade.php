<x-layouts.app :title="$sector->exists ? __('Edit sector') : __('Add sector')">
    <div class="page-head">
        <div>
            <h1>{{ $sector->exists ? $sector->name : __('Add a sector') }}</h1>
            <p>
                @if ($sector->exists)
                    {{ $sector->pathLabel() }}
                @else
                    {{ __('A sector can hold departments, and a department can hold units. Build the structure the way the hospital actually works.') }}
                @endif
            </p>
        </div>
        <a class="btn btn--secondary" href="{{ route('admin.sectors.index') }}">
            <x-icon name="back" size="16" />{{ __('Back to structure') }}
        </a>
    </div>

    <form method="post" action="{{ $sector->exists ? route('admin.sectors.update', $sector) : route('admin.sectors.store') }}">
        @csrf
        @if ($sector->exists) @method('put') @endif

        <div style="display:grid;grid-template-columns:minmax(0,1.6fr) minmax(0,1fr);gap:var(--sp-5);align-items:start">

            <div class="panel">
                <div class="panel__head"><h2>{{ __('Name and place') }}</h2></div>
                <div class="panel__body">

                    <x-field name="name" :label="__('Name')" required
                             :hint="__('What staff call it, for example Outpatient, Maternity or Radiology.')">
                        <input id="name" name="name" type="text" required maxlength="120"
                               value="{{ old('name', $sector->name) }}"
                               class="@error('name') is-invalid @enderror">
                    </x-field>

                    <x-field name="code" :label="__('Short code')"
                             :hint="__('Used on reports and queue slips. Left blank, one is generated from the name.')">
                        <input id="code" name="code" type="text" maxlength="30"
                               value="{{ old('code', $sector->code) }}"
                               class="@error('code') is-invalid @enderror">
                    </x-field>

                    <x-field name="parent_id" :label="__('Sits inside')"
                             :hint="__('Leave as “Top level” for a main sector.')">
                        <select id="parent_id" name="parent_id">
                            <option value="">{{ __('Top level') }}</option>
                            @foreach ($parents as $parent)
                                <option value="{{ $parent->id }}" @selected((int) old('parent_id', $sector->parent_id) === $parent->id)>
                                    {{ $parent->pathLabel() }}
                                </option>
                            @endforeach
                        </select>
                    </x-field>

                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--sp-4)">
                        <x-field name="kind" :label="__('Level')" required>
                            <select id="kind" name="kind" required>
                                @foreach (['sector' => __('Sector'), 'department' => __('Department'), 'unit' => __('Unit')] as $value => $label)
                                    <option value="{{ $value }}" @selected(old('kind', $sector->kind?->value ?? 'department') === $value)>{{ $label }}</option>
                                @endforeach
                            </select>
                        </x-field>

                        <x-field name="type" :label="__('Kind of work')" required>
                            <select id="type" name="type" required>
                                @foreach (['clinical' => __('Clinical'), 'support' => __('Diagnostic or support'), 'administrative' => __('Administrative')] as $value => $label)
                                    <option value="{{ $value }}" @selected(old('type', $sector->type) === $value)>{{ $label }}</option>
                                @endforeach
                            </select>
                        </x-field>
                    </div>

                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--sp-4)">
                        <x-field name="location_note" :label="__('Where it is')">
                            <input id="location_note" name="location_note" type="text" maxlength="120"
                                   placeholder="{{ __('Block B, ground floor') }}"
                                   value="{{ old('location_note', $sector->location_note) }}">
                        </x-field>

                        <x-field name="phone_extension" :label="__('Extension')">
                            <input id="phone_extension" name="phone_extension" type="text" maxlength="20"
                                   value="{{ old('phone_extension', $sector->phone_extension) }}">
                        </x-field>
                    </div>

                    <x-field name="head_employee_id" :label="__('Head of sector')">
                        <select id="head_employee_id" name="head_employee_id">
                            <option value="">{{ __('Not assigned') }}</option>
                            @foreach ($employees as $employee)
                                <option value="{{ $employee->id }}" @selected((int) old('head_employee_id', $sector->head_employee_id) === $employee->id)>
                                    {{ $employee->first_name }} {{ $employee->last_name }} — {{ $employee->job_title }}
                                </option>
                            @endforeach
                        </select>
                    </x-field>

                    <x-field name="description" :label="__('Notes')">
                        <textarea id="description" name="description" rows="3" maxlength="500">{{ old('description', $sector->description) }}</textarea>
                    </x-field>
                </div>
            </div>

            <div style="display:grid;gap:var(--sp-5)">
                <div class="panel">
                    <div class="panel__head"><h2>{{ __('What it uses') }}</h2></div>
                    <div class="panel__body">
                        <p style="margin:0 0 var(--sp-3);font-size:var(--t-sm);color:var(--arh-muted)">
                            {{ __('Tick the parts of the system this sector works with. Switching one on adds it to this sector’s screens; it does not change any other sector.') }}
                        </p>

                        @foreach ($moduleMap as $key => $label)
                            <div class="check">
                                <input type="checkbox" id="module-{{ $key }}" name="modules[]" value="{{ $key }}"
                                       @checked(in_array($key, old('modules', $sector->modules ?? []), true))>
                                <label for="module-{{ $key }}">{{ $label }}</label>
                            </div>
                        @endforeach
                        @error('modules.*')<p class="error">{{ $message }}</p>@enderror
                    </div>
                </div>

                <div class="panel">
                    <div class="panel__head"><h2>{{ __('How patients reach it') }}</h2></div>
                    <div class="panel__body">
                        <div class="check">
                            <input type="checkbox" id="accepts_appointments" name="accepts_appointments" value="1"
                                   @checked(old('accepts_appointments', $sector->accepts_appointments))>
                            <div>
                                <label for="accepts_appointments">{{ __('Takes booked appointments') }}</label>
                                <p class="hint">{{ __('Reception can book a doctor here in advance.') }}</p>
                            </div>
                        </div>

                        <div class="check">
                            <input type="checkbox" id="accepts_walkins" name="accepts_walkins" value="1"
                                   @checked(old('accepts_walkins', $sector->accepts_walkins))>
                            <div>
                                <label for="accepts_walkins">{{ __('Takes walk-in patients') }}</label>
                                <p class="hint">{{ __('Appears in the queue when a patient arrives without an appointment.') }}</p>
                            </div>
                        </div>

                        <div class="check">
                            <input type="checkbox" id="is_active" name="is_active" value="1"
                                   @checked(old('is_active', $sector->is_active ?? true))>
                            <div>
                                <label for="is_active">{{ __('Open') }}</label>
                                <p class="hint">{{ __('Closing it hides it from every picker. Anything inside it closes too, and all past records stay readable.') }}</p>
                            </div>
                        </div>

                        <x-field name="display_order" :label="__('Order in lists')">
                            <input id="display_order" name="display_order" type="number" min="0" max="9999"
                                   value="{{ old('display_order', $sector->display_order ?? 0) }}" style="max-width:120px">
                        </x-field>
                    </div>
                </div>
            </div>
        </div>

        <div style="display:flex;gap:var(--sp-3);margin-top:var(--sp-5)">
            <button class="btn btn--primary" type="submit">
                {{ $sector->exists ? __('Save changes') : __('Add sector') }}
            </button>
            <a class="btn btn--secondary" href="{{ route('admin.sectors.index') }}">{{ __('Cancel') }}</a>
        </div>
    </form>
</x-layouts.app>
