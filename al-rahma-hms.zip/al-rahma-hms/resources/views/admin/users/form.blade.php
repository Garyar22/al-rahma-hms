<x-layouts.app :title="$user->exists ? __('Edit user') : __('Add user')">
    <div class="page-head">
        <div>
            <h1>{{ $user->exists ? $user->name : __('Add a user') }}</h1>
            <p>
                @if ($user->exists)
                    {{ __('Changing the role changes what this person can see and do, immediately.') }}
                @else
                    {{ __('A temporary password is generated and shown once. The person chooses their own password when they first sign in.') }}
                @endif
            </p>
        </div>
        <a class="btn btn--secondary" href="{{ route('admin.users.index') }}">
            <x-icon name="back" size="16" />{{ __('Back to users') }}
        </a>
    </div>

    <form method="post" action="{{ $user->exists ? route('admin.users.update', $user) : route('admin.users.store') }}">
        @csrf
        @if ($user->exists) @method('put') @endif

        <div class="panel" style="max-width:640px">
            <div class="panel__body">

                <x-field name="name" :label="__('Full name')" required>
                    <input id="name" name="name" type="text" required maxlength="120"
                           value="{{ old('name', $user->name) }}" class="@error('name') is-invalid @enderror">
                </x-field>

                <x-field name="username" :label="__('Username')" required
                         :hint="__('What they type to sign in. Letters, numbers, dots, dashes and underscores.')">
                    <input id="username" name="username" type="text" required minlength="3" maxlength="40"
                           value="{{ old('username', $user->username) }}" class="@error('username') is-invalid @enderror">
                </x-field>

                <x-field name="email" :label="__('Email')" :hint="__('Optional. Not used for signing in.')">
                    <input id="email" name="email" type="email" maxlength="160"
                           value="{{ old('email', $user->email) }}" class="@error('email') is-invalid @enderror">
                </x-field>

                <x-field name="employee_id" :label="__('Staff record')"
                         :hint="__('Links this login to a person in the staff register, so attendance and clinical records line up.')">
                    <select id="employee_id" name="employee_id">
                        <option value="">{{ __('Not linked') }}</option>
                        @foreach ($employees as $employee)
                            <option value="{{ $employee->id }}" @selected((int) old('employee_id', $user->employee_id) === $employee->id)>
                                {{ $employee->first_name }} {{ $employee->last_name }} — {{ $employee->job_title }}
                            </option>
                        @endforeach
                    </select>
                </x-field>

                @if ($user->is_protected)
                    <div class="flash flash--info">
                        <x-icon name="shield" />
                        <div>{{ __('This is the hospital’s System Owner account. Its role is fixed, and it cannot be deactivated or deleted — so the hospital can never be locked out of its own system.') }}</div>
                    </div>
                @else
                    <x-field name="role" :label="__('Role')" required
                             :hint="__('A role decides which screens and actions this person has. One role per person.')">
                        <select id="role" name="role" required class="@error('role') is-invalid @enderror">
                            @foreach ($roles as $role)
                                <option value="{{ $role->name }}" @selected(old('role', $user->getRoleNames()->first()) === $role->name)>
                                    {{ $role->name }}
                                </option>
                            @endforeach
                        </select>
                    </x-field>
                @endif
            </div>
        </div>

        <div style="display:flex;gap:var(--sp-3);margin-top:var(--sp-5)">
            <button class="btn btn--primary" type="submit">
                {{ $user->exists ? __('Save changes') : __('Create account') }}
            </button>
            <a class="btn btn--secondary" href="{{ route('admin.users.index') }}">{{ __('Cancel') }}</a>
        </div>
    </form>
</x-layouts.app>
