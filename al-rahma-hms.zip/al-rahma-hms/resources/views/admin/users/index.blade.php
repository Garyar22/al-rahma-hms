<x-layouts.app :title="__('Users')">
    <div class="page-head">
        <div>
            <h1>{{ __('User accounts') }}</h1>
            <p>{{ __('One account per person. Shared logins break the audit trail, which is how the hospital knows who recorded what.') }}</p>
        </div>
        @can('create', \App\Models\User::class)
            <a class="btn btn--primary" href="{{ route('admin.users.create') }}">
                <x-icon name="plus" size="16" />{{ __('Add user') }}
            </a>
        @endcan
    </div>

    <div class="panel">
        <div class="panel__head">
            <form method="get" style="display:flex;gap:var(--sp-3);align-items:center;flex-wrap:wrap">
                <div class="topbar__search" style="max-width:280px">
                    <x-icon name="search" size="16" />
                    <label class="sr-only" for="q">{{ __('Search users') }}</label>
                    <input id="q" type="search" name="q" value="{{ $search }}" placeholder="{{ __('Name or username') }}">
                </div>

                <label class="sr-only" for="role">{{ __('Role') }}</label>
                <select id="role" name="role" style="width:auto" onchange="this.form.submit()">
                    <option value="">{{ __('All roles') }}</option>
                    @foreach ($roles as $role)
                        <option value="{{ $role->name }}" @selected(request('role') === $role->name)>{{ $role->name }}</option>
                    @endforeach
                </select>

                <label class="sr-only" for="status">{{ __('Status') }}</label>
                <select id="status" name="status" style="width:auto" onchange="this.form.submit()">
                    <option value="">{{ __('Active only') }}</option>
                    <option value="inactive" @selected(request('status') === 'inactive')>{{ __('Deactivated only') }}</option>
                    <option value="all" @selected(request('status') === 'all')>{{ __('Everyone') }}</option>
                </select>
            </form>
        </div>

        @if ($users->isEmpty())
            <div class="empty">
                <h3>{{ __('No accounts match this filter') }}</h3>
                <p>{{ __('Change the filters above, or add the first account for this role.') }}</p>
            </div>
        @else
            <div class="table-wrap">
                <table class="data">
                    <thead>
                    <tr>
                        <th>{{ __('Name') }}</th>
                        <th>{{ __('Username') }}</th>
                        <th>{{ __('Role') }}</th>
                        <th>{{ __('Staff record') }}</th>
                        <th>{{ __('Last signed in') }}</th>
                        <th>{{ __('Status') }}</th>
                        <th><span class="sr-only">{{ __('Actions') }}</span></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach ($users as $user)
                        <tr>
                            <td>
                                {{ $user->name }}
                                @if ($user->is_protected)
                                    <span class="badge badge--system" title="{{ __('The hospital’s own account. It cannot be deleted or deactivated.') }}">
                                        {{ __('System Owner') }}
                                    </span>
                                @endif
                            </td>
                            <td>{{ $user->username }}</td>
                            <td>{{ $user->getRoleNames()->first() ?? '—' }}</td>
                            <td>{{ $user->employee?->first_name }} {{ $user->employee?->last_name ?: '—' }}</td>
                            <td>{{ $user->last_login_at?->diffForHumans() ?? __('Never') }}</td>
                            <td>
                                @if (! $user->is_active)
                                    <span class="badge badge--closed">{{ __('Deactivated') }}</span>
                                @elseif ($user->isLockedOut())
                                    <span class="badge badge--warning">{{ __('Locked') }}</span>
                                @elseif ($user->must_change_password)
                                    <span class="badge badge--warning">{{ __('Password not set') }}</span>
                                @else
                                    <span class="badge badge--open">{{ __('Active') }}</span>
                                @endif
                            </td>
                            <td style="text-align:right;white-space:nowrap">
                                @can('update', $user)
                                    <a class="btn btn--ghost btn--sm" href="{{ route('admin.users.edit', $user) }}">
                                        <x-icon name="edit" size="15" /><span class="sr-only">{{ __('Edit :name', ['name' => $user->name]) }}</span>
                                    </a>
                                @endcan
                                @can('resetPassword', $user)
                                    <form method="post" action="{{ route('admin.users.password', $user) }}" style="display:inline"
                                          onsubmit="return confirm(@js(__('Issue a new temporary password for :name? Their current password stops working immediately.', ['name' => $user->name])))">
                                        @csrf
                                        <button class="btn btn--ghost btn--sm" type="submit">
                                            <x-icon name="key" size="15" /><span class="sr-only">{{ __('Reset password') }}</span>
                                        </button>
                                    </form>
                                @endcan
                                @can('deactivate', $user)
                                    <form method="post" action="{{ route('admin.users.toggle', $user) }}" style="display:inline"
                                          onsubmit="return confirm(@js($user->is_active
                                            ? __('Deactivate :name? They can no longer sign in, and everything they recorded stays in their name.', ['name' => $user->name])
                                            : __('Let :name sign in again?', ['name' => $user->name])))">
                                        @csrf
                                        <button class="btn btn--ghost btn--sm" type="submit">
                                            <x-icon name="power" size="15" />
                                            <span class="sr-only">{{ $user->is_active ? __('Deactivate') : __('Reactivate') }}</span>
                                        </button>
                                    </form>
                                @endcan
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>

            <div class="panel__body">{{ $users->links() }}</div>
        @endif
    </div>
</x-layouts.app>
