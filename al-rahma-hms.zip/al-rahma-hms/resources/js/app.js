/*
 | Alpine is the only JavaScript dependency, and it is bundled locally: the
 | hospital server routinely has no internet, so a CDN would mean a dead
 | sidebar toggle on the day the link drops.
 */
import Alpine from 'alpinejs';

window.Alpine = Alpine;
Alpine.start();
