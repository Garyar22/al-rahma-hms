<?php

declare(strict_types=1);

use App\Models\User;
use Database\Seeders\RolePermissionSeeder;
use Database\Seeders\SystemOwnerSeeder;

/*
 | The hospital must never be able to lock itself out of its own system, and
 | an administrator must never be able to quietly take over the owner account.
 */

beforeEach(function (): void {
    $this->seed(RolePermissionSeeder::class);
});

it('creates a protected owner account with no password in the source', function (): void {
    $this->seed(SystemOwnerSeeder::class);

    $owner = User::where('is_protected', true)->firstOrFail();

    expect($owner->isSystemOwner())->toBeTrue()
        ->and($owner->must_change_password)->toBeTrue()
        ->and($owner->is_active)->toBeTrue();
});

it('refuses to deactivate the owner account', function (): void {
    $this->seed(SystemOwnerSeeder::class);

    $owner = User::where('is_protected', true)->firstOrFail();

    $this->actingAs($owner)
        ->post(route('admin.users.toggle', $owner))
        ->assertForbidden();

    expect($owner->fresh()->is_active)->toBeTrue();
});

it('refuses to let an administrator edit the owner account', function (): void {
    $this->seed(SystemOwnerSeeder::class);

    $owner = User::where('is_protected', true)->firstOrFail();
    $admin = User::factory()->create(['must_change_password' => false]);
    $admin->assignRole('super-admin');

    $this->actingAs($admin)->get(route('admin.users.edit', $owner))->assertForbidden();
});

it('never offers the owner role in the user form', function (): void {
    $admin = User::factory()->create(['must_change_password' => false]);
    $admin->assignRole('super-admin');

    $this->actingAs($admin)
        ->post(route('admin.users.store'), [
            'name' => 'Test Person', 'username' => 'test.person', 'role' => 'system-owner',
        ])
        ->assertSessionHasErrors('role');
});

it('stops anyone deactivating their own account', function (): void {
    $admin = User::factory()->create(['must_change_password' => false]);
    $admin->assignRole('super-admin');

    $this->actingAs($admin)->post(route('admin.users.toggle', $admin))->assertForbidden();
});

it('issues a temporary password that must be changed at the next sign-in', function (): void {
    $admin = User::factory()->create(['must_change_password' => false]);
    $admin->assignRole('super-admin');

    $staff = User::factory()->create(['must_change_password' => false]);
    $staff->assignRole('nurse');

    $this->actingAs($admin)
        ->post(route('admin.users.password', $staff))
        ->assertSessionHas('temporary_password');

    expect($staff->fresh()->must_change_password)->toBeTrue();
});
