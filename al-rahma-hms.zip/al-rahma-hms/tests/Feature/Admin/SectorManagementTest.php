<?php

declare(strict_types=1);

use App\Models\Department;
use App\Models\User;
use App\Models\Visit;
use Database\Seeders\RolePermissionSeeder;

/*
 | The administration owns the hospital's structure — and the guard rails that
 | stop a reorganisation from breaking the records underneath it.
 */

beforeEach(function (): void {
    $this->seed(RolePermissionSeeder::class);
});

function admin(): User
{
    return User::factory()->create(['must_change_password' => false])->assignRole('super-admin');
}

function receptionist(): User
{
    return User::factory()->create(['must_change_password' => false])->assignRole('receptionist');
}

it('lets an administrator add a sector', function (): void {
    $this->actingAs(admin())
        ->post(route('admin.sectors.store'), [
            'name'      => 'Radiology',
            'kind'      => 'department',
            'type'      => 'support',
            'modules'   => ['billing'],
            'is_active' => '1',
        ])
        ->assertRedirect(route('admin.sectors.index'));

    expect(Department::where('name', 'Radiology')->exists())->toBeTrue();
});

it('generates a unique code when none is given', function (): void {
    $this->actingAs(admin())->post(route('admin.sectors.store'), [
        'name' => 'Physiotherapy', 'kind' => 'unit', 'type' => 'support',
    ]);

    expect(Department::where('name', 'Physiotherapy')->first()->code)->not->toBeEmpty();
});

it('lets an administrator nest a department inside a sector', function (): void {
    $parent = Department::factory()->create(['name' => 'Clinical Services', 'kind' => 'sector']);

    $this->actingAs(admin())->post(route('admin.sectors.store'), [
        'name' => 'Paediatrics', 'parent_id' => $parent->id, 'kind' => 'department', 'type' => 'clinical',
    ]);

    expect(Department::where('name', 'Paediatrics')->first()->parent_id)->toBe($parent->id);
});

it('refuses to move a sector inside its own child', function (): void {
    $parent = Department::factory()->create();
    $child  = Department::factory()->create(['parent_id' => $parent->id]);

    $this->actingAs(admin())
        ->put(route('admin.sectors.update', $parent), [
            'name' => $parent->name, 'parent_id' => $child->id,
            'kind' => 'sector', 'type' => 'clinical',
        ])
        ->assertSessionHas('error');

    expect($parent->fresh()->parent_id)->toBeNull();
});

it('closes every sector inside one that is closed', function (): void {
    $parent = Department::factory()->create(['is_active' => true]);
    $child  = Department::factory()->create(['parent_id' => $parent->id, 'is_active' => true]);

    $this->actingAs(admin())->put(route('admin.sectors.update', $parent), [
        'name' => $parent->name, 'kind' => 'sector', 'type' => 'clinical', 'is_active' => '0',
    ]);

    expect($child->fresh()->is_active)->toBeFalse();
});

it('never deletes a core sector the system depends on', function (): void {
    $core = Department::factory()->create(['is_system' => true]);

    $this->actingAs(admin())
        ->delete(route('admin.sectors.destroy', $core))
        ->assertForbidden();

    expect(Department::find($core->id))->not->toBeNull();
});

it('refuses to delete a sector that patient visits point at', function (): void {
    $sector = Department::factory()->create();
    Visit::factory()->create(['department_id' => $sector->id]);

    $this->actingAs(admin())
        ->delete(route('admin.sectors.destroy', $sector))
        ->assertForbidden();

    expect(Department::find($sector->id))->not->toBeNull();
});

it('deletes a sector nothing depends on', function (): void {
    $sector = Department::factory()->create(['is_system' => false]);

    $this->actingAs(admin())
        ->delete(route('admin.sectors.destroy', $sector))
        ->assertRedirect(route('admin.sectors.index'));

    expect(Department::find($sector->id))->toBeNull()
        ->and(Department::withTrashed()->find($sector->id))->not->toBeNull(); // history survives
});

it('keeps a receptionist out of the structure screens entirely', function (): void {
    $sector = Department::factory()->create();

    $this->actingAs(receptionist())->get(route('admin.sectors.index'))->assertForbidden();
    $this->actingAs(receptionist())->get(route('admin.sectors.create'))->assertForbidden();
    $this->actingAs(receptionist())->delete(route('admin.sectors.destroy', $sector))->assertForbidden();
});
