<?php

declare(strict_types=1);

use App\Models\AuditLog;
use App\Models\User;

it('signs a member of staff in with their username', function (): void {
    $user = User::factory()->create([
        'username'             => 'amina.yusuf',
        'password'             => 'correct-horse-battery-7',
        'must_change_password' => false,
    ]);

    $this->post(route('login'), ['username' => 'amina.yusuf', 'password' => 'correct-horse-battery-7'])
        ->assertRedirect(route('dashboard'));

    $this->assertAuthenticatedAs($user);
});

it('does not reveal whether the username or the password was wrong', function (): void {
    User::factory()->create(['username' => 'amina.yusuf', 'password' => 'correct-horse-battery-7']);

    $wrongPassword = $this->post(route('login'), ['username' => 'amina.yusuf', 'password' => 'nope']);
    $wrongUsername = $this->post(route('login'), ['username' => 'nobody.here', 'password' => 'nope']);

    expect($wrongPassword->getSession()->get('errors')->first('username'))
        ->toBe($wrongUsername->getSession()->get('errors')->first('username'));
});

it('records failed sign-in attempts in the audit trail', function (): void {
    User::factory()->create(['username' => 'amina.yusuf']);

    $this->post(route('login'), ['username' => 'amina.yusuf', 'password' => 'wrong']);

    expect(AuditLog::where('action', 'auth.login_failed')->exists())->toBeTrue();
});

it('locks an account after repeated failures', function (): void {
    $user = User::factory()->create(['username' => 'amina.yusuf']);

    foreach (range(1, (int) config('hospital.security.max_login_attempts', 5)) as $ignored) {
        $this->post(route('login'), ['username' => 'amina.yusuf', 'password' => 'wrong']);
    }

    expect($user->fresh()->isLockedOut())->toBeTrue();
});

it('refuses a deactivated account', function (): void {
    User::factory()->create([
        'username' => 'former.staff', 'password' => 'correct-horse-battery-7', 'is_active' => false,
    ]);

    $this->post(route('login'), ['username' => 'former.staff', 'password' => 'correct-horse-battery-7'])
        ->assertSessionHasErrors('username');

    $this->assertGuest();
});

it('sends a first-time user to choose a password before anything else', function (): void {
    $user = User::factory()->create(['must_change_password' => true]);

    $this->actingAs($user)->get(route('dashboard'))->assertRedirect(route('password.change'));
});
