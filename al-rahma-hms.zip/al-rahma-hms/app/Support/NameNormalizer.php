<?php

declare(strict_types=1);

namespace App\Support;

/**
 * Transliteration-tolerant name folding for Somali patient names.
 *
 * The problem this solves is the single biggest threat to data quality in this
 * hospital: the same person is registered as Maxamed, Mohamed, Mohammed,
 * Muhammad and Mahamed on five different days, and the medical history
 * fragments across five records.
 *
 * Somali orthography uses letters that English transliteration renders
 * inconsistently:
 *   x -> h   (Maxamed / Mahamed)
 *   c -> ''  (Cabdi / Abdi — the ayin is usually dropped in English spelling)
 *   dh -> d  (Faadumo / Fadumo)
 *   kh -> k, sh stays, doubled vowels collapse (Caasho / Asho)
 *
 * The folded key is stored in patients.name_normalized and indexed; it is a
 * SEARCH key only and is never displayed. The patient's name is always shown
 * exactly as the family gave it.
 */
final class NameNormalizer
{
    /** Ordered: multi-character rules must run before single-character ones. */
    private const RULES = [
        'dh' => 'd',
        'kh' => 'k',
        'gh' => 'g',
        'ph' => 'f',
        'x'  => 'h',
        'c'  => '',
        'q'  => 'k',
        'w'  => 'u',
        'y'  => 'i',
        'z'  => 's',
    ];

    public static function fold(?string ...$parts): string
    {
        $joined = trim(implode(' ', array_filter($parts)));
        $value  = mb_strtolower($joined, 'UTF-8');

        // Strip accents and anything that is not a letter or a space.
        $value = preg_replace('/[^\p{L}\s]+/u', ' ', $value) ?? '';

        foreach (self::RULES as $from => $to) {
            $value = str_replace($from, $to, $value);
        }

        // Collapse doubled letters: Caasho -> asho, Cabdullaahi -> abdulahi
        $value = preg_replace('/(.)\1+/u', '$1', $value) ?? '';

        return trim(preg_replace('/\s+/', ' ', $value) ?? '');
    }

    /** Secondary key for candidate ranking in duplicate detection. */
    public static function soundexKey(string ...$parts): string
    {
        $folded = self::fold(...$parts);

        return implode('', array_map(
            static fn (string $word): string => soundex($word),
            array_slice(explode(' ', $folded), 0, 3)
        ));
    }
}
