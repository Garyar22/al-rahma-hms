<?php

declare(strict_types=1);

namespace App\Support;

use App\Services\Shared\SettingsRepository;
use Illuminate\Support\Facades\Storage;

/**
 * Resolves which logo variant belongs on a given surface.
 *
 * Views ask for a CONTEXT, never for a filename. Without this, every Blade
 * template ends up choosing its own variant, and the day the hospital uploads
 * a new logo half the system updates and half does not.
 *
 * Contexts:
 *   screen   colour logo on a light background (login, letterhead, invoices)
 *   dark     white knock-out for the sidebar and dark headers
 *   mark     emblem only, for the collapsed sidebar and tight spaces
 *   print    colour logo; printed documents are always light
 *   receipt  1-bit silhouette sized for the configured receipt paper
 */
final class Branding
{
    public function __construct(private readonly SettingsRepository $settings) {}

    public function logo(string $context = 'screen'): ?string
    {
        $key = match ($context) {
            'dark'    => 'branding.logo_white_path',
            'mark'    => 'branding.mark_path',
            'receipt' => $this->settings->get('receipt.paper') === 'thermal58'
                            ? 'branding.receipt_logo_narrow_path'
                            : 'branding.receipt_logo_path',
            default   => 'branding.logo_path',
        };

        $path = (string) $this->settings->get($key, '');

        if ($path === '' || ! Storage::disk('public')->exists($path)) {
            // A missing logo must never break a receipt or a report: the caller
            // falls back to the hospital name in text.
            return null;
        }

        return Storage::disk('public')->url($path);
    }

    /**
     * Absolute filesystem path, required by dompdf: it cannot fetch a URL when
     * the server has no outbound internet, which is the normal state here.
     */
    public function logoPathForPdf(string $context = 'print'): ?string
    {
        $key = $context === 'receipt' ? 'branding.receipt_logo_path' : 'branding.logo_path';
        $path = (string) $this->settings->get($key, '');

        return $path !== '' && Storage::disk('public')->exists($path)
            ? Storage::disk('public')->path($path)
            : null;
    }

    public function hospitalName(): string
    {
        return (string) $this->settings->get('hospital.name', config('hospital.name'));
    }

    /** Single-line address for document headers. */
    public function addressLine(): string
    {
        return collect([
            $this->settings->get('hospital.address'),
            $this->settings->get('hospital.city'),
            $this->settings->get('hospital.country'),
        ])->filter()->implode(', ');
    }

    /** @return array<string,string> brand tokens, for inline styles in PDF output */
    public function colours(): array
    {
        return [
            'primary'        => (string) $this->settings->get('branding.color_primary', '#01AFEE'),
            'secondary'      => (string) $this->settings->get('branding.color_secondary', '#6DBC45'),
            'primary_text'   => (string) $this->settings->get('branding.color_primary_text', '#0B6E96'),
            'secondary_text' => (string) $this->settings->get('branding.color_secondary_text', '#3D7A24'),
            'ink'            => (string) $this->settings->get('branding.color_ink', '#10212B'),
        ];
    }
}
