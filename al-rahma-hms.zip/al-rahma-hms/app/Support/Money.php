<?php

declare(strict_types=1);

namespace App\Support;

use InvalidArgumentException;

/**
 * Money value object (Blueprint D5).
 *
 * Amounts are held as an integer number of minor units (cents) so that no
 * rounding error can accumulate. Every addition, discount and rounding rule in
 * the system goes through this class, which means "the invoice is off by one
 * cent" can only ever have one cause, in one file.
 *
 * Floats are never used for money anywhere in this codebase.
 */
final readonly class Money
{
    private function __construct(
        public int $minor,
        public string $currency,
    ) {}

    public static function fromMinor(int $minor, ?string $currency = null): self
    {
        return new self($minor, $currency ?? config('hospital.currency', 'USD'));
    }

    /** Builds from a decimal string such as "12.50" (the DB representation). */
    public static function fromDecimal(string|float|int $amount, ?string $currency = null): self
    {
        $normalised = number_format((float) $amount, 2, '.', '');

        return new self((int) str_replace('.', '', $normalised), $currency ?? config('hospital.currency', 'USD'));
    }

    public static function zero(?string $currency = null): self
    {
        return new self(0, $currency ?? config('hospital.currency', 'USD'));
    }

    public function plus(self $other): self
    {
        $this->assertSameCurrency($other);

        return new self($this->minor + $other->minor, $this->currency);
    }

    public function minus(self $other): self
    {
        $this->assertSameCurrency($other);

        return new self($this->minor - $other->minor, $this->currency);
    }

    public function multipliedBy(float $factor): self
    {
        return new self((int) round($this->minor * $factor), $this->currency);
    }

    /** Percentage discount, rounded half-up to the cent, once, here. */
    public function percentage(float $percent): self
    {
        return new self((int) round($this->minor * $percent / 100), $this->currency);
    }

    public function isNegative(): bool { return $this->minor < 0; }
    public function isZero(): bool     { return $this->minor === 0; }
    public function isPositive(): bool { return $this->minor > 0; }

    public function greaterThan(self $other): bool
    {
        $this->assertSameCurrency($other);

        return $this->minor > $other->minor;
    }

    /** The string form written to DECIMAL(12,2) columns. */
    public function toDecimal(): string
    {
        return number_format($this->minor / 100, 2, '.', '');
    }

    public function format(): string
    {
        return config('hospital.currency_symbol', '$').number_format($this->minor / 100, 2);
    }

    private function assertSameCurrency(self $other): void
    {
        if ($other->currency !== $this->currency) {
            throw new InvalidArgumentException(
                "Cannot combine {$this->currency} with {$other->currency}."
            );
        }
    }
}
