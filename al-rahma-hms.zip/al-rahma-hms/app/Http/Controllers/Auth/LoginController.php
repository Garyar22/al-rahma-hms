<?php

declare(strict_types=1);

namespace App\Http\Controllers\Auth;

use App\Enums\AuditAction;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\Shared\AuditLogger;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

/**
 * Sign in.
 *
 * Staff sign in with a USERNAME, not an email address: most hospital staff
 * here have no work email, and an email field on the login screen produces a
 * daily stream of failed logins.
 *
 * Failures are deliberately vague to the user ("those details do not match")
 * and precise in the audit log. Telling an attacker which half was wrong hands
 * them a list of valid usernames.
 */
class LoginController extends Controller
{
    public function __construct(private readonly AuditLogger $audit) {}

    public function show(): View
    {
        return view('auth.login');
    }

    public function store(Request $request): RedirectResponse
    {
        $credentials = $request->validate([
            'username' => ['required', 'string', 'max:40'],
            'password' => ['required', 'string'],
        ]);

        $throttleKey = mb_strtolower($credentials['username']).'|'.$request->ip();

        if (RateLimiter::tooManyAttempts($throttleKey, 10)) {
            throw ValidationException::withMessages([
                'username' => __('Too many attempts. Try again in :seconds seconds.', [
                    'seconds' => RateLimiter::availableIn($throttleKey),
                ]),
            ]);
        }

        $user = User::query()->where('username', mb_strtolower($credentials['username']))->first();

        if (! $user || ! Hash::check($credentials['password'], $user->password)) {
            RateLimiter::hit($throttleKey, 300);
            $user?->registerFailedLogin();

            $this->audit->log(AuditAction::LoginFailed, module: 'auth', context: [
                'username' => $credentials['username'],
                'reason'   => $user ? 'bad_password' : 'unknown_username',
            ]);

            throw ValidationException::withMessages([
                'username' => __('Those details do not match any account.'),
            ]);
        }

        if (! $user->canAuthenticate()) {
            $this->audit->log(AuditAction::LoginFailed, module: 'auth', subject: $user, context: [
                'reason' => $user->isLockedOut() ? 'locked' : 'inactive',
            ]);

            throw ValidationException::withMessages([
                'username' => $user->isLockedOut()
                    ? __('This account is locked. Ask an administrator to unlock it.')
                    : __('This account is no longer active.'),
            ]);
        }

        RateLimiter::clear($throttleKey);

        Auth::login($user, $request->boolean('remember'));
        $request->session()->regenerate();
        $request->session()->put('last_activity_at', time());

        $user->registerSuccessfulLogin((string) $request->ip());

        $this->audit->log(AuditAction::Login, module: 'auth', subject: $user);

        return redirect()->intended(route('dashboard'));
    }

    public function destroy(Request $request): RedirectResponse
    {
        $this->audit->log(AuditAction::Logout, module: 'auth', subject: $request->user());

        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
