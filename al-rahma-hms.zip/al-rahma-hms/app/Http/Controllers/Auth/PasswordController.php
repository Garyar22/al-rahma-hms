<?php

declare(strict_types=1);

namespace App\Http\Controllers\Auth;

use App\Enums\AuditAction;
use App\Http\Controllers\Controller;
use App\Services\Shared\AuditLogger;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;
use Illuminate\View\View;

/**
 * Changing your own password, including the forced change on first login.
 *
 * There is no self-service "forgot password" by email: most staff have no
 * email address, and an unattended reset link on a shared workstation is worse
 * than a short walk to the administrator, who issues a temporary password and
 * leaves an audit entry doing it.
 */
class PasswordController extends Controller
{
    public function __construct(private readonly AuditLogger $audit) {}

    public function edit(Request $request): View
    {
        return view('auth.change-password', [
            'forced' => (bool) $request->user()->must_change_password,
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        $user = $request->user();

        $validated = $request->validate([
            'current_password' => ['required', 'string'],
            'password'         => [
                'required', 'confirmed',
                Password::min((int) config('hospital.security.password_min_length', 12))
                    ->letters()->numbers()->uncompromised(),
            ],
        ], [
            'password.confirmed' => __('The two new passwords do not match.'),
        ]);

        if (! Hash::check($validated['current_password'], $user->password)) {
            return back()->withErrors(['current_password' => __('That is not your current password.')]);
        }

        if (Hash::check($validated['password'], $user->password)) {
            return back()->withErrors(['password' => __('Choose a password you have not used here before.')]);
        }

        $user->forceFill([
            'password'             => $validated['password'],
            'must_change_password' => false,
            'password_changed_at'  => now(),
        ])->save();

        $this->audit->log(AuditAction::PasswordChanged, module: 'auth', subject: $user, context: ['self_service' => true]);

        return redirect()->route('dashboard')->with('success', __('Your password has been changed.'));
    }
}
