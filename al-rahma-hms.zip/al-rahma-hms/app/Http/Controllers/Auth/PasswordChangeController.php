<?php

declare(strict_types=1);

namespace App\Http\Controllers\Auth;

use App\Enums\AuditAction;
use App\Http\Controllers\Controller;
use App\Services\Shared\AuditLogger;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rules\Password;
use Illuminate\View\View;

class PasswordChangeController extends Controller
{
    public function __construct(private readonly AuditLogger $audit) {}

    public function edit(): View
    {
        return view('auth.change-password');
    }

    public function update(Request $request): RedirectResponse
    {
        $minimum = (int) config('hospital.security.password_min_length', 12);

        $request->validate([
            'current_password' => ['required', 'current_password'],
            'password'         => ['required', 'confirmed', Password::min($minimum)->letters()->numbers()],
        ]);

        $request->user()->forceFill([
            'password'             => $request->get('password'),
            'must_change_password' => false,
            'password_changed_at'  => now(),
        ])->save();

        $this->audit->log(AuditAction::PasswordChanged, module: 'security', subject: $request->user());

        return redirect()->route('dashboard')->with('status', __('Your password has been changed.'));
    }
}
