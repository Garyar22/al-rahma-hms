<?php

declare(strict_types=1);

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Alert;
use App\Models\Department;
use App\Models\Patient;
use App\Models\Visit;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\View\View;

/**
 * Role-aware dashboard (FR-DSH-01): a user sees only what they can act on.
 *
 * All counts use the hospital-local business date, not the server's day
 * (Blueprint D9) — otherwise everything before 03:00 EAT is attributed to
 * yesterday.
 */
class DashboardController extends Controller
{
    public function index(Request $request): View
    {
        $today = Carbon::now(config('hospital.timezone'))->toDateString();
        $user  = $request->user();

        $metrics = [];

        if ($user->can('visits.visit.view')) {
            $metrics['visits_today'] = Visit::query()->where('business_date', $today)
                ->whereNot('status', 'cancelled')->count();

            $metrics['waiting'] = Visit::query()->where('business_date', $today)
                ->whereIn('status', ['registered', 'queued'])->count();
        }

        if ($user->can('patients.record.view')) {
            $metrics['patients_registered_today'] = Patient::query()->where('business_date', $today)->count();
            $metrics['patients_total'] = Patient::query()->where('status', 'active')->count();
        }

        return view('dashboard.index', [
            'metrics' => $metrics,
            'today'   => $today,
            'alerts'  => $user->can('reports.operational.view')
                ? Alert::query()->open()->latest()->limit(6)->get()
                : collect(),
            'sectors' => $user->can('org.sector.view')
                ? Department::query()->active()->count()
                : null,
        ]);
    }
}
