<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UserRequest;
use App\Models\Employee;
use App\Models\User;
use App\Services\Admin\UserService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Spatie\Permission\Models\Role;

/**
 * Administration > Users.
 *
 * One login per person. Temporary passwords are shown once, on screen, and are
 * never emailed or stored in readable form — which is also why this controller
 * flashes them rather than putting them in a redirect URL.
 */
class UserController extends Controller
{
    public function __construct(private readonly UserService $users)
    {
        $this->authorizeResource(User::class, 'user');
    }

    public function index(Request $request): View
    {
        $query = User::query()->with(['roles', 'employee'])->orderBy('name');

        if ($search = trim((string) $request->get('q'))) {
            $query->where(fn ($q) => $q
                ->where('name', 'like', "%{$search}%")
                ->orWhere('username', 'like', "%{$search}%"));
        }

        if ($role = $request->get('role')) {
            $query->whereHas('roles', fn ($q) => $q->where('name', $role));
        }

        if ($request->get('status') === 'inactive') {
            $query->where('is_active', false);
        } elseif ($request->get('status') !== 'all') {
            $query->where('is_active', true);
        }

        return view('admin.users.index', [
            'users'  => $query->paginate(25)->withQueryString(),
            'roles'  => Role::query()->orderBy('name')->get(),
            'search' => $search,
        ]);
    }

    public function create(): View
    {
        return view('admin.users.form', [
            'user'      => new User(['is_active' => true]),
            'roles'     => $this->assignableRoles(),
            'employees' => $this->linkableEmployees(),
        ]);
    }

    public function store(UserRequest $request): RedirectResponse
    {
        $result = $this->users->create($request->validated(), $request->string('role')->toString());

        return redirect()
            ->route('admin.users.index')
            ->with('success', __('Account created for :name.', ['name' => $result['user']->name]))
            ->with('temporary_password', [
                'username' => $result['user']->username,
                'password' => $result['temporary_password'],
            ]);
    }

    public function edit(User $user): View
    {
        return view('admin.users.form', [
            'user'      => $user,
            'roles'     => $this->assignableRoles(),
            'employees' => $this->linkableEmployees($user),
        ]);
    }

    public function update(UserRequest $request, User $user): RedirectResponse
    {
        $role = $request->user()->can('manageRoles', $user)
            ? $request->string('role')->toString()
            : null;

        $this->users->update($user, $request->validated(), $role);

        return redirect()
            ->route('admin.users.index')
            ->with('success', __('Changes to :name saved.', ['name' => $user->name]));
    }

    public function toggleActive(Request $request, User $user): RedirectResponse
    {
        $this->authorize('deactivate', $user);

        $this->users->setActive($user, ! $user->is_active, $request->string('reason')->toString() ?: null);

        return back()->with('success', $user->is_active
            ? __(':name can sign in again.', ['name' => $user->name])
            : __(':name can no longer sign in. Their past records stay attributed to them.', ['name' => $user->name]));
    }

    public function resetPassword(User $user): RedirectResponse
    {
        $this->authorize('resetPassword', $user);

        $temporary = $this->users->resetPassword($user);

        return back()
            ->with('success', __('Temporary password issued for :name.', ['name' => $user->name]))
            ->with('temporary_password', ['username' => $user->username, 'password' => $temporary]);
    }

    /** The owner role is granted at installation and never offered in a dropdown. */
    private function assignableRoles()
    {
        return Role::query()->where('name', '!=', 'system-owner')->orderBy('name')->get();
    }

    private function linkableEmployees(?User $user = null)
    {
        return Employee::query()
            ->where('employment_status', 'active')
            ->where(fn ($q) => $q->whereDoesntHave('user')->when($user?->employee_id, fn ($q, $id) => $q->orWhere('id', $id)))
            ->orderBy('first_name')
            ->get();
    }
}
