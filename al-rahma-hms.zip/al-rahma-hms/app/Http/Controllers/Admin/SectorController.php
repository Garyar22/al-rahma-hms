<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\SectorRequest;
use App\Models\Department;
use App\Models\Employee;
use App\Services\Organisation\SectorService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use RuntimeException;

/**
 * Administration > Sectors.
 *
 * The hospital builds its own structure here. Everything on this screen is the
 * administration's to change: add a sector, nest a department inside it, move
 * a unit, rename after a refurbishment, switch modules on, retire what closed.
 *
 * The controller stays thin: authorise, validate, call the service, redirect.
 * Every rule that must hold regardless of caller lives in SectorService.
 */
class SectorController extends Controller
{
    public function __construct(private readonly SectorService $sectors)
    {
        $this->authorizeResource(Department::class, 'sector');
    }

    public function index(Request $request): View
    {
        $tree = $this->sectors->tree();

        if ($search = trim((string) $request->get('q'))) {
            $matches = Department::query()
                ->where('name', 'like', "%{$search}%")
                ->orWhere('code', 'like', "%{$search}%")
                ->orderBy('name')
                ->get();

            return view('admin.sectors.index', [
                'tree'      => collect(),
                'matches'   => $matches,
                'search'    => $search,
                'moduleMap' => config('hospital.modules', []),
            ]);
        }

        return view('admin.sectors.index', [
            'tree'      => $tree,
            'matches'   => null,
            'search'    => '',
            'moduleMap' => config('hospital.modules', []),
        ]);
    }

    public function create(Request $request): View
    {
        return view('admin.sectors.form', [
            'sector'    => new Department([
                'kind'                 => 'department',
                'type'                 => 'clinical',
                'is_active'            => true,
                'accepts_appointments' => true,
                'accepts_walkins'      => true,
                'parent_id'            => $request->integer('parent') ?: null,
            ]),
            'parents'   => $this->parentOptions(),
            'employees' => $this->employeeOptions(),
            'moduleMap' => config('hospital.modules', []),
        ]);
    }

    public function store(SectorRequest $request): RedirectResponse
    {
        $sector = $this->sectors->create($request->validated());

        return redirect()
            ->route('admin.sectors.index')
            ->with('success', __(':name added to the hospital structure.', ['name' => $sector->name]));
    }

    public function show(Department $sector): View
    {
        $sector->load(['children', 'parent', 'head']);

        return view('admin.sectors.show', [
            'sector'    => $sector,
            'moduleMap' => config('hospital.modules', []),
            'usage'     => [
                __('Staff')           => $sector->employees()->count(),
                __('Wards')           => $sector->wards()->count(),
                __('Patient visits')  => $sector->visits()->count(),
                __('Services')        => $sector->services()->count(),
            ],
        ]);
    }

    public function edit(Department $sector): View
    {
        return view('admin.sectors.form', [
            'sector'    => $sector,
            'parents'   => $this->parentOptions($sector),
            'employees' => $this->employeeOptions(),
            'moduleMap' => config('hospital.modules', []),
        ]);
    }

    public function update(SectorRequest $request, Department $sector): RedirectResponse
    {
        try {
            $this->sectors->update($sector, $request->validated());
        } catch (RuntimeException $e) {
            return back()->withInput()->with('error', $e->getMessage());
        }

        return redirect()
            ->route('admin.sectors.show', $sector)
            ->with('success', __('Changes to :name saved.', ['name' => $sector->name]));
    }

    public function destroy(Department $sector): RedirectResponse
    {
        try {
            $name = $sector->name;
            $this->sectors->delete($sector);
        } catch (RuntimeException $e) {
            // The failure explains itself and offers the safe alternative,
            // rather than a bare "could not delete".
            return back()->with('error', __(':reason', ['reason' => $e->getMessage()]));
        }

        return redirect()
            ->route('admin.sectors.index')
            ->with('success', __(':name removed.', ['name' => $name]));
    }

    /** Deactivate rather than delete: keeps every past record readable. */
    public function deactivate(Request $request, Department $sector): RedirectResponse
    {
        $this->authorize('deactivate', $sector);

        $this->sectors->update($sector, ['is_active' => ! $sector->is_active]);

        return back()->with('success', $sector->is_active
            ? __(':name reopened.', ['name' => $sector->name])
            : __(':name closed. Its history stays intact and searchable.', ['name' => $sector->name]));
    }

    /** @return \Illuminate\Support\Collection<int,Department> */
    private function parentOptions(?Department $exclude = null)
    {
        return Department::query()
            ->with('parent')
            ->orderBy('display_order')->orderBy('name')
            ->get()
            ->reject(function (Department $candidate) use ($exclude): bool {
                if (! $exclude) {
                    return false;
                }

                // A node may not be moved inside itself or its own descendants.
                $node  = $candidate;
                $guard = 0;

                while ($node && $guard++ < 20) {
                    if ($node->id === $exclude->id) {
                        return true;
                    }
                    $node = $node->parent;
                }

                return false;
            })
            ->values();
    }

    private function employeeOptions()
    {
        return Employee::query()
            ->where('employment_status', 'active')
            ->orderBy('first_name')
            ->get(['id', 'first_name', 'middle_name', 'last_name', 'job_title']);
    }
}
