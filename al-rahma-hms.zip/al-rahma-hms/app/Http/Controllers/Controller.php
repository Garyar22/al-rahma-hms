<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;

/**
 * Laravel 11+ ships a bare base controller. Authorisation is pulled in here
 * deliberately: every controller in this system authorises, and a controller
 * that forgets is the defect this prevents.
 */
abstract class Controller
{
    use AuthorizesRequests, ValidatesRequests;
}
