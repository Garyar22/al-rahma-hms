<?php

declare(strict_types=1);

namespace App\Http\Requests\Admin;

use App\Enums\DepartmentKind;
use App\Models\Department;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * One request class for create and update: the rules are identical apart from
 * the uniqueness ignore, and two near-identical classes drift apart.
 */
class SectorRequest extends FormRequest
{
    public function authorize(): bool
    {
        $sector = $this->route('sector');

        return $sector instanceof Department
            ? $this->user()->can('update', $sector)
            : $this->user()->can('create', Department::class);
    }

    public function rules(): array
    {
        $sector = $this->route('sector');
        $id     = $sector instanceof Department ? $sector->id : null;

        return [
            'name' => ['required', 'string', 'max:120'],
            'code' => [
                'nullable', 'string', 'max:30', 'regex:/^[A-Za-z0-9\-]+$/',
                Rule::unique('departments', 'code')->ignore($id)->withoutTrashed(),
            ],
            'parent_id'            => ['nullable', 'integer', Rule::exists('departments', 'id')],
            'kind'                 => ['required', Rule::enum(DepartmentKind::class)],
            'type'                 => ['required', Rule::in(['clinical', 'support', 'administrative'])],
            'modules'              => ['array'],
            'modules.*'            => [Rule::in(array_keys(config('hospital.modules', [])))],
            'description'          => ['nullable', 'string', 'max:500'],
            'location_note'        => ['nullable', 'string', 'max:120'],
            'phone_extension'      => ['nullable', 'string', 'max:20'],
            'head_employee_id'     => ['nullable', 'integer', Rule::exists('employees', 'id')],
            'accepts_appointments' => ['boolean'],
            'accepts_walkins'      => ['boolean'],
            'is_active'            => ['boolean'],
            'display_order'        => ['nullable', 'integer', 'min:0', 'max:9999'],
        ];
    }

    protected function prepareForValidation(): void
    {
        $this->merge([
            'accepts_appointments' => $this->boolean('accepts_appointments'),
            'accepts_walkins'      => $this->boolean('accepts_walkins'),
            'is_active'            => $this->boolean('is_active'),
            'parent_id'            => $this->input('parent_id') ?: null,
            'head_employee_id'     => $this->input('head_employee_id') ?: null,
        ]);
    }

    public function messages(): array
    {
        return [
            'code.regex'  => __('A code can contain letters, numbers and hyphens only.'),
            'code.unique' => __('Another sector already uses that code.'),
        ];
    }

    public function attributes(): array
    {
        return [
            'parent_id'        => __('parent sector'),
            'head_employee_id' => __('head of sector'),
        ];
    }
}
