<?php

declare(strict_types=1);

namespace App\Http\Requests\Admin;

use App\Models\User;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Spatie\Permission\Models\Role;

class UserRequest extends FormRequest
{
    public function authorize(): bool
    {
        $user = $this->route('user');

        return $user instanceof User
            ? $this->user()->can('update', $user)
            : $this->user()->can('create', User::class);
    }

    public function rules(): array
    {
        $target = $this->route('user');
        $id     = $target instanceof User ? $target->id : null;

        return [
            'name'     => ['required', 'string', 'max:120'],
            'username' => [
                'required', 'string', 'min:3', 'max:40', 'regex:/^[a-zA-Z0-9._-]+$/',
                Rule::unique('users', 'username')->ignore($id)->withoutTrashed(),
            ],
            'email'       => ['nullable', 'email', 'max:160'],
            'employee_id' => ['nullable', 'integer', Rule::exists('employees', 'id')],
            'role'        => [
                'required', 'string',
                // The owner role is never assignable through the UI: it belongs
                // to the installed account and is granted by the seeder only.
                Rule::in(Role::query()->where('name', '!=', 'system-owner')->pluck('name')->all()),
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'username.regex' => __('A username can contain letters, numbers, dots, dashes and underscores only.'),
            'role.in'        => __('Choose a role from the list.'),
        ];
    }
}
