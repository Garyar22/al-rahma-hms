<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Enums\AuditAction;
use App\Services\Shared\AuditLogger;
use App\Services\Shared\SettingsRepository;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

/**
 * Logs out an idle session (Blueprint §6.4).
 *
 * Clinical workstations are shared and rarely locked. A consultation screen
 * left open at a nurses' station is an open medical record for anyone walking
 * past, so the timeout is short by default and configurable by the hospital.
 */
class EnforceIdleTimeout
{
    public function __construct(
        private readonly SettingsRepository $settings,
        private readonly AuditLogger $audit,
    ) {}

    public function handle(Request $request, Closure $next): Response
    {
        if (! Auth::check()) {
            return $next($request);
        }

        $limit    = (int) $this->settings->get('security.session_timeout_minutes', 30);
        $lastSeen = $request->session()->get('last_activity_at');

        if ($limit > 0 && $lastSeen && (time() - (int) $lastSeen) > $limit * 60) {
            $this->audit->log(AuditAction::Logout, module: 'auth', context: ['reason' => 'idle_timeout']);

            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return redirect()->route('login')->with('status', __('You were signed out after a period of inactivity.'));
        }

        $request->session()->put('last_activity_at', time());

        return $next($request);
    }
}
