<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Config;
use Symfony\Component\HttpFoundation\Response;

/**
 * Applies the hospital's timezone and interface language to every request.
 *
 * Timestamps are stored in UTC (Blueprint D9); this sets only how they are
 * DISPLAYED. Language is read from the user's preference so Somali and Arabic
 * can be switched on later with no code change (NFR-10).
 */
class SetHospitalContext
{
    public function handle(Request $request, Closure $next): Response
    {
        Config::set('app.display_timezone', config('hospital.timezone'));

        $locale = $request->user()?->locale ?? config('app.locale');
        App::setLocale($locale);

        return $next($request);
    }
}
