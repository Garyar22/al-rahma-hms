<?php

declare(strict_types=1);

namespace App\Enums;

enum LabItemStatus: string
{
    case Requested       = 'requested';
    case SampleCollected = 'sample_collected';
    case Processing      = 'processing';
    case Completed       = 'completed';
    case Verified        = 'verified';
    case Cancelled       = 'cancelled';
    case SampleRejected  = 'sample_rejected';

    public function canTransitionTo(self $next): bool
    {
        return in_array($next, match ($this) {
            self::Requested       => [self::SampleCollected, self::Cancelled],
            self::SampleCollected => [self::Processing, self::SampleRejected, self::Cancelled],
            self::SampleRejected  => [self::SampleCollected, self::Cancelled],
            self::Processing      => [self::Completed, self::SampleRejected],
            self::Completed       => [self::Verified],
            // Verified is terminal: a change becomes an AMENDED result that
            // supersedes this one, never an edit (FR-LAB-09).
            self::Verified, self::Cancelled => [],
        }, true);
    }

    /** Only verified results count as completed in reports (metric dictionary). */
    public function countsAsCompleted(): bool
    {
        return $this === self::Verified;
    }
}
