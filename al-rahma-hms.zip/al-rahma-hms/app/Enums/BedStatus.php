<?php

declare(strict_types=1);

namespace App\Enums;

enum BedStatus: string
{
    case Available   = 'available';
    case Occupied    = 'occupied';
    case Reserved    = 'reserved';
    case Cleaning    = 'cleaning';
    case Maintenance = 'maintenance';

    public function isAssignable(): bool
    {
        return in_array($this, [self::Available, self::Reserved], true);
    }
}
