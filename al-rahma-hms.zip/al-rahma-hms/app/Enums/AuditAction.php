<?php

declare(strict_types=1);

namespace App\Enums;

/** Named audit actions (FR-SEC-04). Using an enum rather than loose strings
 |  means a typo cannot silently create an un-reportable audit category. */
enum AuditAction: string
{
    case Login             = 'auth.login';
    case LoginFailed       = 'auth.login_failed';
    case Logout            = 'auth.logout';
    case PasswordChanged   = 'auth.password_changed';
    case Created           = 'record.created';
    case Updated           = 'record.updated';
    case Deleted           = 'record.deleted';
    case Restored          = 'record.restored';
    case PaymentRecorded   = 'payment.recorded';
    case PaymentReversed   = 'payment.reversed';
    case ReceiptReprinted  = 'payment.receipt_reprinted';
    case DiscountApproved  = 'billing.discount_approved';
    case InvoiceCancelled  = 'billing.invoice_cancelled';
    case Dispensed         = 'pharmacy.dispensed';
    case StockAdjusted     = 'inventory.stock_adjusted';
    case ResultVerified    = 'laboratory.result_verified';
    case ResultAmended     = 'laboratory.result_amended';
    case PatientMerged     = 'patients.merged';
    case BreakGlass        = 'security.break_glass';
    case PermissionChanged = 'security.permission_changed';
    case SettingChanged    = 'settings.changed';
    case SectorChanged     = 'settings.sector_changed';
    case ReportGenerated   = 'reports.generated';
    case ReportExported    = 'reports.exported';
}
