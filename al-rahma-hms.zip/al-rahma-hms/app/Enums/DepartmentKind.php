<?php

declare(strict_types=1);

namespace App\Enums;

/** The level of an organisational node. The tree itself is unconstrained:
 |  administration may nest as deeply as the hospital actually works. */
enum DepartmentKind: string
{
    case Sector     = 'sector';
    case Department = 'department';
    case Unit       = 'unit';

    public function label(): string
    {
        return match ($this) {
            self::Sector     => __('Sector'),
            self::Department => __('Department'),
            self::Unit       => __('Unit'),
        };
    }
}
