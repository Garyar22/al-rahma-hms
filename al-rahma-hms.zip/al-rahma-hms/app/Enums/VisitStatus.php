<?php

declare(strict_types=1);

namespace App\Enums;

enum VisitStatus: string
{
    case Registered     = 'registered';
    case Queued         = 'queued';
    case Called         = 'called';
    case InConsultation = 'in_consultation';
    case OrdersPending  = 'orders_pending';
    case Completed      = 'completed';
    case Cancelled      = 'cancelled';
    case Lwbs           = 'lwbs'; // left without being seen

    /** Allowed transitions. Defined ONCE, here — never duplicated in controllers. */
    public function canTransitionTo(self $next): bool
    {
        return in_array($next, match ($this) {
            self::Registered     => [self::Queued, self::Cancelled, self::Lwbs],
            self::Queued         => [self::Called, self::Cancelled, self::Lwbs],
            self::Called         => [self::InConsultation, self::Queued, self::Lwbs],
            self::InConsultation => [self::OrdersPending, self::Completed],
            self::OrdersPending  => [self::Completed],
            self::Completed, self::Cancelled, self::Lwbs => [],
        }, true);
    }

    public function isOpen(): bool
    {
        return ! in_array($this, [self::Completed, self::Cancelled, self::Lwbs], true);
    }

    public function label(): string
    {
        return match ($this) {
            self::Registered     => __('Registered'),
            self::Queued         => __('Waiting'),
            self::Called         => __('Called'),
            self::InConsultation => __('In consultation'),
            self::OrdersPending  => __('Orders pending'),
            self::Completed      => __('Completed'),
            self::Cancelled      => __('Cancelled'),
            self::Lwbs           => __('Left without being seen'),
        };
    }
}
