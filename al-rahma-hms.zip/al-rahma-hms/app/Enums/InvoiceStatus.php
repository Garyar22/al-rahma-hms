<?php

declare(strict_types=1);

namespace App\Enums;

enum InvoiceStatus: string
{
    case Draft         = 'draft';
    case Issued        = 'issued';
    case PartiallyPaid = 'partially_paid';
    case Paid          = 'paid';
    case Cancelled     = 'cancelled';
    case WrittenOff    = 'written_off';

    public function canTransitionTo(self $next): bool
    {
        return in_array($next, match ($this) {
            self::Draft         => [self::Issued, self::Cancelled],
            self::Issued        => [self::PartiallyPaid, self::Paid, self::Cancelled, self::WrittenOff],
            self::PartiallyPaid => [self::Paid, self::WrittenOff],
            // Paid invoices are NEVER reopened: corrections go through payment
            // reversal, which leaves both records intact (§49.6).
            self::Paid, self::Cancelled, self::WrittenOff => [],
        }, true);
    }

    public function countsAsBilled(): bool
    {
        return ! in_array($this, [self::Draft, self::Cancelled], true);
    }
}
