<?php

declare(strict_types=1);

namespace App\Enums;

enum StockMovementType: string
{
    case Receipt         = 'receipt';
    case Issue           = 'issue';
    case TransferIn      = 'transfer_in';
    case TransferOut     = 'transfer_out';
    case Dispense        = 'dispense';
    case ReturnStock     = 'return';
    case Adjustment      = 'adjustment';
    case DisposalExpired = 'disposal_expired';
    case DisposalDamaged = 'disposal_damaged';
    case CountCorrection = 'count_correction';

    /** Movements that must reduce stock. Used to validate the sign. */
    public function isOutward(): bool
    {
        return in_array($this, [
            self::Issue, self::TransferOut, self::Dispense,
            self::DisposalExpired, self::DisposalDamaged,
        ], true);
    }

    public function requiresReason(): bool
    {
        return in_array($this, [
            self::Adjustment, self::CountCorrection,
            self::DisposalExpired, self::DisposalDamaged,
        ], true);
    }
}
