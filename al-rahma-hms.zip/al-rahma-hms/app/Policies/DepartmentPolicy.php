<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\Department;
use App\Models\User;

/**
 * Who may reshape the hospital's own structure.
 *
 * The permission grants the CAPABILITY; this policy decides whether it applies
 * to THIS node. The distinction matters for system sectors: an administrator
 * holds org.sector.delete, but the four nodes the software depends on still
 * refuse deletion, because a tidy-up on a quiet afternoon must not break
 * patient registration on Monday morning.
 */
class DepartmentPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can('org.sector.view');
    }

    public function view(User $user, Department $department): bool
    {
        return $user->can('org.sector.view');
    }

    public function create(User $user): bool
    {
        return $user->can('org.sector.create');
    }

    public function update(User $user, Department $department): bool
    {
        return $user->can('org.sector.edit');
    }

    /**
     * Deletion is permission AND state. Department::deletionCheck() owns the
     * state half so the same rule is enforced whether the request arrives from
     * the UI, a console command or a future API.
     */
    public function delete(User $user, Department $department): bool
    {
        return $user->can('org.sector.delete') && $department->deletionCheck()['allowed'];
    }

    /** Deactivating is the safe alternative to deleting and needs only edit rights. */
    public function deactivate(User $user, Department $department): bool
    {
        return $user->can('org.sector.edit') && ! $department->is_system;
    }

    public function restore(User $user, Department $department): bool
    {
        return $user->can('org.sector.delete');
    }
}
