<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\User;

/**
 * Account management rules.
 *
 * Three protections exist here that a plain permission check cannot express,
 * and each one exists because of a way hospitals actually lose access:
 *
 *  1. The protected System Owner account cannot be deleted, deactivated or
 *     stripped of its role by anyone — including itself. A hospital that
 *     deletes its own owner account has no route back in without a developer.
 *  2. Nobody can deactivate or delete their own account, which is the common
 *     accidental version of the same mistake.
 *  3. Only a System Owner may edit another System Owner, so an administrator
 *     cannot quietly take over the proprietor's account.
 */
class UserPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can('users.account.view');
    }

    public function view(User $user, User $target): bool
    {
        return $user->can('users.account.view') || $user->is($target);
    }

    public function create(User $user): bool
    {
        return $user->can('users.account.manage');
    }

    public function update(User $user, User $target): bool
    {
        if (! $user->can('users.account.manage')) {
            return false;
        }

        // Only an owner may edit an owner.
        return ! $target->isSystemOwner() || $user->isSystemOwner();
    }

    public function manageRoles(User $user, User $target): bool
    {
        if (! $user->can('users.role.manage')) {
            return false;
        }

        if ($target->is_protected) {
            return false; // the owner's role is fixed
        }

        return ! $target->isSystemOwner() || $user->isSystemOwner();
    }

    public function deactivate(User $user, User $target): bool
    {
        return $user->can('users.account.manage')
            && ! $target->is_protected
            && ! $user->is($target);
    }

    public function delete(User $user, User $target): bool
    {
        return $user->can('users.account.manage')
            && ! $target->is_protected
            && ! $user->is($target);
    }

    public function resetPassword(User $user, User $target): bool
    {
        return $user->can('users.account.manage')
            && (! $target->isSystemOwner() || $user->isSystemOwner());
    }
}
