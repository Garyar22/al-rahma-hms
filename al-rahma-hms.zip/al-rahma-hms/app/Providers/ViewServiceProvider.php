<?php

declare(strict_types=1);

namespace App\Providers;

use App\Support\Branding;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

/**
 * Every layout needs the hospital's identity, so it is shared once rather than
 * passed from forty controllers. This is also what keeps Rule 11 true in the
 * view layer: no Blade file ever writes "Al Rahma Hospital" as a literal.
 */
class ViewServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        View::composer(['layouts.app', 'layouts.guest'], function ($view): void {
            $view->with('branding', app(Branding::class));
        });
    }
}
