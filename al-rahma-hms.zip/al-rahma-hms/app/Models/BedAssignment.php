<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** active_flag carries the one-occupant-per-bed guarantee. It is 1 while the
 |  bed is occupied and NULL after release; the unique indexes do the rest. */
class BedAssignment extends Model
{
    protected $fillable = [
        'admission_id', 'bed_id', 'assigned_at', 'released_at',
        'active_flag', 'assigned_by', 'release_reason',
    ];

    protected function casts(): array
    {
        return ['assigned_at' => 'datetime', 'released_at' => 'datetime'];
    }

    public function admission(): BelongsTo { return $this->belongsTo(Admission::class); }
    public function bed(): BelongsTo       { return $this->belongsTo(Bed::class); }

    public function release(string $reason = 'discharge'): void
    {
        $this->forceFill([
            'released_at'    => now(),
            'active_flag'    => null,
            'release_reason' => $reason,
        ])->save();
    }
}
