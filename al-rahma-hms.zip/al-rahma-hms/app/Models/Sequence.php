<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Sequence extends Model
{
    use HasFactory;

    protected $fillable = ['key', 'prefix', 'next_number', 'padding', 'reset_period', 'current_period'];

    protected function casts(): array
    {
        return [];
    }

    // Allocation is handled exclusively by App\Services\Shared\NumberGenerator.
}
