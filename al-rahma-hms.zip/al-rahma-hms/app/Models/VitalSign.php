<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use RuntimeException;

/**
 * Vital signs are written once and never changed (FR-VIT-03, §49.1).
 *
 * A correction is a NEW row pointing at the one it replaces, so the original
 * reading and the correction both remain visible with their timestamps. The
 * model refuses updates and deletes outright rather than trusting every
 * future controller to remember.
 */
class VitalSign extends Model
{
    use HasFactory;

    public const UPDATED_AT = null;

    protected $fillable = [
        'patient_id', 'visit_id', 'admission_id', 'temperature_c', 'systolic',
        'diastolic', 'pulse', 'respiratory_rate', 'spo2', 'weight_kg',
        'height_cm', 'bmi', 'pain_score', 'notes', 'recorded_by',
        'recorded_at', 'is_correction_of_id',
    ];

    protected function casts(): array
    {
        return [
            'recorded_at'   => 'datetime',
            'temperature_c' => 'decimal:1',
            'weight_kg'     => 'decimal:2',
            'height_cm'     => 'decimal:1',
            'bmi'           => 'decimal:2',
        ];
    }

    protected static function booted(): void
    {
        static::saving(function (self $vitals): void {
            if ($vitals->weight_kg && $vitals->height_cm) {
                $metres      = (float) $vitals->height_cm / 100;
                $vitals->bmi = round((float) $vitals->weight_kg / ($metres ** 2), 2);
            }
        });

        static::updating(fn () => throw new RuntimeException(
            'Vital signs cannot be edited. Record a correcting observation instead.'
        ));

        static::deleting(fn () => throw new RuntimeException('Vital signs cannot be deleted.'));
    }

    public function patient(): BelongsTo    { return $this->belongsTo(Patient::class); }
    public function visit(): BelongsTo      { return $this->belongsTo(Visit::class); }
    public function admission(): BelongsTo  { return $this->belongsTo(Admission::class); }
    public function recordedBy(): BelongsTo { return $this->belongsTo(User::class, 'recorded_by'); }
    public function corrects(): BelongsTo   { return $this->belongsTo(self::class, 'is_correction_of_id'); }

    public function bloodPressure(): ?string
    {
        return $this->systolic && $this->diastolic ? "{$this->systolic}/{$this->diastolic}" : null;
    }
}
