<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class LeaveRequest extends Model
{
    use HasFactory;

    protected $fillable = ['employee_id', 'type', 'start_date', 'end_date', 'reason', 'status', 'approved_by', 'decided_at', 'decision_notes'];

    protected function casts(): array
    {
        return ['start_date' => 'date', 'end_date' => 'date', 'decided_at' => 'datetime'];
    }

    public function employee(): BelongsTo { return $this->belongsTo(Employee::class); }
    public function approver(): BelongsTo   { return $this->belongsTo(User::class, "approved_by"); }
}
