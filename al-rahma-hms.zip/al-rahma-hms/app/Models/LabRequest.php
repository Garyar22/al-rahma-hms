<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class LabRequest extends Model
{
    use HasFactory;

    protected $fillable = ['request_number', 'visit_id', 'patient_id', 'requested_by', 'priority', 'clinical_notes', 'status', 'requested_at'];

    protected function casts(): array
    {
        return ['requested_at' => 'datetime'];
    }

    public function visit(): BelongsTo   { return $this->belongsTo(Visit::class); }
    public function patient(): BelongsTo { return $this->belongsTo(Patient::class); }
    public function doctor(): BelongsTo  { return $this->belongsTo(Doctor::class, "requested_by"); }
    public function items(): HasMany     { return $this->hasMany(LabRequestItem::class); }
    public function samples(): HasMany   { return $this->hasMany(LabSample::class); }
}
