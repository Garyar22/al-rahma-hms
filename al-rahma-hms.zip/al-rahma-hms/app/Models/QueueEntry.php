<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class QueueEntry extends Model
{
    use HasFactory;

    protected $fillable = ['visit_id', 'department_id', 'queue_date', 'queue_number', 'priority', 'status', 'called_at', 'called_by', 'served_at'];

    protected function casts(): array
    {
        return ['queue_date' => 'date', 'called_at' => 'datetime', 'served_at' => 'datetime'];
    }

    public function visit(): BelongsTo      { return $this->belongsTo(Visit::class); }
    public function department(): BelongsTo { return $this->belongsTo(Department::class); }

    public function waitingMinutes(): int
    {
        return (int) $this->created_at->diffInMinutes($this->called_at ?? now());
    }
}
