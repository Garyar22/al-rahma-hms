<?php

declare(strict_types=1);

namespace App\Models;

use App\Enums\DepartmentKind;
use App\Models\Concerns\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * A SECTOR, DEPARTMENT or UNIT — the hospital's own structure, built and
 * rebuilt entirely by the administration without a developer.
 *
 * The tree is unlimited in depth: "Clinical Services > Outpatient >
 * Paediatrics" is three rows created through the UI. `modules` chooses which
 * parts of the system that branch uses, from config('hospital.modules'), so
 * switching Maternity or Radiology on is a checkbox rather than a migration.
 *
 * is_system protects the few nodes the software itself depends on. They stay
 * fully renameable and reconfigurable — only deletion is refused, so a
 * well-meant tidy-up cannot break patient registration on a Monday morning.
 */
class Department extends Model
{
    use Auditable, HasFactory, SoftDeletes;

    protected string $auditModule = 'organisation';

    protected $fillable = [
        'code', 'name', 'parent_id', 'kind', 'type', 'modules', 'description',
        'location_note', 'phone_extension', 'head_employee_id',
        'accepts_appointments', 'accepts_walkins', 'is_active', 'display_order',
    ];

    protected function casts(): array
    {
        return [
            'kind'                 => DepartmentKind::class,
            'modules'              => 'array',
            'accepts_appointments' => 'boolean',
            'accepts_walkins'      => 'boolean',
            'is_system'            => 'boolean',
            'is_active'            => 'boolean',
        ];
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id')->orderBy('display_order')->orderBy('name');
    }

    public function head(): BelongsTo
    {
        return $this->belongsTo(Employee::class, 'head_employee_id');
    }

    public function employees(): HasMany
    {
        return $this->hasMany(Employee::class);
    }

    public function wards(): HasMany
    {
        return $this->hasMany(Ward::class);
    }

    public function visits(): HasMany
    {
        return $this->hasMany(Visit::class);
    }

    public function services(): HasMany
    {
        return $this->hasMany(Service::class);
    }

    public function hasModule(string $module): bool
    {
        return in_array($module, $this->modules ?? [], true);
    }

    /** Full path for display: "Clinical Services › Outpatient › Paediatrics". */
    public function pathLabel(): string
    {
        $names  = [$this->name];
        $node   = $this;
        $guard  = 0;

        while ($node->parent && $guard++ < 10) {
            $node = $node->parent;
            array_unshift($names, $node->name);
        }

        return implode(' › ', $names);
    }

    /**
     * Whether this node may be deleted. Deletion is refused when it is a
     * system node or when real records point at it — history must never be
     * orphaned, so the UI offers "deactivate" instead.
     *
     * @return array{allowed:bool, reason:?string}
     */
    public function deletionCheck(): array
    {
        if ($this->is_system) {
            return ['allowed' => false, 'reason' => __('This is a core sector required by the system. You can rename or deactivate it, but not delete it.')];
        }

        if ($this->children()->exists()) {
            return ['allowed' => false, 'reason' => __('Move or delete the sectors inside it first.')];
        }

        foreach ([
            'visits'    => __('patient visits'),
            'employees' => __('staff records'),
            'wards'     => __('wards'),
            'services'  => __('billable services'),
        ] as $relation => $label) {
            if ($this->{$relation}()->exists()) {
                return ['allowed' => false, 'reason' => __('It is used by existing :thing. Deactivate it instead so the history stays intact.', ['thing' => $label])];
            }
        }

        return ['allowed' => true, 'reason' => null];
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeRoots($query)
    {
        return $query->whereNull('parent_id');
    }
}
