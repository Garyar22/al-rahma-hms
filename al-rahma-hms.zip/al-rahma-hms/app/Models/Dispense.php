<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Dispense extends Model
{
    use HasFactory;

    protected $fillable = ['prescription_id', 'patient_id', 'location_id', 'invoice_id', 'dispensed_by', 'dispensed_at', 'status', 'reversal_of_id', 'reason'];

    protected function casts(): array
    {
        return ['dispensed_at' => 'datetime'];
    }

    public function prescription(): BelongsTo { return $this->belongsTo(Prescription::class); }
    public function patient(): BelongsTo      { return $this->belongsTo(Patient::class); }
    public function items(): HasMany          { return $this->hasMany(DispenseItem::class); }
    public function dispensedBy(): BelongsTo  { return $this->belongsTo(User::class, "dispensed_by"); }
}
