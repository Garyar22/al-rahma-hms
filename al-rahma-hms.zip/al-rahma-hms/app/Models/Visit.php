<?php

declare(strict_types=1);

namespace App\Models;

use App\Enums\VisitStatus;
use App\Exceptions\InvalidStateTransitionException;
use App\Models\Concerns\Auditable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Visit extends Model
{
    use Auditable, HasFactory;

    protected string $auditModule = 'visits';

    protected $fillable = [
        'visit_number', 'patient_id', 'type', 'department_id', 'doctor_id',
        'appointment_id', 'parent_visit_id', 'status', 'chief_complaint_short',
        'arrived_at', 'started_at', 'completed_at', 'created_by', 'closed_by',
        'cancellation_reason',
    ];

    protected function casts(): array
    {
        return [
            'status'        => VisitStatus::class,
            'arrived_at'    => 'datetime',
            'started_at'    => 'datetime',
            'completed_at'  => 'datetime',
            'business_date' => 'date',
        ];
    }

    public function patient(): BelongsTo      { return $this->belongsTo(Patient::class); }
    public function department(): BelongsTo   { return $this->belongsTo(Department::class); }
    public function doctor(): BelongsTo       { return $this->belongsTo(Doctor::class); }
    public function appointment(): BelongsTo  { return $this->belongsTo(Appointment::class); }
    public function queueEntry(): HasOne      { return $this->hasOne(QueueEntry::class); }
    public function emergencyCase(): HasOne   { return $this->hasOne(EmergencyCase::class); }
    public function consultation(): HasOne    { return $this->hasOne(Consultation::class); }
    public function admission(): HasOne       { return $this->hasOne(Admission::class); }
    public function vitalSigns(): HasMany     { return $this->hasMany(VitalSign::class); }
    public function prescriptions(): HasMany  { return $this->hasMany(Prescription::class); }
    public function labRequests(): HasMany    { return $this->hasMany(LabRequest::class); }
    public function invoices(): HasMany       { return $this->hasMany(Invoice::class); }

    /** The one place a visit's status changes. Illegal moves throw rather
     |  than silently corrupting the day's figures. */
    public function transitionTo(VisitStatus $next): void
    {
        if (! $this->status->canTransitionTo($next)) {
            throw new InvalidStateTransitionException(
                "Cannot move visit {$this->visit_number} from {$this->status->value} to {$next->value}."
            );
        }

        $this->status = $next;

        if ($next === VisitStatus::InConsultation && ! $this->started_at) {
            $this->started_at = now();
        }

        if (in_array($next, [VisitStatus::Completed, VisitStatus::Cancelled, VisitStatus::Lwbs], true)) {
            $this->completed_at = now();
        }

        $this->save();
    }

    public function scopeOpen(Builder $query): Builder
    {
        return $query->whereNotIn('status', ['completed', 'cancelled', 'lwbs']);
    }

    public function scopeOnBusinessDate(Builder $query, string $date): Builder
    {
        return $query->where('business_date', $date);
    }
}
