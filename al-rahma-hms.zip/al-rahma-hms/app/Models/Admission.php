<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Admission extends Model
{
    use Auditable, HasFactory;

    protected string $auditModule = 'inpatient';
    protected array $auditExcluded = ['discharge_summary', 'admission_reason'];

    protected $fillable = [
        'admission_number', 'patient_id', 'visit_id', 'attending_doctor_id',
        'ward_id', 'admitted_at', 'admission_reason', 'provisional_diagnosis',
        'status', 'discharged_at', 'discharge_type', 'discharge_summary',
        'discharged_by', 'last_bed_charge_date', 'created_by',
    ];

    protected function casts(): array
    {
        return [
            'admitted_at'          => 'datetime',
            'discharged_at'        => 'datetime',
            'last_bed_charge_date' => 'date',
        ];
    }

    public function patient(): BelongsTo  { return $this->belongsTo(Patient::class); }
    public function visit(): BelongsTo    { return $this->belongsTo(Visit::class); }
    public function doctor(): BelongsTo   { return $this->belongsTo(Doctor::class, 'attending_doctor_id'); }
    public function ward(): BelongsTo     { return $this->belongsTo(Ward::class); }
    public function bedAssignments(): HasMany { return $this->hasMany(BedAssignment::class)->orderByDesc('assigned_at'); }
    public function vitalSigns(): HasMany { return $this->hasMany(VitalSign::class); }
    public function medications(): HasMany { return $this->hasMany(MedicationAdministration::class); }

    public function currentAssignment(): HasOne
    {
        return $this->hasOne(BedAssignment::class)->whereNotNull('active_flag');
    }

    public function currentBed(): ?Bed
    {
        return $this->currentAssignment?->first()?->bed;
    }

    public function lengthOfStayDays(): int
    {
        $end = $this->discharged_at ?? now();

        return max(1, (int) $this->admitted_at->diffInDays($end));
    }

    public function scopeCurrent(Builder $q): Builder
    {
        return $q->where('status', 'admitted');
    }
}
