<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class MedicationAdministration extends Model
{
    use HasFactory;

    protected $fillable = ['admission_id', 'prescription_item_id', 'item_id', 'dose', 'route', 'scheduled_at', 'administered_at', 'status', 'administered_by', 'reason', 'notes'];

    protected function casts(): array
    {
        return ['scheduled_at' => 'datetime', 'administered_at' => 'datetime'];
    }

    public function admission(): BelongsTo { return $this->belongsTo(Admission::class); }
    public function item(): BelongsTo      { return $this->belongsTo(Item::class); }
}
