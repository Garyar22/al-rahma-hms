<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class LabTestParameter extends Model
{
    use HasFactory;

    protected $fillable = ['lab_test_id', 'name', 'unit', 'result_type', 'options', 'ref_low', 'ref_high', 'ref_text', 'critical_low', 'critical_high', 'sex_applicability', 'age_min_years', 'age_max_years', 'display_order'];

    protected function casts(): array
    {
        return ['options' => 'array', 'ref_low' => 'decimal:3', 'ref_high' => 'decimal:3', 'critical_low' => 'decimal:3', 'critical_high' => 'decimal:3'];
    }

    public function test(): BelongsTo { return $this->belongsTo(LabTest::class, "lab_test_id"); }

    public function rangeLabel(): string
    {
        if ($this->ref_text) { return $this->ref_text; }
        if ($this->ref_low !== null && $this->ref_high !== null) {
            return $this->ref_low . " - " . $this->ref_high . " " . ($this->unit ?? "");
        }
        return "";
    }

    /** Flags a value against the range that applies to THIS patient. */
    public function flagFor(float $value): string
    {
        if ($this->critical_low !== null && $value <= (float) $this->critical_low)  { return "critical_low"; }
        if ($this->critical_high !== null && $value >= (float) $this->critical_high) { return "critical_high"; }
        if ($this->ref_low !== null && $value < (float) $this->ref_low)   { return "low"; }
        if ($this->ref_high !== null && $value > (float) $this->ref_high) { return "high"; }
        return "normal";
    }
}
