<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Expense extends Model
{
    use HasFactory;

    protected $fillable = ['expense_number', 'category_id', 'amount', 'currency', 'payment_method_id', 'description', 'incurred_on', 'status', 'recorded_by', 'approved_by', 'attachment_id'];

    protected function casts(): array
    {
        return ['amount' => 'decimal:2', 'incurred_on' => 'date'];
    }

    public function category(): BelongsTo { return $this->belongsTo(ExpenseCategory::class, "category_id"); }
    public function method(): BelongsTo   { return $this->belongsTo(PaymentMethod::class, "payment_method_id"); }
}
