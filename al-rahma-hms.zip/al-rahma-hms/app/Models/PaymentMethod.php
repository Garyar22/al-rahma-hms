<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class PaymentMethod extends Model
{
    use HasFactory;

    protected $fillable = ['code', 'name', 'requires_reference', 'is_cash', 'is_active', 'display_order'];

    protected function casts(): array
    {
        return ['requires_reference' => 'boolean', 'is_cash' => 'boolean', 'is_active' => 'boolean'];
    }

    public function payments(): HasMany { return $this->hasMany(Payment::class); }
}
