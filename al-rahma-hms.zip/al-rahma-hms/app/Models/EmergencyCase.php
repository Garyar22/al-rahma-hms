<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class EmergencyCase extends Model
{
    use HasFactory;

    protected $fillable = ['visit_id', 'arrival_at', 'arrival_mode', 'triage_priority', 'triage_by', 'triage_at', 'presenting_complaint', 'disposition', 'disposition_at', 'disposition_by', 'referred_to', 'disposition_notes'];

    protected function casts(): array
    {
        return ['arrival_at' => 'datetime', 'triage_at' => 'datetime', 'disposition_at' => 'datetime'];
    }

    public function visit(): BelongsTo { return $this->belongsTo(Visit::class); }
}
