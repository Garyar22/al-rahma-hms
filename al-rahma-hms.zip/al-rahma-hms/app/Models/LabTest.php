<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class LabTest extends Model
{
    use Auditable, HasFactory, SoftDeletes;

    protected string $auditModule = 'laboratory';

    protected $fillable = [
        'code', 'name', 'category_id', 'service_id', 'sample_type', 'container',
        'turnaround_hours', 'price', 'has_parameters', 'preparation_notes', 'is_active',
    ];

    protected function casts(): array
    {
        return ['price' => 'decimal:2', 'has_parameters' => 'boolean', 'is_active' => 'boolean'];
    }

    public function category(): BelongsTo  { return $this->belongsTo(LabTestCategory::class, 'category_id'); }
    public function service(): BelongsTo   { return $this->belongsTo(Service::class); }
    public function parameters(): HasMany  { return $this->hasMany(LabTestParameter::class)->orderBy('display_order'); }

    /** Parameters narrowed to the ranges that apply to this patient's sex and
     |  age — a haemoglobin range that ignores both flags healthy women and
     |  children as abnormal every day. */
    public function parametersFor(Patient $patient)
    {
        $age = $patient->age();

        return $this->parameters->filter(function (LabTestParameter $p) use ($patient, $age): bool {
            if ($p->sex_applicability !== 'any' && $p->sex_applicability !== $patient->gender) {
                return false;
            }
            if ($age !== null && $p->age_min_years !== null && $age < $p->age_min_years) {
                return false;
            }
            if ($age !== null && $p->age_max_years !== null && $age > $p->age_max_years) {
                return false;
            }

            return true;
        })->values();
    }
}
