<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Carbon;
use Spatie\Permission\Traits\HasRoles;

/**
 * A system user.
 *
 * One login per person — shared accounts are forbidden, because the audit
 * trail is the hospital's main accountability control and a shared login
 * destroys it (Blueprint §3.1).
 *
 * is_protected marks the System Owner account: it cannot be deleted,
 * deactivated or stripped of its role through the UI, so the hospital can
 * never lock itself out of its own system.
 */
class User extends Authenticatable
{
    use Auditable, HasFactory, HasRoles, Notifiable, SoftDeletes;

    protected string $auditModule = 'users';

    protected $fillable = [
        'employee_id', 'name', 'username', 'email', 'password',
        'is_active', 'is_protected', 'must_change_password',
    ];

    protected $hidden = ['password', 'remember_token', 'two_factor_secret'];

    protected function casts(): array
    {
        return [
            'password'             => 'hashed',
            'email_verified_at'    => 'datetime',
            'is_active'            => 'boolean',
            'is_protected'         => 'boolean',
            'must_change_password' => 'boolean',
            'password_changed_at'  => 'datetime',
            'last_login_at'        => 'datetime',
            'locked_until'         => 'datetime',
        ];
    }

    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class);
    }

    public function isLockedOut(): bool
    {
        return $this->locked_until !== null && $this->locked_until->isFuture();
    }

    /** Blocks login for deactivated or locked accounts (FR-SEC-08/09). */
    public function canAuthenticate(): bool
    {
        return $this->is_active && ! $this->isLockedOut() && $this->deleted_at === null;
    }

    public function registerFailedLogin(): void
    {
        $max = (int) config('hospital.security.max_login_attempts', 5);

        $this->failed_login_count++;

        if ($this->failed_login_count >= $max) {
            $this->locked_until       = Carbon::now()->addMinutes((int) config('hospital.security.lockout_minutes', 15));
            $this->failed_login_count = 0;
        }

        $this->saveQuietly();
    }

    public function registerSuccessfulLogin(string $ip): void
    {
        $this->forceFill([
            'failed_login_count' => 0,
            'locked_until'       => null,
            'last_login_at'      => Carbon::now(),
            'last_login_ip'      => $ip,
        ])->saveQuietly();
    }

    public function isSystemOwner(): bool
    {
        return $this->hasRole('system-owner');
    }
}
