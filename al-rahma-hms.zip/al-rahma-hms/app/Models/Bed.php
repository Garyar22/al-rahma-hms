<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Bed extends Model
{
    use HasFactory;

    protected $fillable = ['ward_id', 'bed_number', 'status', 'notes'];

    protected function casts(): array
    {
        return ['status' => \App\Enums\BedStatus::class];
    }

    public function ward(): BelongsTo        { return $this->belongsTo(Ward::class); }
    public function assignments(): HasMany   { return $this->hasMany(BedAssignment::class); }

    public function currentAssignment(): HasOne
    {
        return $this->hasOne(BedAssignment::class)->whereNotNull("active_flag");
    }
}
