<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Prescription extends Model
{
    use HasFactory;

    protected $fillable = ['prescription_number', 'visit_id', 'patient_id', 'doctor_id', 'status', 'notes', 'cancelled_by', 'cancellation_reason'];

    protected function casts(): array
    {
        return ['status' => \App\Enums\PrescriptionStatus::class];
    }

    public function visit(): BelongsTo   { return $this->belongsTo(Visit::class); }
    public function patient(): BelongsTo { return $this->belongsTo(Patient::class); }
    public function doctor(): BelongsTo  { return $this->belongsTo(Doctor::class); }
    public function items(): HasMany     { return $this->hasMany(PrescriptionItem::class); }
    public function dispenses(): HasMany { return $this->hasMany(Dispense::class); }

    /** Derived from the items, never typed: a prescription is dispensed when
     |  every billable item is. */
    public function refreshStatus(): void
    {
        $items = $this->items()->where("status", "!=", "cancelled")->get();
        $done  = $items->where("status", "dispensed")->count();

        $this->status = match (true) {
            $items->isEmpty()      => \App\Enums\PrescriptionStatus::Cancelled,
            $done === $items->count() => \App\Enums\PrescriptionStatus::Dispensed,
            $done > 0              => \App\Enums\PrescriptionStatus::PartiallyDispensed,
            default                => \App\Enums\PrescriptionStatus::Pending,
        };

        $this->save();
    }
}
