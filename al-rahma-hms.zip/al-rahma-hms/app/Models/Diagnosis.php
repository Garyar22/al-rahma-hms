<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Diagnosis extends Model
{
    use HasFactory;

    protected $fillable = ['consultation_id', 'patient_id', 'type', 'code_system', 'code', 'description', 'notes', 'created_by'];

    protected function casts(): array
    {
        return [];
    }

    public function consultation(): BelongsTo { return $this->belongsTo(Consultation::class); }
    public function patient(): BelongsTo      { return $this->belongsTo(Patient::class); }
}
