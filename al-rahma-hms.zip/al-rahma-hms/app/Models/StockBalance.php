<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Cached quantity per batch per location.
 *
 * WRITTEN ONLY BY App\Services\Shared\StockLedger. A feature test asserts that
 * no other class in app/ touches this model, because the moment a controller
 * "just updates the quantity", the ledger and the balance diverge and nobody
 * can say which is right.
 */
class StockBalance extends Model
{
    public $timestamps = false;

    protected $fillable = ['item_id', 'batch_id', 'location_id', 'quantity', 'updated_at'];

    protected function casts(): array
    {
        return ['quantity' => 'decimal:2', 'updated_at' => 'datetime'];
    }

    public function item(): BelongsTo     { return $this->belongsTo(Item::class); }
    public function batch(): BelongsTo    { return $this->belongsTo(ItemBatch::class, 'batch_id'); }
    public function location(): BelongsTo { return $this->belongsTo(StockLocation::class, 'location_id'); }
}
