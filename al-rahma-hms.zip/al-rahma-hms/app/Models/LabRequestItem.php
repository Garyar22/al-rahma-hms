<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class LabRequestItem extends Model
{
    use HasFactory;

    protected $fillable = ['lab_request_id', 'lab_test_id', 'status', 'price', 'sample_id', 'completed_at', 'verified_at', 'verified_by', 'cancellation_reason'];

    protected function casts(): array
    {
        return ['status' => \App\Enums\LabItemStatus::class, 'price' => 'decimal:2', 'completed_at' => 'datetime', 'verified_at' => 'datetime'];
    }

    public function request(): BelongsTo { return $this->belongsTo(LabRequest::class, "lab_request_id"); }
    public function test(): BelongsTo    { return $this->belongsTo(LabTest::class, "lab_test_id"); }
    public function sample(): BelongsTo  { return $this->belongsTo(LabSample::class, "sample_id"); }
    public function results(): HasMany   { return $this->hasMany(LabResult::class)->whereNull("supersedes_id"); }
    public function allResults(): HasMany { return $this->hasMany(LabResult::class); }

    public function turnaroundHours(): ?float
    {
        if (! $this->verified_at) { return null; }
        return round($this->request->requested_at->diffInMinutes($this->verified_at) / 60, 1);
    }
}
