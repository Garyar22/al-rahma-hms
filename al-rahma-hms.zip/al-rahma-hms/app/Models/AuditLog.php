<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use RuntimeException;

/**
 * Append-only (FR-SEC-05). Updates and deletes throw, and in production the
 * application's database user holds only INSERT and SELECT on this table —
 * so even a compromised application account cannot rewrite the trail.
 */
class AuditLog extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'occurred_at', 'user_id', 'user_name_snapshot', 'role_snapshot',
        'action', 'module', 'auditable_type', 'auditable_id', 'changed_fields',
        'old_values', 'new_values', 'context', 'reason', 'ip_address', 'user_agent',
    ];

    protected function casts(): array
    {
        return [
            'occurred_at'    => 'datetime',
            'changed_fields' => 'array',
            'old_values'     => 'array',
            'new_values'     => 'array',
            'context'        => 'array',
        ];
    }

    protected static function booted(): void
    {
        static::updating(fn () => throw new RuntimeException('Audit entries are immutable.'));
        static::deleting(fn () => throw new RuntimeException('Audit entries cannot be deleted.'));
    }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }

    public function scopeBreakGlass(Builder $q): Builder
    {
        return $q->where('action', 'security.break_glass');
    }
}
