<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class InvoiceItem extends Model
{
    use HasFactory;

    protected $fillable = ['invoice_id', 'service_id', 'billable_type', 'billable_id', 'department_id', 'description', 'quantity', 'unit_price', 'discount_amount', 'line_total', 'created_by'];

    protected function casts(): array
    {
        return ['quantity' => 'decimal:2', 'unit_price' => 'decimal:2', 'discount_amount' => 'decimal:2', 'line_total' => 'decimal:2'];
    }

    public function invoice(): BelongsTo    { return $this->belongsTo(Invoice::class); }
    public function service(): BelongsTo    { return $this->belongsTo(Service::class); }
    public function department(): BelongsTo { return $this->belongsTo(Department::class); }

    public function billable(): \Illuminate\Database\Eloquent\Relations\MorphTo
    {
        return $this->morphTo();
    }
}
