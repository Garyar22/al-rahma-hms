<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Ward extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'department_id', 'gender_restriction', 'daily_bed_rate', 'is_active'];

    protected function casts(): array
    {
        return ['daily_bed_rate' => 'decimal:2', 'is_active' => 'boolean'];
    }

    public function department(): BelongsTo { return $this->belongsTo(Department::class); }
    public function beds(): HasMany          { return $this->hasMany(Bed::class); }

    public function availableBeds(): int
    {
        return $this->beds()->where("status", "available")->count();
    }
}
