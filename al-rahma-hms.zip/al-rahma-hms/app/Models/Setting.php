<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Setting extends Model
{
    use HasFactory;

    protected $fillable = ['group', 'key', 'value', 'type', 'label', 'description', 'is_security_sensitive', 'updated_by'];

    protected function casts(): array
    {
        return ['is_security_sensitive' => 'boolean'];
    }

    public function updatedBy(): BelongsTo { return $this->belongsTo(User::class, "updated_by"); }
}
