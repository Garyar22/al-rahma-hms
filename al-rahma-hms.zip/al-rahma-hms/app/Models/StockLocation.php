<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class StockLocation extends Model
{
    use HasFactory;

    protected $fillable = ['code', 'name', 'type', 'department_id', 'is_dispensing_point', 'is_active'];

    protected function casts(): array
    {
        return ['is_dispensing_point' => 'boolean', 'is_active' => 'boolean'];
    }

    public function department(): BelongsTo { return $this->belongsTo(Department::class); }
    public function balances(): HasMany     { return $this->hasMany(StockBalance::class, "location_id"); }
    public function movements(): HasMany    { return $this->hasMany(StockMovement::class, "location_id"); }
}
