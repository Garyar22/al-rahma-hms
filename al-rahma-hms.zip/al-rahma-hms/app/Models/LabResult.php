<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use RuntimeException;

/** Immutable once entered (FR-LAB-09). An amendment inserts a new row with
 |  supersedes_id pointing here; both versions stay visible. */
class LabResult extends Model
{
    use HasFactory;

    protected $fillable = [
        'lab_request_item_id', 'parameter_id', 'value_numeric', 'value_text',
        'flag', 'ref_range_snapshot', 'entered_by', 'entered_at',
        'supersedes_id', 'is_amended', 'amendment_reason', 'comments',
    ];

    protected function casts(): array
    {
        return [
            'value_numeric' => 'decimal:3',
            'entered_at'    => 'datetime',
            'is_amended'    => 'boolean',
        ];
    }

    protected static function booted(): void
    {
        static::updating(function (self $result): void {
            if (array_diff(array_keys($result->getDirty()), ['updated_at']) !== []) {
                throw new RuntimeException(
                    'Laboratory results are immutable. Enter an amended result instead.'
                );
            }
        });

        static::deleting(fn () => throw new RuntimeException('Laboratory results cannot be deleted.'));
    }

    public function requestItem(): BelongsTo { return $this->belongsTo(LabRequestItem::class, 'lab_request_item_id'); }
    public function parameter(): BelongsTo   { return $this->belongsTo(LabTestParameter::class, 'parameter_id'); }
    public function enteredBy(): BelongsTo   { return $this->belongsTo(User::class, 'entered_by'); }
    public function supersedes(): BelongsTo  { return $this->belongsTo(self::class, 'supersedes_id'); }

    public function isCritical(): bool
    {
        return in_array($this->flag, ['critical_low', 'critical_high'], true);
    }

    public function displayValue(): string
    {
        return $this->value_text ?? (string) $this->value_numeric;
    }
}
