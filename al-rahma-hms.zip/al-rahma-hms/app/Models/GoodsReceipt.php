<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class GoodsReceipt extends Model
{
    use HasFactory;

    protected $fillable = ['grn_number', 'supplier_id', 'location_id', 'invoice_reference', 'received_at', 'total_cost', 'received_by', 'notes'];

    protected function casts(): array
    {
        return ['received_at' => 'datetime', 'total_cost' => 'decimal:2'];
    }

    public function supplier(): BelongsTo { return $this->belongsTo(Supplier::class); }
    public function location(): BelongsTo { return $this->belongsTo(StockLocation::class, "location_id"); }
    public function items(): HasMany      { return $this->hasMany(GoodsReceiptItem::class); }
}
