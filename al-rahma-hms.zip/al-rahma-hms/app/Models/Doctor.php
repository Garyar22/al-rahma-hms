<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Carbon;

class Doctor extends Model
{
    use HasFactory;

    protected $fillable = [
        'employee_id', 'specialty', 'license_number', 'qualification',
        'consultation_fee', 'consultation_service_id', 'default_slot_minutes',
        'signature_path', 'is_accepting_appointments',
    ];

    protected function casts(): array
    {
        return [
            'consultation_fee'          => 'decimal:2',
            'is_accepting_appointments' => 'boolean',
        ];
    }

    public function employee(): BelongsTo     { return $this->belongsTo(Employee::class); }
    public function schedules(): HasMany      { return $this->hasMany(DoctorSchedule::class); }
    public function absences(): HasMany       { return $this->hasMany(DoctorAbsence::class); }
    public function appointments(): HasMany   { return $this->hasMany(Appointment::class); }
    public function consultations(): HasMany  { return $this->hasMany(Consultation::class); }
    public function visits(): HasMany         { return $this->hasMany(Visit::class); }

    public function name(): string
    {
        return 'Dr. '.($this->employee?->fullName() ?? '—');
    }

    /** Used before booking, so the receptionist gets a clear message rather
     |  than a database constraint error (the constraint is still the
     |  guarantee — see the appointments migration). */
    public function isAvailableAt(Carbon $start, Carbon $end): bool
    {
        if (! $this->is_accepting_appointments) {
            return false;
        }

        $onLeave = $this->absences()
            ->where('starts_at', '<', $end)
            ->where('ends_at', '>', $start)
            ->exists();

        if ($onLeave) {
            return false;
        }

        $hasSchedule = $this->schedules()
            ->where('is_active', true)
            ->where('day_of_week', (int) $start->dayOfWeek)
            ->whereTime('start_time', '<=', $start->format('H:i:s'))
            ->whereTime('end_time', '>=', $end->format('H:i:s'))
            ->where('effective_from', '<=', $start->toDateString())
            ->where(fn ($q) => $q->whereNull('effective_to')->orWhere('effective_to', '>=', $start->toDateString()))
            ->exists();

        if (! $hasSchedule) {
            return false;
        }

        return ! $this->appointments()
            ->whereNotNull('slot_lock')
            ->where('scheduled_start', '<', $end)
            ->where('scheduled_end', '>', $start)
            ->exists();
    }
}
