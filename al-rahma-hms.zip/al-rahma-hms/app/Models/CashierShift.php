<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class CashierShift extends Model
{
    use HasFactory;

    protected $fillable = ['user_id', 'opened_at', 'closed_at', 'opening_float', 'declared_cash', 'system_cash', 'variance', 'status', 'reviewed_by', 'notes'];

    protected function casts(): array
    {
        return ['opened_at' => 'datetime', 'closed_at' => 'datetime', 'opening_float' => 'decimal:2', 'declared_cash' => 'decimal:2', 'system_cash' => 'decimal:2', 'variance' => 'decimal:2'];
    }

    public function user(): BelongsTo     { return $this->belongsTo(User::class); }
    public function payments(): HasMany   { return $this->hasMany(Payment::class, "shift_id"); }

    /** Cash the system says should be in the drawer: float + cash payments,
     |  net of cash reversals. */
    public function expectedCash(): float
    {
        return (float) $this->opening_float + (float) $this->payments()
            ->whereHas("method", fn ($q) => $q->where("is_cash", true))
            ->sum("amount");
    }
}
