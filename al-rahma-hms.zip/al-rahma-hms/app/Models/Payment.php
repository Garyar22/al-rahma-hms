<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use App\Support\Money;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use RuntimeException;

/**
 * A payment and its receipt. Immutable once written (FR-PAY-05).
 *
 * A reversal is a separate row with a negative amount pointing at the
 * original; the original keeps its receipt number and stays printable, marked
 * REVERSED. That is what makes "I paid and there is no record" answerable.
 */
class Payment extends Model
{
    use Auditable, HasFactory;

    protected string $auditModule = 'payments';

    protected $fillable = [
        'receipt_number', 'invoice_id', 'patient_id', 'type', 'amount',
        'payment_method_id', 'reference_no', 'status', 'reverses_payment_id',
        'shift_id', 'received_by', 'paid_at', 'reason', 'notes',
    ];

    protected function casts(): array
    {
        return [
            'amount'        => 'decimal:2',
            'paid_at'       => 'datetime',
            'business_date' => 'date',
        ];
    }

    protected static function booted(): void
    {
        static::deleting(fn () => throw new RuntimeException(
            'Payments cannot be deleted. Record a reversal instead.'
        ));

        static::updating(function (self $payment): void {
            // Only the controlled fields may ever change after issue.
            $allowed = ['status', 'print_count', 'notes', 'updated_at'];

            if (array_diff(array_keys($payment->getDirty()), $allowed) !== []) {
                throw new RuntimeException('A receipt cannot be altered after it is issued.');
            }
        });
    }

    public function invoice(): BelongsTo  { return $this->belongsTo(Invoice::class); }
    public function patient(): BelongsTo  { return $this->belongsTo(Patient::class); }
    public function method(): BelongsTo   { return $this->belongsTo(PaymentMethod::class, 'payment_method_id'); }
    public function shift(): BelongsTo    { return $this->belongsTo(CashierShift::class, 'shift_id'); }
    public function receivedBy(): BelongsTo { return $this->belongsTo(User::class, 'received_by'); }
    public function reverses(): BelongsTo  { return $this->belongsTo(self::class, 'reverses_payment_id'); }

    public function money(): Money
    {
        return Money::fromDecimal($this->amount);
    }

    public function isReversal(): bool
    {
        return $this->type !== 'payment';
    }
}
