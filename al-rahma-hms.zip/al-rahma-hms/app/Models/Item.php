<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

/** One master for medicines and supplies alike (Blueprint D2). */
class Item extends Model
{
    use Auditable, HasFactory, SoftDeletes;

    protected string $auditModule = 'inventory';

    protected $fillable = [
        'item_code', 'name', 'generic_name', 'brand_name', 'item_type',
        'category_id', 'unit_id', 'strength', 'dosage_form', 'route',
        'is_batch_tracked', 'is_expiry_tracked', 'is_billable',
        'requires_prescription', 'reorder_level', 'default_selling_price',
        'service_id', 'notes', 'is_active',
    ];

    protected function casts(): array
    {
        return [
            'is_batch_tracked'      => 'boolean',
            'is_expiry_tracked'     => 'boolean',
            'is_billable'           => 'boolean',
            'requires_prescription' => 'boolean',
            'is_active'             => 'boolean',
            'reorder_level'         => 'decimal:2',
            'default_selling_price' => 'decimal:2',
        ];
    }

    public function category(): BelongsTo { return $this->belongsTo(ItemCategory::class, 'category_id'); }
    public function unit(): BelongsTo     { return $this->belongsTo(Unit::class); }
    public function service(): BelongsTo  { return $this->belongsTo(Service::class); }
    public function batches(): HasMany    { return $this->hasMany(ItemBatch::class); }
    public function balances(): HasMany   { return $this->hasMany(StockBalance::class); }
    public function movements(): HasMany  { return $this->hasMany(StockMovement::class); }

    public function quantityAt(int $locationId): float
    {
        return (float) $this->balances()->where('location_id', $locationId)->sum('quantity');
    }

    public function totalQuantity(): float
    {
        return (float) $this->balances()->sum('quantity');
    }

    public function isLowStock(): bool
    {
        return $this->totalQuantity() <= (float) $this->reorder_level;
    }

    /**
     * FEFO — first expiry, first out (FR-PHA-03).
     *
     * Expired batches are excluded outright: offering them and relying on the
     * pharmacist to notice is how expired medicine reaches a patient.
     */
    public function fefoBatches(int $locationId)
    {
        return StockBalance::query()
            ->where('item_id', $this->id)
            ->where('location_id', $locationId)
            ->where('quantity', '>', 0)
            ->whereHas('batch', fn (Builder $q) => $q
                ->where(fn (Builder $b) => $b->whereNull('expiry_date')->orWhere('expiry_date', '>', now())))
            ->with('batch')
            ->get()
            ->sortBy(fn (StockBalance $b) => $b->batch?->expiry_date?->timestamp ?? PHP_INT_MAX)
            ->values();
    }

    public function scopeActive(Builder $q): Builder { return $q->where('is_active', true); }
}
