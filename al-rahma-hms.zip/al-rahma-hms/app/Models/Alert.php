<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Alert extends Model
{
    use HasFactory;

    protected $fillable = ['type', 'severity', 'subject_type', 'subject_id', 'message', 'data', 'is_resolved', 'resolved_at'];

    protected function casts(): array
    {
        return ['data' => 'array', 'is_resolved' => 'boolean', 'resolved_at' => 'datetime'];
    }

    public function scopeOpen($query) { return $query->where("is_resolved", false); }
}
