<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class PatientMerge extends Model
{
    use HasFactory;

    protected $fillable = ['surviving_patient_id', 'merged_patient_id', 'merged_patient_number', 'reason', 'moved_counts', 'performed_by', 'performed_at'];

    protected function casts(): array
    {
        return ['moved_counts' => 'array', 'performed_at' => 'datetime'];
    }

    public function surviving(): BelongsTo { return $this->belongsTo(Patient::class, "surviving_patient_id"); }
    public function merged(): BelongsTo    { return $this->belongsTo(Patient::class, "merged_patient_id"); }
}
