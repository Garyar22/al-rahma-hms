<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class PatientCondition extends Model
{
    use HasFactory;

    protected $fillable = ['patient_id', 'condition', 'onset_date', 'status', 'notes', 'recorded_by'];

    protected function casts(): array
    {
        return ['onset_date' => 'date'];
    }

    public function patient(): BelongsTo { return $this->belongsTo(Patient::class); }
}
