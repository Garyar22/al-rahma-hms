<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class DoctorSchedule extends Model
{
    use HasFactory;

    protected $fillable = ['doctor_id', 'department_id', 'day_of_week', 'start_time', 'end_time', 'slot_minutes', 'effective_from', 'effective_to', 'is_active'];

    protected function casts(): array
    {
        return ['effective_from' => 'date', 'effective_to' => 'date', 'is_active' => 'boolean'];
    }

    public function doctor(): BelongsTo     { return $this->belongsTo(Doctor::class); }
    public function department(): BelongsTo { return $this->belongsTo(Department::class); }
}
