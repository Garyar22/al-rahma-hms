<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Supplier extends Model
{
    use Auditable, HasFactory, SoftDeletes;

    protected string $auditModule = 'inventory';

    protected $fillable = [
        'name', 'contact_person', 'phone', 'email', 'address',
        'supplier_type', 'status', 'notes',
    ];

    public function goodsReceipts(): HasMany { return $this->hasMany(GoodsReceipt::class); }
    public function batches(): HasMany       { return $this->hasMany(ItemBatch::class); }
}
