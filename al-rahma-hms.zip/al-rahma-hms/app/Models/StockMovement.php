<?php

declare(strict_types=1);

namespace App\Models;

use App\Enums\StockMovementType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use RuntimeException;

/** Append-only. Updates and deletes are refused at the model level so that a
 |  stray save() can never rewrite stock history. */
class StockMovement extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'item_id', 'batch_id', 'location_id', 'counterparty_location_id', 'type',
        'quantity_change', 'balance_after', 'unit_cost', 'reference_type',
        'reference_id', 'reason', 'performed_by', 'occurred_at', 'created_at',
    ];

    protected function casts(): array
    {
        return [
            'type'            => StockMovementType::class,
            'quantity_change' => 'decimal:2',
            'balance_after'   => 'decimal:2',
            'unit_cost'       => 'decimal:2',
            'occurred_at'     => 'datetime',
            'created_at'      => 'datetime',
            'business_date'   => 'date',
        ];
    }

    protected static function booted(): void
    {
        static::updating(fn () => throw new RuntimeException('Stock movements are immutable.'));
        static::deleting(fn () => throw new RuntimeException('Stock movements cannot be deleted.'));
    }

    public function item(): BelongsTo      { return $this->belongsTo(Item::class); }
    public function batch(): BelongsTo     { return $this->belongsTo(ItemBatch::class, 'batch_id'); }
    public function location(): BelongsTo  { return $this->belongsTo(StockLocation::class, 'location_id'); }
    public function performedBy(): BelongsTo { return $this->belongsTo(User::class, 'performed_by'); }
    public function reference(): MorphTo    { return $this->morphTo(); }
}
