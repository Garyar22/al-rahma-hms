<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * slot_lock is the whole double-booking guarantee (see the migration).
 *
 * It must equal scheduled_start while the appointment is live, and NULL once
 * it is cancelled or marked no-show. Keeping that invariant in a model event
 * means no controller can forget it and quietly reopen the hole.
 */
class Appointment extends Model
{
    use Auditable, HasFactory;

    protected string $auditModule = 'appointments';

    protected $fillable = [
        'appointment_number', 'patient_id', 'doctor_id', 'department_id',
        'scheduled_start', 'scheduled_end', 'status', 'reason', 'notes',
        'checked_in_at', 'visit_id', 'cancelled_by', 'cancellation_reason', 'created_by',
    ];

    protected function casts(): array
    {
        return [
            'scheduled_start' => 'datetime',
            'scheduled_end'   => 'datetime',
            'slot_lock'       => 'datetime',
            'checked_in_at'   => 'datetime',
        ];
    }

    public const RELEASED_STATUSES = ['cancelled', 'no_show'];

    protected static function booted(): void
    {
        static::saving(function (self $appointment): void {
            $appointment->slot_lock = in_array($appointment->status, self::RELEASED_STATUSES, true)
                ? null
                : $appointment->scheduled_start;
        });
    }

    public function patient(): BelongsTo    { return $this->belongsTo(Patient::class); }
    public function doctor(): BelongsTo     { return $this->belongsTo(Doctor::class); }
    public function department(): BelongsTo { return $this->belongsTo(Department::class); }
    public function visit(): BelongsTo      { return $this->belongsTo(Visit::class); }

    public function isActive(): bool
    {
        return ! in_array($this->status, self::RELEASED_STATUSES, true);
    }
}
