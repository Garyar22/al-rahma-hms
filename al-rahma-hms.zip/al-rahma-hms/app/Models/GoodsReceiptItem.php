<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class GoodsReceiptItem extends Model
{
    use HasFactory;

    protected $fillable = ['goods_receipt_id', 'item_id', 'batch_id', 'quantity', 'unit_cost', 'selling_price', 'expiry_date', 'line_total'];

    protected function casts(): array
    {
        return ['expiry_date' => 'date', 'quantity' => 'decimal:2', 'unit_cost' => 'decimal:2', 'selling_price' => 'decimal:2', 'line_total' => 'decimal:2'];
    }

    public function goodsReceipt(): BelongsTo { return $this->belongsTo(GoodsReceipt::class); }
    public function item(): BelongsTo         { return $this->belongsTo(Item::class); }
    public function batch(): BelongsTo        { return $this->belongsTo(ItemBatch::class, "batch_id"); }
}
