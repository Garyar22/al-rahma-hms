<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Carbon;

class Employee extends Model
{
    use Auditable, HasFactory, SoftDeletes;

    protected string $auditModule = 'staff';

    protected $fillable = [
        'employee_number', 'first_name', 'middle_name', 'last_name', 'gender',
        'date_of_birth', 'phone', 'email', 'department_id', 'job_title',
        'hire_date', 'employment_status', 'shift_start', 'shift_end',
        'emergency_contact_name', 'emergency_contact_phone', 'address', 'notes',
    ];

    protected function casts(): array
    {
        return ['date_of_birth' => 'date', 'hire_date' => 'date'];
    }

    public function department(): BelongsTo { return $this->belongsTo(Department::class); }
    public function user(): HasOne          { return $this->hasOne(User::class); }
    public function doctor(): HasOne        { return $this->hasOne(Doctor::class); }
    public function attendance(): HasMany   { return $this->hasMany(Attendance::class); }
    public function leaveRequests(): HasMany { return $this->hasMany(LeaveRequest::class); }

    public function fullName(): string
    {
        return trim(implode(' ', array_filter([$this->first_name, $this->middle_name, $this->last_name])));
    }

    /** Lateness is derived from the shift, never typed in (FR-STF-04). */
    public function minutesLateAt(Carbon $checkIn): int
    {
        if (! $this->shift_start) {
            return 0;
        }

        $expected = $checkIn->copy()->setTimeFromTimeString((string) $this->shift_start);

        return $checkIn->greaterThan($expected) ? (int) $expected->diffInMinutes($checkIn) : 0;
    }
}
