<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ItemBatch extends Model
{
    use HasFactory;

    protected $fillable = [
        'item_id', 'batch_number', 'expiry_date', 'cost_price',
        'selling_price', 'supplier_id', 'received_at',
    ];

    protected function casts(): array
    {
        return [
            'expiry_date'   => 'date',
            'received_at'   => 'datetime',
            'cost_price'    => 'decimal:2',
            'selling_price' => 'decimal:2',
        ];
    }

    public function item(): BelongsTo     { return $this->belongsTo(Item::class); }
    public function supplier(): BelongsTo { return $this->belongsTo(Supplier::class); }
    public function balances(): HasMany   { return $this->hasMany(StockBalance::class, 'batch_id'); }

    public function isExpired(): bool
    {
        return $this->expiry_date !== null && $this->expiry_date->isPast();
    }

    public function isExpiringSoon(): bool
    {
        $days = (int) config('hospital.inventory.expiry_warning_days', 90);

        return $this->expiry_date !== null
            && ! $this->isExpired()
            && $this->expiry_date->lessThanOrEqualTo(now()->addDays($days));
    }

    public function scopeExpiringWithin(Builder $q, int $days): Builder
    {
        return $q->whereNotNull('expiry_date')
            ->whereBetween('expiry_date', [now()->toDateString(), now()->addDays($days)->toDateString()]);
    }
}
