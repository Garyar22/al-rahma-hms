<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class PrescriptionItem extends Model
{
    use HasFactory;

    protected $fillable = ['prescription_id', 'item_id', 'dose', 'frequency', 'route', 'duration_days', 'quantity_prescribed', 'quantity_dispensed', 'instructions', 'status'];

    protected function casts(): array
    {
        return ['quantity_prescribed' => 'decimal:2', 'quantity_dispensed' => 'decimal:2'];
    }

    public function prescription(): BelongsTo { return $this->belongsTo(Prescription::class); }
    public function item(): BelongsTo         { return $this->belongsTo(Item::class); }

    public function remainingQuantity(): float
    {
        return max(0, (float) $this->quantity_prescribed - (float) $this->quantity_dispensed);
    }
}
