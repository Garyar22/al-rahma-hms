<?php

declare(strict_types=1);

namespace App\Models;

use App\Enums\InvoiceStatus;
use App\Models\Concerns\Auditable;
use App\Support\Money;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use RuntimeException;

class Invoice extends Model
{
    use Auditable, HasFactory;

    protected string $auditModule = 'billing';

    protected $fillable = [
        'invoice_number', 'patient_id', 'visit_id', 'admission_id', 'status',
        'subtotal', 'discount_amount', 'discount_reason', 'discount_approved_by',
        'total', 'amount_paid', 'balance', 'currency', 'issued_at',
        'created_by', 'cancelled_by', 'cancelled_at', 'cancellation_reason',
    ];

    protected function casts(): array
    {
        return [
            'status'          => InvoiceStatus::class,
            'subtotal'        => 'decimal:2',
            'discount_amount' => 'decimal:2',
            'total'           => 'decimal:2',
            'amount_paid'     => 'decimal:2',
            'balance'         => 'decimal:2',
            'issued_at'       => 'datetime',
            'cancelled_at'    => 'datetime',
            'business_date'   => 'date',
        ];
    }

    /** Financial records are never deleted (§49.6). */
    protected static function booted(): void
    {
        static::deleting(fn () => throw new RuntimeException(
            'Invoices cannot be deleted. Cancel or write off instead, with a reason.'
        ));
    }

    public function patient(): BelongsTo   { return $this->belongsTo(Patient::class); }
    public function visit(): BelongsTo     { return $this->belongsTo(Visit::class); }
    public function admission(): BelongsTo { return $this->belongsTo(Admission::class); }
    public function items(): HasMany       { return $this->hasMany(InvoiceItem::class); }
    public function payments(): HasMany    { return $this->hasMany(Payment::class); }

    /**
     * Recalculates totals from the line items and the completed payments.
     *
     * All arithmetic goes through Money, so there is exactly one rounding
     * rule in the system. Reversals carry a negative amount, so summing the
     * payments already yields the correct net figure.
     */
    public function recalculate(): void
    {
        $subtotal = Money::zero($this->currency);

        foreach ($this->items as $item) {
            $subtotal = $subtotal->plus(Money::fromDecimal($item->line_total, $this->currency));
        }

        $discount = Money::fromDecimal($this->discount_amount ?? 0, $this->currency);
        $total    = $subtotal->minus($discount);

        $paid = Money::fromDecimal(
            (string) $this->payments()->where('status', 'completed')->sum('amount'),
            $this->currency
        );

        $this->subtotal    = $subtotal->toDecimal();
        $this->total       = $total->toDecimal();
        $this->amount_paid = $paid->toDecimal();
        $this->balance     = $total->minus($paid)->toDecimal();

        if ($this->status !== InvoiceStatus::Draft && ! in_array($this->status, [InvoiceStatus::Cancelled, InvoiceStatus::WrittenOff], true)) {
            $this->status = match (true) {
                $paid->isZero()                 => InvoiceStatus::Issued,
                $paid->greaterThan($total->minus(Money::fromMinor(1))) => InvoiceStatus::Paid,
                default                         => InvoiceStatus::PartiallyPaid,
            };
        }

        $this->save();
    }

    public function outstanding(): Money
    {
        return Money::fromDecimal($this->balance, $this->currency);
    }
}
