<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class LabSample extends Model
{
    use HasFactory;

    protected $fillable = ['sample_number', 'lab_request_id', 'sample_type', 'collected_by', 'collected_at', 'condition', 'rejected_at', 'rejected_by', 'rejection_reason'];

    protected function casts(): array
    {
        return ['collected_at' => 'datetime', 'rejected_at' => 'datetime'];
    }

    public function request(): BelongsTo { return $this->belongsTo(LabRequest::class, "lab_request_id"); }
    public function collector(): BelongsTo { return $this->belongsTo(User::class, "collected_by"); }
}
