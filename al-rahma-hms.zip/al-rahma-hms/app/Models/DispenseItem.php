<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class DispenseItem extends Model
{
    use HasFactory;

    protected $fillable = ['dispense_id', 'prescription_item_id', 'item_id', 'batch_id', 'quantity', 'unit_price', 'line_total'];

    protected function casts(): array
    {
        return ['quantity' => 'decimal:2', 'unit_price' => 'decimal:2', 'line_total' => 'decimal:2'];
    }

    public function dispense(): BelongsTo { return $this->belongsTo(Dispense::class); }
    public function item(): BelongsTo     { return $this->belongsTo(Item::class); }
    public function batch(): BelongsTo    { return $this->belongsTo(ItemBatch::class, "batch_id"); }
}
