<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class ReportRun extends Model
{
    use HasFactory;

    protected $fillable = ['reference_no', 'report_key', 'parameters', 'format', 'row_count', 'duration_ms', 'generated_by', 'generated_at'];

    protected function casts(): array
    {
        return ['parameters' => 'array', 'generated_at' => 'datetime'];
    }

    public function generatedBy(): BelongsTo { return $this->belongsTo(User::class, "generated_by"); }
}
