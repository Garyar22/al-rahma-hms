<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Service extends Model
{
    use Auditable, HasFactory, SoftDeletes;

    protected string $auditModule = 'billing';

    protected $fillable = [
        'code', 'name', 'category', 'department_id', 'price', 'currency',
        'requires_prepayment', 'is_active', 'description',
    ];

    protected function casts(): array
    {
        return [
            'price'               => 'decimal:2',
            'requires_prepayment' => 'boolean',
            'is_active'           => 'boolean',
        ];
    }

    public function department(): BelongsTo { return $this->belongsTo(Department::class); }

    /** Falls back to the hospital-wide billing mode when the service itself
     |  does not override it (open question Q4). */
    public function needsPrepayment(): bool
    {
        return $this->requires_prepayment
            ?? config('hospital.billing.mode') === 'pay_before_service';
    }
}
