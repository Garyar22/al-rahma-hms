<?php

declare(strict_types=1);

namespace App\Models\Concerns;

use App\Enums\AuditAction;
use App\Services\Shared\AuditLogger;

/**
 * Add to any model whose changes must be audited.
 *
 * Declare $auditModule on the model, and $auditExcluded for clinical free-text
 * fields whose VALUES must not be copied into the audit table (Blueprint D12);
 * their names are still recorded, so the trail shows that they changed.
 */
trait Auditable
{
    public static function bootAuditable(): void
    {
        static::created(fn ($model) => app(AuditLogger::class)
            ->logModelChange($model, AuditAction::Created, $model->auditModule()));

        static::updated(fn ($model) => app(AuditLogger::class)
            ->logModelChange($model, AuditAction::Updated, $model->auditModule()));

        static::deleted(fn ($model) => app(AuditLogger::class)
            ->logModelChange($model, AuditAction::Deleted, $model->auditModule()));
    }

    public function auditModule(): string
    {
        return property_exists($this, 'auditModule') ? $this->auditModule : 'general';
    }

    /** @return array<int,string> */
    public function auditExcludedFields(): array
    {
        return property_exists($this, 'auditExcluded') ? $this->auditExcluded : [];
    }
}
