<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use RuntimeException;

class Consultation extends Model
{
    use Auditable, HasFactory;

    protected string $auditModule = 'clinical';

    /** The clinical narrative is audited by field name only — never copied
     |  into the audit table (Blueprint D12). */
    protected array $auditExcluded = [
        'chief_complaint', 'history_present_illness', 'past_medical_history',
        'current_medication', 'examination', 'assessment', 'plan', 'follow_up_notes',
    ];

    protected $fillable = [
        'visit_id', 'patient_id', 'doctor_id', 'chief_complaint',
        'history_present_illness', 'past_medical_history', 'current_medication',
        'examination', 'assessment', 'plan', 'follow_up_date', 'follow_up_notes',
        'status', 'finalised_at',
    ];

    protected function casts(): array
    {
        return ['follow_up_date' => 'date', 'finalised_at' => 'datetime'];
    }

    /** A finalised note is never rewritten (FR-CON-05, §49.2). */
    protected static function booted(): void
    {
        static::updating(function (self $consultation): void {
            $wasFinalised = $consultation->getOriginal('status') === 'finalised';
            $onlyStatus   = array_diff(array_keys($consultation->getDirty()), ['updated_at']) === ['status'];

            if ($wasFinalised && ! $onlyStatus) {
                throw new RuntimeException(
                    'A finalised consultation cannot be edited. Add an addendum instead.'
                );
            }
        });
    }

    public function visit(): BelongsTo   { return $this->belongsTo(Visit::class); }
    public function patient(): BelongsTo { return $this->belongsTo(Patient::class); }
    public function doctor(): BelongsTo  { return $this->belongsTo(Doctor::class); }
    public function diagnoses(): HasMany { return $this->hasMany(Diagnosis::class); }
    public function addenda(): HasMany   { return $this->hasMany(ConsultationAddendum::class)->oldest(); }

    public function isEditableBy(User $user): bool
    {
        if ($this->status === 'finalised') {
            return false;
        }

        return $this->doctor?->employee?->user_id === $user->id
            || $this->doctor?->employee?->id === $user->employee_id;
    }

    public function finalise(): void
    {
        $this->forceFill(['status' => 'finalised', 'finalised_at' => now()])->save();
    }
}
