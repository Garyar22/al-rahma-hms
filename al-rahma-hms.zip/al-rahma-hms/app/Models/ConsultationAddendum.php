<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class ConsultationAddendum extends Model
{
    use HasFactory;

    protected $fillable = ['consultation_id', 'body', 'author_id', 'created_at'];

    protected function casts(): array
    {
        return ['created_at' => 'datetime'];
    }

    public $timestamps = false;

    public function consultation(): BelongsTo { return $this->belongsTo(Consultation::class); }
    public function author(): BelongsTo       { return $this->belongsTo(User::class, "author_id"); }
}
