<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\Auditable;
use App\Support\NameNormalizer;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Carbon;

class Patient extends Model
{
    use Auditable, HasFactory, SoftDeletes;

    protected string $auditModule = 'patients';

    /** Demographic changes are audited; these free-text fields are recorded
     |  by name only, never copied into the audit table (Blueprint D12). */
    protected array $auditExcluded = ['notes'];

    protected $fillable = [
        'patient_number', 'first_name', 'middle_name', 'last_name',
        'name_normalized', 'name_soundex', 'gender', 'date_of_birth',
        'dob_accuracy', 'birth_year', 'age_at_registration', 'phone', 'phone_alt',
        'address_line', 'district', 'city', 'blood_group', 'marital_status',
        'occupation', 'next_of_kin_name', 'next_of_kin_phone', 'next_of_kin_relation',
        'status', 'merged_into_patient_id', 'is_unidentified',
        'registered_at', 'registered_by', 'notes',
    ];

    protected function casts(): array
    {
        return [
            'date_of_birth'    => 'date',
            'registered_at'    => 'datetime',
            'business_date'    => 'date',
            'is_unidentified'  => 'boolean',
        ];
    }

    /** Keeps the folded search key in step with the name, always. */
    protected static function booted(): void
    {
        static::saving(function (self $patient): void {
            $patient->name_normalized = NameNormalizer::fold(
                $patient->first_name, $patient->middle_name, $patient->last_name
            );
            $patient->name_soundex = NameNormalizer::soundexKey(
                (string) $patient->first_name, (string) $patient->middle_name, (string) $patient->last_name
            );
        });
    }

    public function fullName(): string
    {
        return trim(implode(' ', array_filter([$this->first_name, $this->middle_name, $this->last_name])));
    }

    /**
     * Age in years from whatever the hospital actually knows.
     *
     * Returns null rather than guessing when nothing is recorded: a wrong age
     * on a paediatric dose or a reference range is worse than a blank.
     */
    public function age(): ?int
    {
        if ($this->date_of_birth && $this->dob_accuracy === 'exact') {
            return $this->date_of_birth->age;
        }

        if ($this->birth_year) {
            return (int) Carbon::now(config('hospital.timezone'))->year - $this->birth_year;
        }

        if ($this->age_at_registration !== null && $this->registered_at) {
            return $this->age_at_registration + (int) $this->registered_at->diffInYears(now());
        }

        return null;
    }

    public function ageLabel(): string
    {
        $age = $this->age();

        if ($age === null) {
            return __('Age unknown');
        }

        return $this->dob_accuracy === 'exact' ? "{$age}" : "~{$age}";
    }

    public function visits(): HasMany      { return $this->hasMany(Visit::class)->latest('arrived_at'); }
    public function appointments(): HasMany { return $this->hasMany(Appointment::class); }
    public function consultations(): HasMany { return $this->hasMany(Consultation::class); }
    public function vitalSigns(): HasMany  { return $this->hasMany(VitalSign::class)->latest('recorded_at'); }
    public function allergies(): HasMany   { return $this->hasMany(PatientAllergy::class)->where('status', 'active'); }
    public function conditions(): HasMany  { return $this->hasMany(PatientCondition::class); }
    public function prescriptions(): HasMany { return $this->hasMany(Prescription::class); }
    public function labRequests(): HasMany { return $this->hasMany(LabRequest::class); }
    public function admissions(): HasMany  { return $this->hasMany(Admission::class); }
    public function invoices(): HasMany    { return $this->hasMany(Invoice::class); }
    public function payments(): HasMany    { return $this->hasMany(Payment::class); }

    public function registeredBy(): BelongsTo { return $this->belongsTo(User::class, 'registered_by'); }
    public function mergedInto(): BelongsTo   { return $this->belongsTo(self::class, 'merged_into_patient_id'); }

    /** Outstanding across every issued, non-cancelled invoice (metric dictionary). */
    public function outstandingBalance(): float
    {
        return (float) $this->invoices()
            ->whereIn('status', ['issued', 'partially_paid'])
            ->sum('balance');
    }

    /**
     * Transliteration-tolerant search (FR-PAT-03).
     * Matches the patient number exactly, the phone exactly, or the folded
     * name key loosely, so "Mohamed Ali" finds "Maxamed Cali".
     */
    public function scopeSearch(Builder $query, string $term): Builder
    {
        $term   = trim($term);
        $folded = NameNormalizer::fold($term);

        return $query->where(function (Builder $q) use ($term, $folded): void {
            $q->where('patient_number', $term)
              ->orWhere('phone', $term)
              ->orWhere('phone_alt', $term)
              ->orWhere('name_normalized', 'like', $folded.'%')
              ->orWhere('name_normalized', 'like', '%'.$folded.'%');
        });
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->whereIn('status', ['active', 'inactive']);
    }
}
