<?php

declare(strict_types=1);

namespace App\Services\Admin;

use App\Enums\AuditAction;
use App\Models\User;
use App\Services\Shared\AuditLogger;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Account lifecycle.
 *
 * Passwords are never chosen by the administrator who creates the account.
 * A strong temporary password is generated, shown once, and must be replaced
 * by the person on first login — so no administrator ever knows a colleague's
 * working password, and the audit trail keeps meaning something.
 */
final class UserService
{
    public function __construct(private readonly AuditLogger $audit) {}

    /**
     * @param  array<string,mixed>  $data
     * @return array{user: User, temporary_password: string}
     */
    public function create(array $data, string $role): array
    {
        return DB::transaction(function () use ($data, $role): array {
            $temporary = $this->generatePassword();

            $user = User::query()->create([
                'employee_id'          => $data['employee_id'] ?? null,
                'name'                 => $data['name'],
                'username'             => Str::lower($data['username']),
                'email'                => $data['email'] ?? null,
                'password'             => $temporary,
                'is_active'            => true,
                'is_protected'         => false,
                'must_change_password' => true,
            ]);

            $user->syncRoles([$role]);

            $this->audit->log(
                AuditAction::PermissionChanged,
                module: 'users',
                subject: $user,
                context: ['operation' => 'account_created', 'role' => $role],
            );

            return ['user' => $user, 'temporary_password' => $temporary];
        });
    }

    /** @param array<string,mixed> $data */
    public function update(User $user, array $data, ?string $role = null): User
    {
        return DB::transaction(function () use ($user, $data, $role): User {
            $user->fill([
                'name'        => $data['name'],
                'username'    => Str::lower($data['username']),
                'email'       => $data['email'] ?? null,
                'employee_id' => $data['employee_id'] ?? null,
            ])->save();

            if ($role !== null && ! $user->is_protected && $user->getRoleNames()->first() !== $role) {
                $previous = $user->getRoleNames()->first();
                $user->syncRoles([$role]);

                $this->audit->log(
                    AuditAction::PermissionChanged,
                    module: 'users',
                    subject: $user,
                    context: ['operation' => 'role_changed', 'from' => $previous, 'to' => $role],
                );
            }

            return $user;
        });
    }

    public function setActive(User $user, bool $active, ?string $reason = null): User
    {
        $user->is_active = $active;
        $user->save();

        $this->audit->log(
            AuditAction::PermissionChanged,
            module: 'users',
            subject: $user,
            context: ['operation' => $active ? 'account_reactivated' : 'account_deactivated'],
            reason: $reason,
        );

        return $user;
    }

    /** Returns the temporary password so it can be shown to the administrator once. */
    public function resetPassword(User $user): string
    {
        $temporary = $this->generatePassword();

        $user->forceFill([
            'password'             => $temporary,
            'must_change_password' => true,
            'failed_login_count'   => 0,
            'locked_until'         => null,
        ])->save();

        $this->audit->log(
            AuditAction::PasswordChanged,
            module: 'users',
            subject: $user,
            context: ['operation' => 'password_reset_by_administrator'],
        );

        return $temporary;
    }

    /**
     * Readable but strong: staff have to type this once from a printed slip,
     * so ambiguous characters would cost more in failed logins than the extra
     * entropy is worth here.
     */
    private function generatePassword(): string
    {
        return Str::password(14, letters: true, numbers: true, symbols: false, spaces: false);
    }
}
