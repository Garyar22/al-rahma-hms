<?php

declare(strict_types=1);

namespace App\Services\Admin;

use App\Enums\AuditAction;
use App\Models\Department;
use App\Services\Shared\AuditLogger;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

/**
 * Create, restructure and retire the hospital's own organisational units.
 *
 * All the rules that keep the structure sane live here, in one place, rather
 * than being re-implemented by whichever screen happens to touch a sector.
 */
final class SectorManager
{
    public function __construct(private readonly AuditLogger $audit) {}

    public function create(array $data, int $userId): Department
    {
        return DB::transaction(function () use ($data, $userId): Department {
            $department = Department::query()->create([
                'code'                 => $this->resolveCode($data['code'] ?? null, $data['name']),
                'name'                 => $data['name'],
                'parent_id'            => $data['parent_id'] ?? null,
                'kind'                 => $data['kind'] ?? 'department',
                'type'                 => $data['type'] ?? 'clinical',
                'modules'              => $data['modules'] ?? [],
                'description'          => $data['description'] ?? null,
                'location_note'        => $data['location_note'] ?? null,
                'phone_extension'      => $data['phone_extension'] ?? null,
                'head_employee_id'     => $data['head_employee_id'] ?? null,
                'accepts_appointments' => (bool) ($data['accepts_appointments'] ?? false),
                'accepts_walkins'      => (bool) ($data['accepts_walkins'] ?? false),
                'is_active'            => (bool) ($data['is_active'] ?? true),
                'display_order'        => (int) ($data['display_order'] ?? 0),
            ]);

            $this->audit->log(
                AuditAction::SectorChanged,
                module: 'organisation',
                subject: $department,
                context: ['operation' => 'created', 'name' => $department->name],
            );

            return $department;
        });
    }

    public function update(Department $department, array $data, int $userId): Department
    {
        $this->guardAgainstCycle($department, $data['parent_id'] ?? null);

        return DB::transaction(function () use ($department, $data): Department {
            // A system sector cannot be switched off, whatever the form says.
            if ($department->is_system) {
                $data['is_active'] = true;
            }

            $department->fill([
                'name'                 => $data['name'],
                'parent_id'            => $data['parent_id'] ?? null,
                'kind'                 => $data['kind'] ?? $department->kind->value,
                'type'                 => $data['type'] ?? $department->type,
                'modules'              => $data['modules'] ?? [],
                'description'          => $data['description'] ?? null,
                'location_note'        => $data['location_note'] ?? null,
                'phone_extension'      => $data['phone_extension'] ?? null,
                'head_employee_id'     => $data['head_employee_id'] ?? null,
                'accepts_appointments' => (bool) ($data['accepts_appointments'] ?? false),
                'accepts_walkins'      => (bool) ($data['accepts_walkins'] ?? false),
                'is_active'            => (bool) ($data['is_active'] ?? true),
                'display_order'        => (int) ($data['display_order'] ?? 0),
            ])->save();

            $this->audit->log(
                AuditAction::SectorChanged,
                module: 'organisation',
                subject: $department,
                context: ['operation' => 'updated', 'changed' => array_keys($department->getChanges())],
            );

            return $department;
        });
    }

    /**
     * Soft-deletes a sector once it is provably unused.
     *
     * Real history is never orphaned: if visits, staff, wards or services
     * point at it, deletion is refused and the caller is told to deactivate
     * instead. Three years of reports must still be able to name the
     * department a patient was seen in.
     */
    public function delete(Department $department, string $reason): void
    {
        $check = $department->deletionCheck();

        if (! $check['allowed']) {
            throw new RuntimeException($check['reason']);
        }

        DB::transaction(function () use ($department, $reason): void {
            $this->audit->log(
                AuditAction::SectorChanged,
                module: 'organisation',
                subject: $department,
                context: ['operation' => 'deleted', 'code' => $department->code, 'name' => $department->name],
                reason: $reason,
            );

            $department->delete();
        });
    }

    public function restore(int $id): Department
    {
        $department = Department::withTrashed()->findOrFail($id);
        $department->restore();

        $this->audit->log(
            AuditAction::SectorChanged,
            module: 'organisation',
            subject: $department,
            context: ['operation' => 'restored'],
        );

        return $department;
    }

    /** Prevents a sector becoming its own ancestor, which would make the tree
     |  render forever and the path label recurse. */
    private function guardAgainstCycle(Department $department, ?int $parentId): void
    {
        if ($parentId === null) {
            return;
        }

        if ($parentId === $department->id) {
            throw new RuntimeException(__('A sector cannot be placed inside itself.'));
        }

        $ancestor = Department::query()->find($parentId);
        $guard    = 0;

        while ($ancestor && $guard++ < 20) {
            if ($ancestor->id === $department->id) {
                throw new RuntimeException(__('That would place this sector inside one of its own sub-sectors.'));
            }
            $ancestor = $ancestor->parent;
        }
    }

    private function resolveCode(?string $code, string $name): string
    {
        $base = $code ? Str::upper(Str::slug($code, '')) : Str::upper(Str::substr(Str::slug($name, ''), 0, 8));
        $try  = $base;
        $n    = 1;

        while (Department::withTrashed()->where('code', $try)->exists()) {
            $try = $base.(++$n);
        }

        return $try;
    }
}
