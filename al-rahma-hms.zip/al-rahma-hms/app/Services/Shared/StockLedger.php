<?php

declare(strict_types=1);

namespace App\Services\Shared;

use App\Enums\AuditAction;
use App\Enums\StockMovementType;
use App\Exceptions\InsufficientStockException;
use App\Models\Item;
use App\Models\ItemBatch;
use App\Models\StockBalance;
use App\Models\StockLocation;
use App\Models\StockMovement;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

/**
 * The ONLY code path in this system allowed to change a stock quantity
 * (Blueprint D4, mandatory rule §49.3).
 *
 * Every change appends an immutable movement and updates the cached balance
 * inside one transaction with the balance row locked. Nothing else — no
 * controller, no model, no seeder — writes to stock_balances. A test asserts
 * that no other class references that table.
 *
 * Why the lock: two pharmacists dispensing the last box of amoxicillin at the
 * same moment would both read "1 available" and both succeed, leaving the
 * balance at -1. The lock makes the second one wait and then fail correctly.
 */
final class StockLedger
{
    public function __construct(private readonly AuditLogger $audit) {}

    public function receive(
        Item $item,
        ?ItemBatch $batch,
        StockLocation $location,
        float $quantity,
        ?float $unitCost = null,
        ?Model $reference = null,
        ?string $reason = null,
    ): StockMovement {
        return $this->apply(StockMovementType::Receipt, $item, $batch, $location, abs($quantity), $unitCost, $reference, $reason);
    }

    public function dispense(
        Item $item,
        ItemBatch $batch,
        StockLocation $location,
        float $quantity,
        ?Model $reference = null,
    ): StockMovement {
        return $this->apply(StockMovementType::Dispense, $item, $batch, $location, -abs($quantity), null, $reference);
    }

    public function adjust(
        Item $item,
        ?ItemBatch $batch,
        StockLocation $location,
        float $signedQuantity,
        string $reason,
        ?Model $reference = null,
    ): StockMovement {
        if (trim($reason) === '') {
            throw new InvalidArgumentException('A stock adjustment requires a reason.');
        }

        $movement = $this->apply(StockMovementType::Adjustment, $item, $batch, $location, $signedQuantity, null, $reference, $reason);

        // Adjustments are the one movement a person can make freely, so they
        // are audited separately from the ledger itself (FR-SEC-04).
        $this->audit->log(
            AuditAction::StockAdjusted,
            module: 'inventory',
            subject: $movement,
            context: ['item' => $item->item_code, 'quantity' => $signedQuantity],
            reason: $reason,
        );

        return $movement;
    }

    /** Moves stock between two locations as a paired out/in, atomically. */
    public function transfer(
        Item $item,
        ?ItemBatch $batch,
        StockLocation $from,
        StockLocation $to,
        float $quantity,
        ?string $reason = null,
    ): array {
        return DB::transaction(function () use ($item, $batch, $from, $to, $quantity, $reason): array {
            $out = $this->apply(StockMovementType::TransferOut, $item, $batch, $from, -abs($quantity), null, null, $reason, $to);
            $in  = $this->apply(StockMovementType::TransferIn, $item, $batch, $to, abs($quantity), null, null, $reason, $from);

            return [$out, $in];
        });
    }

    private function apply(
        StockMovementType $type,
        Item $item,
        ?ItemBatch $batch,
        StockLocation $location,
        float $signedQuantity,
        ?float $unitCost = null,
        ?Model $reference = null,
        ?string $reason = null,
        ?StockLocation $counterparty = null,
    ): StockMovement {
        if ($signedQuantity == 0.0) {
            throw new InvalidArgumentException('A stock movement cannot be zero.');
        }

        if ($item->is_batch_tracked && $batch === null) {
            throw new InvalidArgumentException("Item {$item->item_code} is batch tracked; a batch is required.");
        }

        return DB::transaction(function () use (
            $type, $item, $batch, $location, $signedQuantity, $unitCost, $reference, $reason, $counterparty
        ): StockMovement {
            /** @var StockBalance $balance */
            $balance = StockBalance::query()
                ->where('item_id', $item->id)
                ->where('batch_id', $batch?->id)
                ->where('location_id', $location->id)
                ->lockForUpdate()
                ->first()
                ?? StockBalance::query()->create([
                    'item_id'     => $item->id,
                    'batch_id'    => $batch?->id,
                    'location_id' => $location->id,
                    'quantity'    => 0,
                ]);

            $newQuantity = (float) $balance->quantity + $signedQuantity;

            if ($newQuantity < 0) {
                throw new InsufficientStockException(
                    "Insufficient stock for {$item->name} at {$location->name}: "
                    ."available {$balance->quantity}, requested ".abs($signedQuantity).'.'
                );
            }

            $balance->quantity   = $newQuantity;
            $balance->updated_at = now();
            $balance->save();

            return StockMovement::query()->create([
                'item_id'                  => $item->id,
                'batch_id'                 => $batch?->id,
                'location_id'              => $location->id,
                'counterparty_location_id' => $counterparty?->id,
                'type'                     => $type->value,
                'quantity_change'          => $signedQuantity,
                'balance_after'            => $newQuantity,
                'unit_cost'                => $unitCost,
                'reference_type'           => $reference ? $reference::class : null,
                'reference_id'             => $reference?->getKey(),
                'reason'                   => $reason,
                'performed_by'             => Auth::id(),
                'occurred_at'              => now(),
                'created_at'               => now(),
            ]);
        });
    }
}
