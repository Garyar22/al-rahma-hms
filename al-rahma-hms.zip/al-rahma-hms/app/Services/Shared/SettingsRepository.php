<?php

declare(strict_types=1);

namespace App\Services\Shared;

use App\Enums\AuditAction;
use App\Models\Setting;
use Illuminate\Support\Facades\Cache;

/**
 * The ONLY way application code reads hospital identity and configuration
 * (Rule 11: never hard-code what belongs in Settings).
 *
 * Read once per request from cache; a write busts the cache and writes an
 * audit entry, because changing the invoice prefix or the discount threshold
 * is a financial-control event.
 */
final class SettingsRepository
{
    private const CACHE_KEY = 'hospital.settings';

    /** @var array<string,mixed>|null */
    private ?array $loaded = null;

    public function all(): array
    {
        return $this->loaded ??= Cache::rememberForever(self::CACHE_KEY, function (): array {
            return Setting::query()->get()->mapWithKeys(fn (Setting $s) => [
                $s->key => $this->cast($s->value, $s->type),
            ])->all();
        });
    }

    public function get(string $key, mixed $default = null): mixed
    {
        return $this->all()[$key] ?? $default ?? config(str_replace('hospital.', 'hospital.', $key));
    }

    public function set(string $key, mixed $value, ?int $userId = null): void
    {
        $setting = Setting::query()->where('key', $key)->firstOrFail();
        $old     = $setting->value;

        $setting->value      = is_array($value) ? json_encode($value) : (string) $value;
        $setting->updated_by = $userId;
        $setting->save();

        $this->flush();

        app(AuditLogger::class)->log(
            AuditAction::SettingChanged,
            module: 'settings',
            subject: $setting,
            context: ['key' => $key, 'from' => $old, 'to' => $setting->value],
        );
    }

    public function flush(): void
    {
        $this->loaded = null;
        Cache::forget(self::CACHE_KEY);
    }

    private function cast(?string $value, string $type): mixed
    {
        if ($value === null) {
            return null;
        }

        return match ($type) {
            'int'     => (int) $value,
            'bool'    => filter_var($value, FILTER_VALIDATE_BOOLEAN),
            'decimal' => (float) $value,
            'json'    => json_decode($value, true),
            default   => $value,
        };
    }
}
