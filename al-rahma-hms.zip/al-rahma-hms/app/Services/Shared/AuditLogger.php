<?php

declare(strict_types=1);

namespace App\Services\Shared;

use App\Enums\AuditAction;
use App\Models\AuditLog;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;

/**
 * Writes the audit trail (FR-SEC-04/05).
 *
 * Two entry points:
 *   - logModelChange() for create/update/delete, used by the Auditable trait
 *   - log() for explicit events: login, reversal, dispensing, break-glass,
 *     reprint, export, permission change
 *
 * Clinical free text is NEVER diffed (Blueprint D12). Fields listed in a
 * model's $auditExcluded are recorded by NAME only, so the audit shows that
 * the examination note changed, without storing a second copy of it in a
 * table with different access rules.
 *
 * There is no update() or delete() here, and none anywhere else: the table is
 * append-only by design, not by convention.
 */
final class AuditLogger
{
    public function log(
        AuditAction $action,
        string $module,
        ?Model $subject = null,
        ?array $context = null,
        ?string $reason = null,
        ?array $changedFields = null,
        ?array $oldValues = null,
        ?array $newValues = null,
    ): void {
        $user = Auth::user();

        AuditLog::query()->create([
            'occurred_at'        => now(),
            'user_id'            => $user?->id,
            'user_name_snapshot' => $user?->name,
            'role_snapshot'      => $user?->getRoleNames()->implode(', ') ?: null,
            'action'             => $action->value,
            'module'             => $module,
            'auditable_type'     => $subject ? $subject::class : null,
            'auditable_id'       => $subject?->getKey(),
            'changed_fields'     => $changedFields,
            'old_values'         => $oldValues,
            'new_values'         => $newValues,
            'context'            => $context,
            'reason'             => $reason,
            'ip_address'         => Request::ip(),
            'user_agent'         => substr((string) Request::userAgent(), 0, 255),
        ]);
    }

    public function logModelChange(Model $model, AuditAction $action, string $module): void
    {
        $excluded = method_exists($model, 'auditExcludedFields')
            ? $model->auditExcludedFields()
            : [];

        $changed = array_keys($model->getChanges());
        $changed = array_values(array_diff($changed, ['updated_at']));

        $safeOld = [];
        $safeNew = [];

        foreach ($changed as $field) {
            if (in_array($field, $excluded, true)) {
                continue; // name recorded in changed_fields, value deliberately not stored
            }
            $safeOld[$field] = $model->getOriginal($field);
            $safeNew[$field] = $model->getAttribute($field);
        }

        $this->log(
            action: $action,
            module: $module,
            subject: $model,
            changedFields: $changed ?: null,
            oldValues: $safeOld ?: null,
            newValues: $safeNew ?: null,
        );
    }
}
