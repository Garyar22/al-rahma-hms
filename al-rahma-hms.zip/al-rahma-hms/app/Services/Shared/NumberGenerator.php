<?php

declare(strict_types=1);

namespace App\Services\Shared;

use App\Models\Sequence;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use RuntimeException;

/**
 * Allocates human-readable document numbers (Blueprint D6).
 *
 * ARH-P-000001, ARH-INV-000001, ARH-REC-000001 ...
 *
 * The allocation takes a row lock on the sequence and increments it inside the
 * caller's transaction. MAX(id)+1 is forbidden: under two concurrent
 * receptionists it produces duplicates, and a duplicate receipt number is a
 * financial-control failure, not a cosmetic bug.
 */
final class NumberGenerator
{
    /**
     * @param  string  $key  patient|visit|invoice|receipt|...
     *
     * Must be called inside a transaction. The lock is held until that
     * transaction commits, which is exactly the window in which the record
     * being numbered is also written.
     */
    public function next(string $key): string
    {
        if (DB::transactionLevel() === 0) {
            throw new RuntimeException(
                "NumberGenerator::next('{$key}') must run inside a database transaction."
            );
        }

        /** @var Sequence|null $sequence */
        $sequence = Sequence::query()->where('key', $key)->lockForUpdate()->first();

        if (! $sequence) {
            throw new RuntimeException("Unknown number sequence [{$key}]. Seed it in SequenceSeeder.");
        }

        $period = $this->currentPeriod($sequence->reset_period);

        if ($period !== null && $sequence->current_period !== $period) {
            $sequence->next_number    = 1;
            $sequence->current_period = $period;
        }

        $number = $sequence->next_number;
        $sequence->next_number = $number + 1;
        $sequence->save();

        return $sequence->prefix.str_pad((string) $number, $sequence->padding, '0', STR_PAD_LEFT);
    }

    private function currentPeriod(string $resetPeriod): ?string
    {
        $now = Carbon::now(config('hospital.timezone'));

        return match ($resetPeriod) {
            'yearly'  => $now->format('Y'),
            'monthly' => $now->format('Y-m'),
            default   => null,
        };
    }
}
