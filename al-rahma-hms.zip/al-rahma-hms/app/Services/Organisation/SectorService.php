<?php

declare(strict_types=1);

namespace App\Services\Organisation;

use App\Enums\AuditAction;
use App\Models\Department;
use App\Services\Shared\AuditLogger;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use RuntimeException;

/**
 * Creating, reshaping and retiring the hospital's structure.
 *
 * The administration owns this tree completely: sectors, departments and units
 * to any depth, each choosing which modules it uses. No developer is involved
 * in adding Radiology, splitting Maternity out of Inpatient, or renaming a
 * ward after a refurbishment.
 *
 * Three invariants are enforced here rather than in the controller, so they
 * hold for every caller:
 *
 *  1. A node can never become its own ancestor. Dragging a parent into its own
 *     child would produce a cycle that makes the sidebar recurse forever.
 *  2. Deactivating a node deactivates everything beneath it. A department
 *     cannot be "open" inside a closed sector; staff would see it in a picker
 *     and register patients against it.
 *  3. Deletion is refused whenever history points at the node. The UI then
 *     offers deactivation, which keeps every past visit readable.
 */
final class SectorService
{
    public function __construct(private readonly AuditLogger $audit) {}

    /** @param array<string,mixed> $data */
    public function create(array $data): Department
    {
        return DB::transaction(function () use ($data): Department {
            $data['code'] = $this->uniqueCode($data['code'] ?? null, $data['name']);

            $sector = Department::query()->create($data + [
                'display_order' => $this->nextDisplayOrder($data['parent_id'] ?? null),
            ]);

            $this->audit->log(
                AuditAction::SectorChanged,
                module: 'organisation',
                subject: $sector,
                context: ['operation' => 'created', 'path' => $sector->pathLabel()],
            );

            return $sector;
        });
    }

    /** @param array<string,mixed> $data */
    public function update(Department $sector, array $data): Department
    {
        return DB::transaction(function () use ($sector, $data): Department {
            if (array_key_exists('parent_id', $data)) {
                $this->assertNoCycle($sector, $data['parent_id'] ? (int) $data['parent_id'] : null);
            }

            $wasActive = $sector->is_active;

            $sector->fill($data)->save();

            // Invariant 2: a closed sector closes everything inside it.
            if ($wasActive && ! $sector->is_active) {
                $this->cascadeDeactivate($sector);
            }

            $this->audit->log(
                AuditAction::SectorChanged,
                module: 'organisation',
                subject: $sector,
                context: ['operation' => 'updated', 'path' => $sector->pathLabel()],
                changedFields: array_keys($sector->getChanges()) ?: null,
            );

            return $sector;
        });
    }

    public function delete(Department $sector): void
    {
        $check = $sector->deletionCheck();

        if (! $check['allowed']) {
            throw new RuntimeException($check['reason']);
        }

        DB::transaction(function () use ($sector): void {
            $this->audit->log(
                AuditAction::SectorChanged,
                module: 'organisation',
                subject: $sector,
                context: [
                    'operation' => 'deleted',
                    'path'      => $sector->pathLabel(),
                    'code'      => $sector->code,
                ],
            );

            $sector->delete(); // soft delete: the row survives for the audit trail
        });
    }

    /** Moves a node to a new parent, keeping the tree acyclic. */
    public function move(Department $sector, ?int $parentId): Department
    {
        return $this->update($sector, ['parent_id' => $parentId]);
    }

    /** The whole tree, eager-loaded, ready for the sidebar and the admin screen. */
    public function tree(bool $includeInactive = true): \Illuminate\Support\Collection
    {
        $query = Department::query()->with('children.children.children')->roots()
            ->orderBy('display_order')->orderBy('name');

        if (! $includeInactive) {
            $query->active();
        }

        return $query->get();
    }

    private function assertNoCycle(Department $sector, ?int $parentId): void
    {
        if ($parentId === null) {
            return;
        }

        if ($parentId === $sector->id) {
            throw new RuntimeException(__('A sector cannot sit inside itself.'));
        }

        $ancestor = Department::query()->find($parentId);
        $guard    = 0;

        while ($ancestor && $guard++ < 20) {
            if ($ancestor->id === $sector->id) {
                throw new RuntimeException(__('That would move :name inside one of its own sectors.', ['name' => $sector->name]));
            }
            $ancestor = $ancestor->parent;
        }
    }

    private function cascadeDeactivate(Department $sector): void
    {
        foreach ($sector->children as $child) {
            $child->is_active = false;
            $child->save();
            $this->cascadeDeactivate($child);
        }
    }

    private function uniqueCode(?string $code, string $name): string
    {
        $base = Str::upper(Str::slug($code ?: Str::limit($name, 8, ''), ''));
        $base = $base !== '' ? substr($base, 0, 24) : 'SECTOR';
        $try  = $base;
        $n    = 1;

        while (Department::withTrashed()->where('code', $try)->exists()) {
            $try = substr($base, 0, 24 - strlen((string) ++$n)).$n;
        }

        return $try;
    }

    private function nextDisplayOrder(?int $parentId): int
    {
        return (int) Department::query()
            ->where('parent_id', $parentId)
            ->max('display_order') + 10;
    }
}
