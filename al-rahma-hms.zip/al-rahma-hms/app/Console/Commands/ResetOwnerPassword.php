<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\User;
use App\Services\Admin\UserService;
use Illuminate\Console\Command;

/**
 * The hospital's way back in.
 *
 * If the System Owner password is lost, this is the only recovery route, and
 * it requires shell access to the server — which in practice means physical
 * access to the machine in the office. That is the right level of difficulty:
 * hard enough that it is not a remote attack path, easy enough that a lost
 * password is not a disaster.
 */
class ResetOwnerPassword extends Command
{
    protected $signature = 'hms:reset-owner-password {username? : The owner username, if more than one exists}';

    protected $description = "Issue a new temporary password for the hospital's System Owner account";

    public function handle(UserService $users): int
    {
        $query = User::query()->where('is_protected', true);

        if ($username = $this->argument('username')) {
            $query->where('username', $username);
        }

        $owners = $query->get();

        if ($owners->isEmpty()) {
            $this->error('No System Owner account found. Run: php artisan db:seed --class=SystemOwnerSeeder');

            return self::FAILURE;
        }

        if ($owners->count() > 1 && ! $username) {
            $this->error('More than one owner account exists. Name the one to reset:');
            $this->line('  '.$owners->pluck('username')->implode(', '));

            return self::FAILURE;
        }

        $owner = $owners->first();

        if (! $this->confirm("Issue a new temporary password for '{$owner->username}'? The current password stops working immediately.")) {
            return self::SUCCESS;
        }

        $temporary = $users->resetPassword($owner);

        $this->newLine();
        $this->warn('=========================================================');
        $this->warn('  TEMPORARY PASSWORD — shown once, not stored anywhere');
        $this->warn('=========================================================');
        $this->line("  Username:  {$owner->username}");
        $this->line("  Password:  {$temporary}");
        $this->warn('=========================================================');
        $this->line('  A new password must be chosen at the next sign-in.');
        $this->newLine();

        return self::SUCCESS;
    }
}
