<?php

declare(strict_types=1);

namespace App\Exceptions;

use RuntimeException;

/** Raised when the appointments_doctor_slot_unique constraint rejects a
 |  booking. The database is the guarantee; this turns its error into a
 |  message a receptionist can act on. */
class DoubleBookingException extends RuntimeException {}
