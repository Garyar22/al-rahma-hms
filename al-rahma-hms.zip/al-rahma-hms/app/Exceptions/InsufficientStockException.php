<?php

declare(strict_types=1);

namespace App\Exceptions;

use RuntimeException;

/** Thrown by StockLedger when a movement would drive a balance below zero. */
class InsufficientStockException extends RuntimeException {}
