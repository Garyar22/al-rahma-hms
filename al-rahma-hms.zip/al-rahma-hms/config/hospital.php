<?php

declare(strict_types=1);

/*
 | Al Rahma Hospital — STRUCTURAL configuration only.
 |
 | Anything hospital staff should be able to change without a developer lives
 | in the `settings` table and is read through SettingsRepository (Rule 11).
 | The values here are used at MIGRATION time (generated columns) or as
 | fallbacks before settings are seeded.
 */
return [
    'name'    => env('HOSPITAL_NAME', 'Al Rahma Hospital'),
    'address' => env('HOSPITAL_ADDRESS', 'Qardho Main Road, Qardho, Somalia'),

    /*
     | Somalia is UTC+3 with no daylight saving, so a fixed offset is safe for
     | the generated `business_date` columns (Blueprint D9).
     | Changing this after go-live requires a migration that rebuilds every
     | generated column. It is deliberately NOT a runtime setting.
     */
    'timezone'         => env('HOSPITAL_TIMEZONE', 'Africa/Mogadishu'),
    'utc_offset_hours' => (int) env('HOSPITAL_UTC_OFFSET_HOURS', 3),

    'currency'        => env('HOSPITAL_CURRENCY', 'USD'),
    'currency_symbol' => env('HOSPITAL_CURRENCY_SYMBOL', '$'),

    'prefixes' => [
        'patient'       => 'ARH-P-',
        'visit'         => 'ARH-VST-',
        'appointment'   => 'ARH-APT-',
        'admission'     => 'ARH-ADM-',
        'prescription'  => 'ARH-RX-',
        'lab_request'   => 'ARH-LAB-',
        'lab_sample'    => 'ARH-SMP-',
        'invoice'       => 'ARH-INV-',
        'receipt'       => 'ARH-REC-',
        'goods_receipt' => 'ARH-GRN-',
        'expense'       => 'ARH-EXP-',
        'employee'      => 'ARH-EMP-',
        'report'        => 'ARH-RPT-',
    ],
    'number_padding' => 6,

    'billing' => [
        'mode'                      => env('HOSPITAL_BILLING_MODE', 'pay_before_service'),
        'allow_advance_payments'    => false,
        'discount_approval_percent' => 10,
    ],

    'clinical' => [
        'consultation_edit_grace_minutes' => 1440,
        'breakglass_window_minutes'       => 720,
        'allow_self_verification_in_lab'  => false,
    ],

    'inventory' => ['expiry_warning_days' => 90],

    'security' => [
        'max_login_attempts'      => 5,
        'lockout_minutes'         => 15,
        'session_idle_minutes'    => 30,
        'password_min_length'     => 12,
    ],

    /*
     | Modules that can be switched on or off per sector by the administration.
     | Adding a module here makes it selectable in Sector management; it never
     | requires a schema change.
     */
    'modules' => [
        'opd'         => 'Outpatient (OPD)',
        'emergency'   => 'Emergency',
        'inpatient'   => 'Inpatient / Ward',
        'maternity'   => 'Maternity',
        'laboratory'  => 'Laboratory',
        'pharmacy'    => 'Pharmacy',
        'radiology'   => 'Radiology / Imaging',
        'billing'     => 'Billing & Cashier',
        'inventory'   => 'Store & Inventory',
        'hr'          => 'Staff & HR',
        'reporting'   => 'Reports',
    ],
];
