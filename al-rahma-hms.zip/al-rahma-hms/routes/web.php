<?php

declare(strict_types=1);

use App\Http\Controllers\Admin\SectorController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\PasswordController;
use Illuminate\Support\Facades\Route;

/*
 | Routes are grouped by module and always named, because views, policies and
 | tests reference them by name. There is no registration route: accounts are
 | created by an administrator (FR-SEC-09).
 */

Route::middleware('guest')->group(function (): void {
    Route::get('login', [LoginController::class, 'show'])->name('login');
    Route::post('login', [LoginController::class, 'store'])->middleware('throttle:20,1');
});

Route::middleware('auth')->group(function (): void {
    Route::post('logout', [LoginController::class, 'destroy'])->name('logout');

    // Reachable while must_change_password is set; everything else is not.
    Route::get('password/change', [PasswordController::class, 'edit'])->name('password.change');
    Route::put('password/change', [PasswordController::class, 'update'])->name('password.update');
});

Route::middleware(['auth', 'password.changed', 'idle.timeout'])->group(function (): void {

    Route::view('/', 'dashboard')->name('home');

    Route::get('dashboard', function () {
        $hour = now(config('hospital.timezone'))->hour;

        return view('dashboard', [
            'greeting' => $hour < 12 ? __('morning') : ($hour < 17 ? __('afternoon') : __('evening')),
            'today'    => now(config('hospital.timezone'))->translatedFormat('l, j F Y'),
        ]);
    })->name('dashboard');

    /*
     | Administration
     |
     | The hospital's structure and its accounts. Authorisation is enforced
     | twice on purpose: the middleware keeps the whole group out of reach,
     | and each controller authorises the individual record through a policy.
     | A missing middleware must never become an open door.
     */
    Route::prefix('admin')->name('admin.')->group(function (): void {

        Route::middleware('permission:org.sector.view')->group(function (): void {
            Route::post('sectors/{sector}/deactivate', [SectorController::class, 'deactivate'])
                ->name('sectors.deactivate');
        });

        Route::resource('sectors', SectorController::class)
            ->parameters(['sectors' => 'sector']);

        Route::middleware('permission:users.account.view')->group(function (): void {
            Route::post('users/{user}/toggle', [UserController::class, 'toggleActive'])->name('users.toggle');
            Route::post('users/{user}/password', [UserController::class, 'resetPassword'])->name('users.password');
        });

        Route::resource('users', UserController::class)->except(['show', 'destroy']);
    });
});
